/**
 * Homework 1
 * CMSC 653 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */


1.0 Introduction
----------------
This program requires the installation of the 
Sun Java Runtime Environment version 1.6 (JRE).
http://www.java.com/en/download/index.jsp

Double-click on the RUN_ME.bat script to run the program.

1.1 Files
---------
bin/ - java class files for the app
src/ - source files for the app
.classpath - used by Eclipse IDE
.project - used by Eclipse IDE
README.txt - this file
RUN_ME.bat - batch file for running the application

greg.txt - test data using random samples
greg2.txt - test data from Figure 8.2 in the text
Hea-dat.txt - test data from the project website
Iris-dat.txt - test data from the project website



2.0 CAIM
--------
The program will display three buttons.

2.1 Read me
-----------
Displays this file

2.2 Select File
---------------
Allows you to select a file.  A file selection dialog will be displayed.
The file will immediately be run through the CAIM algorithm and a results 
file will be displayed.  The file must be formatted in the same fashion
as the example files for this project.

2.3 Source Code
---------------
Displays a File Explorer in the source code directory.



3.0 Output
----------
The results are dumped into a file with the extension ".result"
The results are displayed in a notepad window and has three sections:

3.1 Dataset title
-----------------
This displays the dataset's title as entered in the original dataset

3.2 Discretizations
-------------------
Integer and Real number discretizations are displayed as a set of ranges.
EXAMPLE: x : [0.01,0.11] (0.11,0.33] (0.33,0.66] (0.66,1.0]

String and Classname discretizations are displayed as a set of strings.
EXAMPLE: classname : [GREEN,below,on,red]

3.3 Feature List
----------------
The original data set is repeated in a tab-separated list.
The original value is displayed followed by its discrete value in brackets
EXAMPLE:
x	rand	classname	
0.01[0]	0.606961831[0]	below[1]	
0.02[1]	0.578360521[2]	below[1]	
0.03[2]	0.644931872[2]	below[1]

4.0 Notes
---------
The program is not written as efficiently as possible.
A mix of arrays and lists were used.
Objects were often copied for the sake of ease of programming.
Improvements would include the use of more global variables
and arrays over lists.

Error handling is sparse at best.
An ill-formatted file will cause an abnormal end of program.

The algorithm appears to always pick the same number of
intervals as the number of classes.
