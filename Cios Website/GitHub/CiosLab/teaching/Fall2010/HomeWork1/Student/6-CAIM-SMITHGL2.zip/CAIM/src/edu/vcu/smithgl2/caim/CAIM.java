package edu.vcu.smithgl2.caim;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.Arrays;

/**
 * The CAIM algorithm as documented in
 * LA Kurgan & KJ Cios "CAIM Discritization Algorithm" 
 * in IEEE Transactions on Knowledge and Data Engineering Vol 16, No 2
 * February 2004
 * 
 * @author Gregory Smith
 *
 */
public class CAIM {
	Double[] DF; // sorted, distinct features (F)
	ArrayList<Double> D; // the discretization array
	boolean[] B; // the boundaries list
	int S; // the number of classes
	double GlobalCAIM = 0;

	/**
	 * the constructor. calls the init() method
	 * 
	 * @param F
	 *            = array of continuous features
	 * @param C
	 *            = array of classes for each feature
	 */
	public CAIM(Double[] F, int S) {
		initialization(F);
		this.S = S;
	}

	/**
	 * the compute() method. does the calculation and returns the resulting discretization array
	 * 
	 * @return
	 */
	public Double[] compute(Double[] F, Integer[] C) {
		//System.out.println("---");
		int k = 1;
		while (true) {
			ArrayList<Double> maxD = null;
			double maxCAIM = 0;
			int maxB = 0;
			for (int b = 0; b < B.length; b++) {
				if (B[b]) {
					ArrayList<Double> DD = splitDiscretization(D, DF, b);
					double caim = computeCAIM(DD, F, C);
					if (caim > maxCAIM) {
						maxCAIM = caim;
						maxD = DD;
						maxB = b;
					}
				}
			}
			//System.out.println(maxCAIM + ":" + GlobalCAIM);
			if (maxCAIM > GlobalCAIM || k < S) {
				D = maxD;
				GlobalCAIM = maxCAIM;
				B[maxB] = false;
			} else {
				break;
			}
			k = k + 1;
		}
		// dump(D);
		return D.toArray(new Double[0]);
	}

	/**
	 * The CAIM calculation
	 * 
	 * @param D
	 * @return
	 */
	private double computeCAIM(ArrayList<Double> D, Double[] F, Integer[] C) {
		double caim = 0;
		double[][] Q = computeQuantaMatrix(D, F, C);
		for (int r = 0; r < D.size() - 1; r++) {
			double max = maxr(Q, r);
			double Mr = mplusr(Q, r);
			caim += max * max / Mr;
		}
		caim = caim / (double) D.size();
		return caim;
	}

	private double maxr(double[][] Q, int r) {
		double max = -1E100;
		for (int i = 0; i < S; i++) {
			if (Q[i][r] > max) {
				max = Q[i][r];
			}
		}
		return max;
	}

	private double mplusr(double[][] Q, int r) {
		return Q[S][r];
	}

	/**
	 * initialization. 
	 * sorts the F array and creates the default discretization 
	 * array returns initial Discretization list
	 */
	private void initialization(Double[] F) {

		// sort and make distinct the array
		DF = sortDistinct(F);

		// find the min and max values
		Double d0 = findMinimum(F);
		Double dn = findMaximum(F);

		// create a discretization scheme with [min,max]
		D = new ArrayList<Double>();
		D.add(d0);
		D.add(dn);

		// create a boundaries array
		// each TRUE is where a boundary may lie
		// each FALSE is where a boundary already exists
		B = new boolean[DF.length];
		Arrays.fill(B, true);
		B[0] = false;
		B[DF.length - 1] = false;

		GlobalCAIM = 0.0;
	}

	/**
	 * finds the minimum in the F array
	 * 
	 * @param F
	 * @return
	 */
	private Double findMinimum(Double F[]) {
		Double min = +1e100; // very large number
		for (Double x : F) {
			if (x < min) {
				min = x;
			}
		}
		return min;
	}

	/**
	 * finds the maximum in the F array
	 * 
	 * @param F
	 * @return
	 */
	private double findMaximum(Double F[]) {
		double max = -1E100; // very negative number
		for (double x : F) {
			if (x > max) {
				max = x;
			}
		}
		return max;
	}

	/**
	 * sorts the array F distinct and returns a copy
	 * 
	 * @param F
	 * @return
	 */
	private Double[] sortDistinct(Double F[]) {
		Arrays.sort(F);
		int j = 0;
		for (int i = 0; i < F.length; i++) {
			if (F[i].equals(F[j])) {
				continue;
			} else {
				F[++j] = F[i];
			}
		}
		Double[] newF = Arrays.copyOf(F, j + 1);
		newF = midpointAdjustment(newF);
		return newF;
	}
	
	/**
	 * use the min, max, and midpoint
	 */
	private Double[] midpointAdjustment(Double[] F) {
		Double[] result = new Double[F.length+1];
		result[0] = F[0];
		for(int i=1; i<F.length; i++) {
			result[i] = (F[i-1]+F[i])/2;
		}
		result[result.length-1] = F[F.length-1];
		return result;
	}

	/**
	 * Splits the discretization array D at the boundary indicated at 'b'
	 * 
	 * @param D
	 * @param b
	 * @return
	 */
	private ArrayList<Double> splitDiscretization(ArrayList<Double> D, Double[] F, int b) {
		ArrayList<Double> DD = new ArrayList<Double>();
		for (Double d : D) {
			DD.add(d);
		}
		double x = F[b];
		boolean didSplit = false;
		for (int i = 0; i < DD.size() - 2; i++) {
			double lower = DD.get(i);
			double upper = DD.get(i + 1);
			if (x > lower && x < upper) {
				splitBounds(DD, x, i);
				didSplit = true;
				break;
			}
		}
		// handle the special case of the last boundary which is inclusive
		if (!didSplit) {
			splitBounds(DD, x, DD.size() - 2);
		}
		return DD;
	}

	/**
	 * splits the boundary with value 'x' at location 'i'
	 * 
	 * @param D
	 * @param x
	 * @param i
	 */
	private void splitBounds(ArrayList<Double> D, double x, int i) {
		D.add(i + 1, x);
	}

	/**
	 * print the array F
	 * 
	 * @param F
	 */
	private void dump(Double[] F) {
		for (double f : F) {
			System.out.print(f + " ");
		}
		System.out.println();
	}

	/**
	 * computes the Quanta Matrix
	 * 
	 * @param D
	 * @param F
	 * @param C
	 * @return
	 */
	private double[][] computeQuantaMatrix(ArrayList<Double> D, Double[] F, Integer[] C) {
		double Q[][] = new double[S + 1][D.size()];
		for (int i = 0; i < F.length; i++) {
			int r = discretize(D, F[i]);
			Q[C[i]][r]++;
			Q[S][r]++; // the M+r
			Q[C[i]][D.size() - 1]++; // the Mi+
		}
		//dumpQuanta(Q);
		return Q;
	}

	/**
	 * Prints the quanta matrix for debugging
	 * 
	 * @param Q
	 */
	private void dumpQuanta(double[][] Q) {
		System.out.println();
		for (int i = 0; i < Q.length; i++) {
			for (int j = 0; j < Q[i].length; j++) {
				System.out.print(Q[i][j] + "\t");
			}
			System.out.println();
		}
	}

	/**
	 * convert the number 'f' into one of the ranged defined in D
	 * 
	 * @param D
	 * @param f
	 * @return
	 */
	private int discretize(ArrayList<Double> D, double f) {
		for (int i = 0; i < D.size(); i++) {
			if (D.get(i) <= f && f <= D.get(i + 1)) {
				return i;
			}
		}
		return 0;
	}
}
