package edu.vcu.smithgl2.caim;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.vcu.smithgl2.caim.feature.Feature;

/**
 * A Dataset is a collection of Features
 * 
 * @author Owner
 *
 */
public class Dataset {
	List<Feature> featureList = new ArrayList<Feature>();
	String title;
	int nRows;

	public Dataset(File infile) {
		// read all the lines into memory
		List<String> lines = FileIO.readFile(infile);

		// get the title of the database
		title = lines.get(0);

		// get the comma-separated field names
		String line2 = lines.get(1);
		String[] fieldNames = line2.split(",");

		// get the comma-separated datatypes
		String line3 = lines.get(2);
		String[] dataTypes = line3.split(",");

		// create the "empty" features
		for (int i = 0; i < fieldNames.length; i++) {
			Feature feature = Feature.instance(fieldNames[i], dataTypes[i]);
			featureList.add(feature);
		}

		// read all the data into memory and assign each to its correct feature set
		for (int i = 3; i < lines.size(); i++) {
			String data = lines.get(i);
			String[] fields = data.split(",");
			for (int j = 0; j < fields.length; j++) {
				Feature feature = featureList.get(j);
				feature.add(fields[j]);
			}
		}
		nRows = lines.size() - 3;

		// discretize all the features
		discretize();
	}

	/**
	 * calls discretize() on each Feature
	 */
	private void discretize() {
		// now discretize all the features
		Feature classes = this.getClassname();
		classes.discretize(classes);
		for (Feature feature : featureList) {
			feature.discretize(classes);
		}
	}

	public Feature getFeature(String name) {
		for (Feature f : featureList) {
			if (f.getName().equalsIgnoreCase(name)) {
				return f;
			}
		}
		return null;
	}

	public Feature getClassname() {
		for (Feature f : featureList) {
			if (f.getType().equalsIgnoreCase("classname")) {
				return f;
			}
		}
		return null;
	}

	public void dump() {
		System.out.println("Dataset:" + title);
		for (Feature feature : featureList) {
			System.out.print(feature.getName() + "\t");
		}
		System.out.println();
		for (int i = 0; i < nRows; i++) {
			for (Feature feature : featureList) {
				Object value = feature.get(i);
				System.out.print(value + "\t");
			}
			System.out.println();
		}
	}

	public List<String> dumpDiscrete() {
		ArrayList<String> list = new ArrayList<String>();
		list.add("\nDataset:" + title);
		list.add("-------Discretizations--------");
		for (Feature feature : featureList) {
			String featureDump = feature.dumpDiscretization();
			list.add(featureDump);
		}
		list.add("-------Feature List-----------");
		String bar = "";
		for (Feature feature : featureList) {
			bar += feature.getName() + "\t";
		}
		list.add(bar);
		for (int i = 0; i < nRows; i++) {
			String foo = "";
			for (Feature feature : featureList) {
				Object value = feature.get(i);
				Object discrete = feature.getDiscrete(i);
				foo += value + "[" + discrete + "]" + "\t";
			}
			list.add(foo);
		}
		return list;
	}

}
