package edu.vcu.smithgl2.caim;

/**
 * Homework 1
 * CMSC 653 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 * This program computes the CAIM Discretization for input data.
 * Four datatypes are recognized: 
 * 
 * REAL
 * INTEGER
 * STRING
 * CLASSNAME
 * 
 * REAL and INTEGER are discretized in the same way - using the CAIM algorithm
 * STRING and CLASSNAME are dicretized in the same way - by distinct sorting
 * 
 * @author Gregory Smith
 *
 */
public class Main implements ActionListener {
	JFrame frame = null;
	JButton readmeButton = null;
	JButton startButton = null;
	JButton sourceButton = null;

	/**
	 * Create the GUI and show it. 
	 */
	private void createAndShowGUI() {
		// Make sure we have nice window decorations.
		JFrame.setDefaultLookAndFeelDecorated(true);

		// Create and set up the window.
		frame = new JFrame("CAIM By Greg Smith");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		makeGUI(frame.getContentPane());

		// Display the window.
		frame.pack();
		frame.setBounds(0, 0, 250, 250);
		frame.setVisible(true);
	}

	/**
	 * paint the GUI.  There is a single button that displays
	 * a File Chooser.
	 * 
	 * @param pane
	 */
	private void makeGUI(Container pane) {
		pane.setLayout(null);

		readmeButton = new JButton("Read Me");
		readmeButton.setBounds(0, 20, 150, 16);
		readmeButton.addActionListener(this);
		readmeButton.setActionCommand("Readme");

		startButton = new JButton("Select File");
		startButton.setBounds(0, 40, 150, 16);
		startButton.addActionListener(this);
		startButton.setActionCommand("Start");

		sourceButton = new JButton("Source Code");
		sourceButton.setBounds(0, 60, 150, 16);
		sourceButton.addActionListener(this);
		sourceButton.setActionCommand("Source");

		pane.add(readmeButton);
		pane.add(startButton);
		pane.add(sourceButton);
	}

	/**
	 * The main routine, it just instantiates the Main object and creates the GUI
	 * @param args
	 */
	public static void main(String[] args) {
		Main thisMain = new Main();
		thisMain.createAndShowGUI();
	}

	@Override
	/*
	 * * this 'action' is called whenever a button is pressed.
	 */
	public void actionPerformed(ActionEvent e) {
		/**
		 * this is a dispatcher for the different events that come in 
		 * Basically it just redirects to another method called 'onMethodname()'
		 */
		if ("Start".equals(e.getActionCommand())) {
			onStart(e);
		}
		if ("Source".equals(e.getActionCommand())) {
			onSource(e);
		}
		if ("Readme".equals(e.getActionCommand())) {
			onReadme(e);
		}
	}

	// /////////////////////////////////////////////////////////////////
	// Methods below this line are the actions for individual buttons
	// /////////////////////////////////////////////////////////////////

	/**
	 * This method is called when the Start Button is pressed.
	 */
	private void onStart(ActionEvent e) {
		// open a file chooser dialog so the user can choose the input file
		final JFileChooser fc = new JFileChooser(new File("."));
		int returnVal = fc.showOpenDialog((Component) e.getSource());
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			// the user canceled the file selection dialog box 
			return;
		}

		// get the file selected by the user
		File file = fc.getSelectedFile();

		// read the file into a Dataset
		// Dataset holds all the values in the file
		// separated by Features
		// Dataset also discretizes all the Features
		Dataset dataset = new Dataset(file);

		//Dump the dataset for inspection
		List<String> results = dataset.dumpDiscrete();
		String fname = file.getPath();
		fname += ".result";
		File outfile = new File(fname);
		FileIO.writeFile(fname, results);
		try {
			Process p = Runtime.getRuntime().exec("notepad " + fname);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * displays the source code in a file explorer window
	 * 
	 * @param e
	 */
	private void onSource(ActionEvent e) {
		try {
			Process p = Runtime.getRuntime().exec("explorer .\\src\\edu\\vcu\\smithgl2\\caim");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * displays the readme file
	 * 
	 * @param e
	 */
	private void onReadme(ActionEvent e) {
		try {
			Process p = Runtime.getRuntime().exec("notepad README.txt");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
