package edu.vcu.smithgl2.caim.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.List;

import edu.vcu.smithgl2.caim.CAIM;

/**
 * A DoubleFeature is a set of values that are stored as Doubles.
 */
public class DoubleFeature extends Feature {

	List<Double> values;
	Double[] d;

	/**
	 * the constructor
	 * 
	 * @param name
	 * @param type
	 */
	protected DoubleFeature(String name, String type) {
		super(name, type);
		values = new ArrayList<Double>();
	}

	/**
	 * add a value to the feature set
	 * 
	 */
	public void add(String value) {
		Double d = new Double(value);
		values.add(d);
	}

	/**
	 * get a value from the original set of values
	 * 
	 */
	public Object get(int i) {
		return values.get(i);
	}

	/**
	 * discretize the feature set (using the CAIM algorithm)
	 * 
	 */
	@Override
	public List<Integer> discretize(Feature classes) {
		Double[] F = values.toArray(new Double[0]);
		Integer[] C = classes.getDiscretization().toArray(new Integer[0]);
		CAIM caim = new CAIM(F, classes.getDistinct().size());
		d = caim.compute(F, C);
		discretized = new ArrayList<Integer>();
		for (int i = 0; i < F.length; i++) {
			Integer x = find(F[i]);
			discretized.add(x);
		}
		return discretized;
	}

	/**
	 * find a value in the discetization and return its index
	 * 
	 * @param f
	 * @return
	 */
	private int find(double f) {
		for (int i = 0; i < d.length; i++) {
			if (d[i] <= f && f <= d[i + 1]) {
				return i;
			}
		}
		// never gets here
		return 0;
	}

	/**
	 * unimplemented for DoubleFeature
	 */
	@Override
	public List getDistinct() {
		return null;
	}

	/**
	 * print the discretization array
	 * 
	 * @param D
	 */
	public String dumpDiscretization() {
		String foo = name + " : ";
		String left = "[";
		for (int i = 0; i < d.length - 1; i++) {
			foo += left + d[i] + "," + d[i + 1] + "]";
			left = " (";
		}
		return foo;
	}

}
