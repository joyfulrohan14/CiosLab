package edu.vcu.smithgl2.caim.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.List;

/**
 * A Feature is a discretized set of values.
 * It consists of two lists:
 * 1) list of discretized values (integers)
 * 2) list of labels/values
 *   a) if discretized values were strings, then this is a set of strings
 *   b) if discretized values were numbers, then this is a set of range-values
 *   
 *   There are currently 3 types of Features:
 *   1) StringFeatures
 *   2) DoubleFeatures
 *   3) IntegerFeatures
 */
public abstract class Feature {
	protected String name;
	protected String type;
	protected List<Integer> discretized;

	/**
	 * You cannot instantiate this class directly
	 */
	protected Feature() {
	}

	/**
	 * a feature has a name and a data type that we'll print out eventually
	 * 
	 * @param name
	 * @param type
	 */
	protected Feature(String name, String type) {
		setName(name);
		setType(type);
	}

	/*
	 * Factory methods
	 * 
	 * Note: We currently use the same diseretization method for INTEGER as for REAL (DoubleFeature)
	 * Note: We currently use the same discretization method for STRING and CLASSNAME (StringFeature)
	 * 
	 */
	public static Feature instance(String name, String type) {
		String theType = type.toLowerCase();
		if (theType.equals("string")) {
			return new StringFeature(name, theType);
		} else if (theType.equals("real")) {
			return new DoubleFeature(name, theType);
		} else if (theType.equals("integer")) {
			return new DoubleFeature(name, theType);
		} else if (theType.equals("classname")) {
			return new StringFeature(name, theType);
		}
		return null;
	}

	/**
	 * adds a value to the Feature set.  It is a string and will be converted to the correct type
	 * when the sub-class receives it.
	 * 
	 * @param value
	 */
	public abstract void add(String value);

	/**
	 * get a value from the feature set
	 * @param i
	 * @return
	 */
	public abstract Object get(int i);

	/**
	 * discretize the feature set and return the discretized list
	 * @param classes
	 * @return
	 */
	public abstract List<Integer> discretize(Feature classes);

	/**
	 * get the list of distinct values (where appropriate)
	 * 
	 * @return
	 */
	public abstract List getDistinct();

	/**
	 * get the Type of the data (real, integer, string, classname)
	 * 
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * set the type
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * get the name
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * set the name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public Integer getDiscrete(int i) {
		return discretized.get(i);
	}

	/**
	 * get the discretization (after the disretize() method has been called)
	 * @return
	 */
	public List<Integer> getDiscretization() {
		return discretized;
	}

	/**
	 * dump the features out for debugging
	 */
	public abstract String dumpDiscretization();

}
