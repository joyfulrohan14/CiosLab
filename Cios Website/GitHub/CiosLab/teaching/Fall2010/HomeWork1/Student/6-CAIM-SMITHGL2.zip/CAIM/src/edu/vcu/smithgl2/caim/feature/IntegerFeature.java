package edu.vcu.smithgl2.caim.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A IntegerFeature is a set of values that are stored as Integers.
 * This implementation is not currently used in the application.
 * 
 * It sorts the feature set distinct and uses the resulting 'bins' as a discretization
 */
public class IntegerFeature extends Feature {

	List<Integer> values;
	List<Integer> distinct;

	/**
	 * constructor
	 * 
	 * @param name
	 * @param type
	 */
	protected IntegerFeature(String name, String type) {
		super(name, type);
		values = new ArrayList<Integer>();
	}

	/**
	 * add a feature to the feature set
	 */
	public void add(String value) {
		Integer i = new Integer(value);
		values.add(i);
	}

	/**
	 * get a value from the original feature set
	 */
	public Object get(int i) {
		return values.get(i);
	}

	/**
	 * discretize the feature set.
	 * 
	 * Uses distinct sort to create the discretization
	 */
	public List<Integer> discretize(Feature classes) {
		Integer[] valuesAsArray = values.toArray(new Integer[0]);
		Integer[] sortedDistinct = sortDistinct(valuesAsArray);
		distinct = new ArrayList<Integer>();
		for (Integer s : sortedDistinct) {
			distinct.add(s);
		}
		discretized = new ArrayList<Integer>();
		for (Integer s : values) {
			Integer found = find(s);
			discretized.add(found);
		}
		return discretized;
	}

	/**
	 * find a value in the discretization and return its index
	 * 
	 * @param s
	 * @return
	 */
	private Integer find(Integer s) {
		for (int i = 0; i < distinct.size(); i++) {
			Integer d = distinct.get(i);
			if (d.equals(s)) {
				return new Integer(i);
			}
		}
		// never gets here
		return new Integer(0);
	}

	/**
	 * sorts an array distinct
	 * 
	 * @param F
	 * @return
	 */
	private Integer[] sortDistinct(Integer F[]) {
		Arrays.sort(F);
		int j = 0;
		for (int i = 0; i < F.length; i++) {
			if (F[i].equals(F[j])) {
				continue;
			} else {
				F[++j] = F[i];
			}
		}
		Integer[] newF = Arrays.copyOf(F, j + 1);
		return newF;
	}

	@Override
	public List getDistinct() {
		return distinct;
	}

	@Override
	public Integer getDiscrete(int i) {
		return discretized.get(i);
	}

	public String dumpDiscretization() {
		String foo = "";
		foo = name + " : [";
		String comma = "";
		for (int i = 0; i < distinct.size(); i++) {
			foo += (comma + distinct.get(i));
			comma = ",";
		}
		foo += "]";
		return foo;
	}

}
