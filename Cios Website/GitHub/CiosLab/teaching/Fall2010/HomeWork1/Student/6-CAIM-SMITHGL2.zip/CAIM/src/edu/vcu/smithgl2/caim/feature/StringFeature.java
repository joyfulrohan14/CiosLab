package edu.vcu.smithgl2.caim.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A StringFeature is a set of values that are stored as Strings.
 * 
 * It sorts the feature set distinct and uses the resulting 'bins' as a discretization
 */
public class StringFeature extends Feature {

	List<String> values;
	List<String> distinct;

	/**
	 * constructor
	 * 
	 * @param name
	 * @param type
	 */
	protected StringFeature(String name, String type) {
		super(name, type);
		values = new ArrayList<String>();
	}

	/**
	 * add a value to the feature set
	 */
	public void add(String value) {
		values.add(value);
	}

	/**
	 * get a value from the original feature set
	 */
	public Object get(int i) {
		return values.get(i);
	}

	/**
	 * discretize the feature set.
	 * the features are sorted discrete and the result is used as a discretization
	 */
	public List<Integer> discretize(Feature classes) {
		String[] valuesAsArray = values.toArray(new String[0]);
		String[] sortedDistinct = sortDistinct(valuesAsArray);
		distinct = new ArrayList<String>();
		for (String s : sortedDistinct) {
			distinct.add(s);
		}
		discretized = new ArrayList<Integer>();
		for (String s : values) {
			Integer found = find(s);
			discretized.add(found);
		}
		return discretized;
	}

	/**
	 * find a string in the discretization
	 * return its index
	 * 
	 * @param s
	 * @return
	 */
	private Integer find(String s) {
		for (int i = 0; i < distinct.size(); i++) {
			String d = distinct.get(i);
			if (d.equals(s)) {
				return new Integer(i);
			}
		}
		// never gets here
		return new Integer(0);
	}

	/**
	 * sorts the array F unique and returns a copy
	 * 
	 * @param F
	 * @return
	 */
	private String[] sortDistinct(String F[]) {
		Arrays.sort(F);
		int j = 0;
		for (int i = 0; i < F.length; i++) {
			if (F[i].equals(F[j])) {
				continue;
			} else {
				F[++j] = F[i];
			}
		}
		String[] newF = Arrays.copyOf(F, j + 1);
		return newF;
	}

	public List getDistinct() {
		return distinct;
	}

	public String dumpDiscretization() {
		String foo = "";
		foo = name + " : [";
		String comma = "";
		for (int i = 0; i < distinct.size(); i++) {
			foo += (comma + distinct.get(i));
			comma = ",";
		}
		foo += "]";
		return foo;
	}

}
