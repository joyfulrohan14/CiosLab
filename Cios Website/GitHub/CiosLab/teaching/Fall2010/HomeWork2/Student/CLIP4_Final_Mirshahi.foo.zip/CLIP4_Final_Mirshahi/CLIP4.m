function CLIP4(selection)

load Travel.dat
data = Travel;
 if selection == 1
disp('Travel Dataset');
 elseif selection == 2
     disp('Weather Dataset');
 elseif selection == 3
     disp('Iris Dataset');
 end

[r c] = size(data);

%% Creating POS & NEG MATRIX
temp = 1;
for i = 1:r
    if(data(i,c) == 1)
        POS(i,:) = data(i,:);
    else
        NEG(temp,:) = data(i,:); temp = temp+1;
    end
end
%% Phase 1
 flag1 =0;
 
 POS(:,size(POS,2)) = [];
 %NEG(:,size(NEG,2)) = [];
 POSorg = POS;
 NEGorg = NEG;
numOfTimes = 1;

%while(flag1 == 0)
    POS;
    POSorg;
    NEG;
    numOfTimes;
    tempPOS = POS;
    %display('Phase1');
    [NEGr NEGc] = size(NEG);
    SPLIT = cell(1);
    SPLIT1 = cell(1);
    GlobalSPLIT = cell(1);
    

    for f=1:NEGr
         f;
         SPLIT = {};
         SPLIT = GlobalSPLIT;

        % display('Before Cleanup');
         %  SPLIT;
         if(f>1)
             SPLIT = cleanup(SPLIT);
         end
         %GlobalSPLIT = cell(1);


         %display('After Cleanup');
         %SPLIT;

           %while(flag1 ~= 1)
         for k = 1:length(SPLIT)
            if(f == 1)
                %display('First Round');
                [POSr POSc] = size(POS);
                [NEGr NEGc] = size(NEG);
                %POS(:,POSc) = [];
                BIN = createBIN(POSr,POSc,NEG,f,POS);
            else
                k;
                POS = [];
                SPLIT;
                %display('POS being USED');
                if(SPLIT{k} == [0])
                    SPLIT{k};
                    break;
                end
                POS = SPLIT{k};   %k
                [POSr POSc] = size(POS);
                [NEGr NEGc] = size(NEG);
                BIN = createBIN(POSr,POSc,NEG,f,POS);
            end

            SPLIT1 = iteration3(BIN,POS,NEG,f);
            [SPLITr SPLITc] = size(SPLIT);
            if(k == 1)  %k
            GlobalSPLIT = SPLIT1;
            else
            GlobalSPLIT = [GlobalSPLIT SPLIT1];
            end        
         end
       % GlobalSPLIT
    end 

    %display('PHASE 2');
    [BINCell SOLreturn] = Phase2(NEG,SPLIT);

    
    
    %for v=1:3
       % selection = v;
        Selectiontemp1 = Rules(selection);
        [a b] = rulz(BINCell,SOLreturn,POSorg,selection,Selectiontemp1);
    %end
        POS1 = [];
        b;
        count =1;
    
    for k = 1:size(POSorg,1)
        %for m =1:size(b,1)
            if(find(ismember(b,k),1))
                k;
                POS1(count,:) = POSorg(k,:);
                count = count+1;
                
            else
              % display('');
            end
       % end
    end

    
    POS;
    POS1;
    if(numOfTimes > 10 || size(tempPOS,1) == size(POS1,1))        
        if(tempPOS == POS1)
           flag1 = 1;   
            %display('end');
            numOfTimes;
        end
    end
    numOfTimes = numOfTimes+1;
    tempPOS = POS;
    POS =POS1;
    POSorg = POS1;
    POS1 = [];
%end



% for f=1:1   %NEGr
%     globalSPLIT = {};
%     POS = SPLIT
%     
%     [POSr POSc] = size(POS);
%     [NEGr NEGc] = size(NEG);
%     BIN = createBIN(POSr,POSc,NEG,f,POS);
% %     for i = 1:POSr 
% %         for j=1:POSc-1
% %             if(NEG(f,j) == POS(i,j))
% %               BIN(i,j) = 0;
% %             else
% %               BIN(i,j) = 1;
% %             end
% %         end
% %     end
%     SPLIT = iteration(BIN,POS,NEG,SPLIT,f);
%     [SPLITr SPLITc] = size(SPLIT);
%     SPLIT      
%     
%    % BIN = [];
%     %BIN = createBIN(POSr,POSc,NEG,f,POS);
%     for s=1:SPLITc
%         SPLIT1 = {};
%         SPLIT1 = iteration(BIN,SPLIT{s},NEG,SPLIT1,f);
%         GlobalSPLIT = {globalSPLIT SPLIT1}
%     end
%     SPLIT = {};
%     SPLIT = globalSPLIT;
%     
% end


% % Finding active rows
% temp = sum(BIN,2);
% MIN = min(temp);
% activeROWS = find(temp == MIN);
% ROWS = zeros(POSr,1);
% ROWS(activeROWS(:)) = 1
% passiveROWS =find(temp ~= MIN);
% 
% [passR passC] = size(passiveROWS);
% passTEMP = zeros(1,POSc-1);
% BINtemp = BIN;
% 
% %making the inactive rows zero
% BINtemp(passiveROWS(:),:) = 0
% 
% %calculating MAX of COLOUMS in all active rows
% passiveColsum = sum(BINtemp,1);
% MAX = max(passiveColsum);
% activeCOLS = find(passiveColsum == MAX)
% 
% SOL = zeros(1,POSc-1);
% SOL(activeCOLS(1)) = 1
% 
% % STEP 6
% if(size(activeCOLS,2) > 1)
%     tempCOL = BINtemp(:,activeCOLS(1));
%     temp = find(tempCOL ==1)
%     ROWS(temp(:)) = 0
%     BINtemp(temp(:),:) = 0;
% 
%     BINtemp1 = BIN;
%     BINtemp1(find(ROWS == 1),:) = [];
%     x = min(sum(BINtemp1,1));
% 
%     SOL(find(sum(BINtemp1) == x)) = 1
% end
% 
% % creating POS2 and POS3
% SPLITmat = find(SOL == 1);
% [SPLITr SPLITc] = size(SPLITmat);
% SPLIT = cell([SPLITr SPLITc]);
% 
% for i=1:SPLITc
%     tmp = SPLITmat(i);
%     Temp=1;
%     POS2 = [];
%     for j=1:POSr
%         if (POS(j,tmp) ~= NEG(1,tmp))
%             POS2(Temp,:) = POS(j,:);
%             Temp=Temp+1;
%         end
%     end
%     POS2(:,POSc) = [];
%     SPLIT{i} = POS2;
% end
% SPLIT
% 
% 
% 
% 
% 
% 


end



% temp = 1
% for i=1:POSr
%     if (temp <= passR)
%         if (i == passiveROWS(temp))
%             BINtemp(i,:) = passTEMP;  
%             %BINtemp(:,passiveROWS) = [];
%             temp = temp+1
%         end
%     end
% end
