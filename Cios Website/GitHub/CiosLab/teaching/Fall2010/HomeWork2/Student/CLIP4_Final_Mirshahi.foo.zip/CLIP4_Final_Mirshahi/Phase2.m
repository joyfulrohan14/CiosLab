function [BINreturn SOLreturn] = Phase2(NEG,SPLIT)
%Remove all zero arrays in cell
for i=1:length(SPLIT)
    if(SPLIT{i} == 0)
        SPLIT(i) =[];
    end
end
NEG(:,size(NEG,2)) = [];
BINCell = cell(1);
BINreturn = cell(1);
SOLreturn = [];
    for i=1:length(SPLIT)
        BINCell{i} = NEG;
        for j=1:length(SPLIT{i})
            SPLIT{i};
            u = unique(SPLIT{i}(:,j));
            u;
        
            for l=1:size(u,1)
                for k=1:size(NEG,1)
                    if(NEG(k,j) == u(l))
                        BINCell{i}(k,j) = 0;
                        BINCell{i};
                    end
                end
            end
        end
        BINreturn{i} = BINCell{i};
        
        for k=1:size(BINCell{i},1)
            for j=1:size(BINCell{i},2)
                   if(BINCell{i}(k,j) ~=0)
                       BINCell{i}(k,j) = 1;
                   end
            end
        end
        
        BINCell{i};
        SOL = iteration2(BINCell{i});
        SOLreturn = [SOLreturn;SOL];
    
    
end