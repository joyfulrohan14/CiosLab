function GlobalSPLIT = cleanup(GlobalSPLIT)

flag1=0;
flag2=0;
temp1=1;
temp2=2;

if(length(GlobalSPLIT) >2)
    for i =1:length(GlobalSPLIT)
     if isempty(GlobalSPLIT{i})
         GlobalSPLIT(i) = [];
     end
     if(i>=length(GlobalSPLIT))
         break;
     end
end
    while(flag1 ~= 1)
    %for i=1:length(GlobalSPLIT)
        while(flag2 ~= 1)
        %for j=2:length(GlobalSPLIT)
            
            x1 = GlobalSPLIT{temp1};
            x2 = GlobalSPLIT{temp2};

            tf1 = ismember(x1,x2,'rows');
            tf2 = ismember(x2,x1,'rows');
            
            if(length(tf1)>length(tf2))
               if(size(x2,1)==length(find(tf1(:)==1)));
                   GlobalSPLIT(temp2) = [];
                   GlobalSPLIT = [GlobalSPLIT 0];
               end
            else
                if(size(x1,1)==length(find(tf2(:)==1)));
                   GlobalSPLIT(temp1) = [];
                   GlobalSPLIT = [GlobalSPLIT 0];
                end
            end
            if(temp2>=length(GlobalSPLIT))
                break
            else
                temp2 = temp2+1;
            end
        end 
            if(temp1>=length(GlobalSPLIT))
                break
            else
                temp1 = temp1+1;
            end
    end
end
end
