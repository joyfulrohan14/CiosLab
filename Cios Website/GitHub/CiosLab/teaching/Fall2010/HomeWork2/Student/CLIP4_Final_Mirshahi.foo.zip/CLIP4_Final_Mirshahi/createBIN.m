function BIN = createBIN(POSr,POSc,NEG,f,POS)
BIN = [];
for i = 1:POSr 
        for j=1:POSc
            if(NEG(f,j) == POS(i,j))
              BIN(i,j) = 0;
            else
              BIN(i,j) = 1;
            end
        end
    end

end