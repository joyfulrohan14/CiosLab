function SPLIT = iteration(BIN,POS,NEG,f)


[POSr POSc] = size(POS);
[NEGr NEGc] = size(NEG);


% Finding active rows
temp = sum(BIN,2);
MIN = min(temp);
activeROWS = find(temp == MIN);
ROWS = zeros(POSr,1);
ROWS(activeROWS(:)) = 1;
passiveROWS =find(temp ~= MIN);

[passR passC] = size(passiveROWS);
passTEMP = zeros(1,POSc);
BINtemp = BIN;

%making the inactive rows zero
BINtemp(passiveROWS(:),:) = 0;

%calculating MAX of COLOUMS in all active rows
passiveColsum = sum(BINtemp,1);
MAX = max(passiveColsum);
activeCOLS = find(passiveColsum == MAX);

SOL = zeros(1,POSc);
SOL(activeCOLS(1)) = 1;

% STEP 6
if(size(activeCOLS,2) > 1)
    tempCOL = BINtemp(:,activeCOLS(1));
    temp = find(tempCOL ==1);
    ROWS(temp(:)) = 0;
    BINtemp(temp(:),:) = 0;

    BINtemp1 = BIN;
    BINtemp1(find(ROWS == 1),:) = [];
    x = min(sum(BINtemp1,1));

    SOL(find(sum(BINtemp1) == x)) = 1;
end

% creating POS2 and POS3
SPLITmat = find(SOL == 1);
[SPLITr SPLITc] = size(SPLITmat);
SPLIT = cell([SPLITr SPLITc]);

for i=1:SPLITc
    tmp = SPLITmat(i);
    Temp=1;
    POS2 = [];
    for j=1:POSr
        if (POS(j,tmp) ~= NEG(f,tmp))
            POS2(Temp,:) = POS(j,:);
            Temp=Temp+1;
        end
    end
   % POS2(:,POSc) = [];
    SPLIT{i} = POS2;
end
SOL
SPLIT;



end


