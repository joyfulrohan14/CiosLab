function SOL = iteration2(BIN)

[POSr POSc] = size(BIN);
%[POSr POSc] = size(POS);
%[NEGr NEGc] = size(NEG);

BINtemp = BIN;
SOL = zeros(1,POSc);
while(size(BINtemp,1) > 0)
    
    %Finding active rows
    temp = sum(BINtemp,2);
    MIN = min(temp);
   % activeROWS = find(temp == MIN);
   % activeROWS
   % ROWS = zeros(POSr,1);
   % ROWS(activeROWS(:)) = 1;
    passiveROWS =find(temp ~= MIN);
   % passiveROWS

   % [passR passC] = size(passiveROWS);
    passTEMP = zeros(1,POSc);

    %making the inactive rows zero
    BINtemp(passiveROWS(:),:) = [];

    %calculating MAX of COLOUMS in all active rows
    passiveColsum = sum(BINtemp,1);
    MAX = max(passiveColsum);
    activeCOLS = find(passiveColsum == MAX);

    
    SOL(activeCOLS(1)) = 1;
   

    x = find(BINtemp(:,activeCOLS)==1);
    BINtemp(x(:),:) = [];
   
%     BINtemp;
%     size(BINtemp,1);
    
end
    
end
    
% % STEP 6
% if(size(activeCOLS,2) > 1)
%     display('extra');
%     tempCOL = BINtemp(:,activeCOLS(1));
%     temp = find(tempCOL ==1);
%     ROWS(temp(:)) = 0;
%     BINtemp(temp(:),:) = 0;
% 
%     BINtemp1 = BIN;
%     BINtemp1(find(ROWS == 1),:) = [];
%     x = min(sum(BINtemp1,1));
% 
%     SOL(find(sum(BINtemp1) == x)) = 1;
% end
