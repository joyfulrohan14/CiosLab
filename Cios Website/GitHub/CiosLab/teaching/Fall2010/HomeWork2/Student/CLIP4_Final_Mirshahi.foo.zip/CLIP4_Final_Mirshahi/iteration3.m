function SPLIT = iteration3(BIN,POS,NEG,f)

[POSr POSc] = size(BIN);
%[POSr POSc] = size(POS);
%[NEGr NEGc] = size(NEG);

BINtemp = BIN;
SOL = zeros(1,POSc);

while(size(BINtemp,1) > 0)
    
    %Finding active rows
    temp = sum(BINtemp,2);
    MIN = min(temp);
   % activeROWS = find(temp == MIN);
   % activeROWS
   % ROWS = zeros(POSr,1);
   % ROWS(activeROWS(:)) = 1;
    passiveROWS =find(temp ~= MIN);
   % passiveROWS

   % [passR passC] = size(passiveROWS);
    passTEMP = zeros(1,POSc);

    %making the inactive rows zero
    BINtemp(passiveROWS(:),:) = [];

    %calculating MAX of COLOUMS in all active rows
    passiveColsum = sum(BINtemp,1);
    MAX = max(passiveColsum);
    activeCOLS = find(passiveColsum == MAX);
    
%     display('before');
%      BINtemp

%     temp = [];
%     for k = 1:size(BINtemp,1)
%         sum(BINtemp(k,:))
%         if(sum(BINtemp(k,:)) == 0)
%             temp = [temp k]
%         end
%     end
%     
%     BINtemp(temp(:),:) = []; 
% %     display('after');
% %     BINtemp
    
    SOL(activeCOLS(1)) = 1;
    

    x = find(BINtemp(:,activeCOLS(1))==1);
    if(size(BINtemp,1) > 0)
        x;
        BINtemp;
        BINtemp(x(:),:) = [];
    end
%     BINtemp;
%     size(BINtemp,1);
    
end



% creating POS2 and POS3
SPLITmat = find(SOL == 1);
[SPLITr SPLITc] = size(SPLITmat);
SPLIT = cell([SPLITr SPLITc]);

for i=1:SPLITc
    tmp = SPLITmat(i);
    Temp=1;
    POS2 = [];
    for j=1:POSr
        if (POS(j,tmp) ~= NEG(f,tmp))
            POS2(Temp,:) = POS(j,:);
            Temp=Temp+1;
        end
    end
   % POS2(:,POSc) = [];
    SPLIT{i} = POS2;
end

SOL;
SPLIT;



end


