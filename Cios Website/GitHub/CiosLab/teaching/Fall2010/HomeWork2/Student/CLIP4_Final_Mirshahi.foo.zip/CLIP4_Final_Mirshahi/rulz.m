function [a b] = rulz(BINCell,SOLs,POSorg,selection,colName)
%% Travel
if(selection == 1)
ColName = char('Type of call','Language Fluency','Ticket Type','Age','Decision');
Col{1} = char('Long', 'Local','Intern');
Col{2} = char('Fluent','Accent','Not fluent','Foreign');
Col{3} = char('Local','Short','Long');
Col{4} = char('Very young','Young','Middle','Old','Very old');
Col{5} = char('Buy','Not buy');
end
%% Weather
if(selection ==2)
ColName = char('Outlook','Temperature','Humidity','Windy','Play');
Col{1} = char('Sunny','Rainy','Overcast');
Col{2} = char('Hot','Mild','Cool');
Col{3} = char('High','Normal');
Col{4} = char('True','False');
Col{5} = char('No','Yes');
end

%% Iris
if(selection ==3)
ColName = char('Sepallength','Sepalwidth','Petallength','Petalwidth','Classname');
Col{1} = char('[4.3 - 5.55]','(5.55 - 6.25]','[6.25 - 7.9]');
Col{2} = char('[2-2.95]','(2.95 - 3.05]','(3.05 - 4.4]');
Col{3} = char('[1 - 2.45]','(2.45 - 4.75]','(4.75 - 6.9]');
Col{4} = char('[0.1 - 0.8]','(0.8 - 1.75]','(1.75 - 2.5]');
Col{5} = char('Iris-Setosa','Iris-Versicolor','Iris-Virginica');
end
%%
temp = cell(1);
ROWS = cell(1);
for i=1:size(BINCell,2)
    BIN = BINCell{i};
    SOLs(i,:);
    ones = find(SOLs(i,:)==1);
    
    for j=1:size(ones,2)
        unq = unique(BIN(:,ones(j)));
     
        for k=1:size(POSorg,1)
            if(POSorg(k,ones(j)) ~= unq(:))
                temp{j}(k) = 1;
            else
                temp{j}(k) = 0;
                
            end
        end
        
        
    end   
    temp;
    
    if(size(temp,2) > 1)
           for l=1:(size(temp,2)-1)
                x = temp{l}&temp{l+1};
           end
    else
        x = temp{1};
    end
         h = find(ones);
         
         
         
        % disp('then YES')
   %sprintf('if col %d that was selected in solution #',)
  
    
%     display('if col' x(1))
%     display(x(1))
%     display('that was selected in solution !=')
%     display(unq(:));
    
         %display('SUM OF VALID RULES');
         sums(i) = sum(x);
         sums(i);
         
         %display('ROWS THAT ARE VALID');
         ROWS{i} = find(x(:) == 1);
         ROWS{i};
         
   end

sums';
z = max(sums');
a = find(sums', z);
b = [];
b = ROWS{a};
        %colName
        %for h=1:size(colName,2)
        for j=1:(size(colName,2))
         
         disp(' ');
         disp('RULE');
         disp(' ');
         
         colName{j};
         disp('if');
            for m=1:length(colName{j})/2
                disp([ColName(colName{j}(m),:) ]);
                k=colName{j}(m);
                l=colName{j}(m+(length(colName{j}))/2);
                %disp([Col{k}(l,:)]);

                %disp(Col{b}(unq(h(j)),:));
            if(m==length(colName{j})/2)
                disp('='); 
                disp([Col{k}(l,:)]);
                disp(' ');
           
            elseif(m == (length(colName{j})/2)-1)
                disp('#');    
                disp([Col{k}(l,:)]);
                disp('then');
                   
                
            else
                disp('#');
                disp([Col{k}(l,:)]);
                disp('and');
            end
                    
            end
        end  
        %end
       
         
end