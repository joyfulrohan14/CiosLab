/**
 * Homework 2
 * CMSC 653 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */


1.0 Introduction
----------------
This program requires the installation of the 
Sun Java Runtime Environment version 1.6 (JRE).
http://www.java.com/en/download/index.jsp

Double-click on the RUN_ME.bat script to run the program.

1.1 Files
---------
bin/ - java class files for the app
src/ - source files for the app
.classpath - used by Eclipse IDE
.project - used by Eclipse IDE
README.txt - this file
RUN_ME.bat - batch file for running the application

Hea-dat.txt - test data from the project website
Iris-dat.txt - test data from the project website
Travel-DS.txt - test data from the project website
weather.txt - test data from the project website


2.0 CLIP4
--------
The program will display three buttons.

2.1 Read me
-----------
Displays this file

2.2 Select File
---------------
Allows you to select a file.  A file selection dialog will be displayed.
The file will immediately be run through the CLIP4 algorithm and a results 
file will be displayed.  The file must be formatted in the same fashion
as the example files for this project.

You will be prompted with a dialog box to choose the
positive outcome for the CLIP4 algorithm to create
rules for.

2.3 Source Code
---------------
Displays a File Explorer in the source code directory.

2.4 Noise Threshold
-------------------
Hovering over the first text field will show the name "Noise Threshold"
Enter a value other than '0' to reduce the number of items that will 
be allowed in a POS matrix.  Larger values causes more pruning.

2.5 Stop Threshold
------------------
Hovering over the second text field will show the name "Stop Threshold"
Enter a value other than '0' to terminate the search early.  This is
the number of remaining POS rows at the end of each iteration.

2.6 Iteration Threshold
-----------------------
Hovering over the third text field will show the name "Iteration Threshold"
This is the maximum number of iterations the algorithm will execute.

2.7 Pruning Threshold
-----------------------
Hovering over the fourth text field will show the name "Pruning Threshold"
Prunes nodes from the tree using a goodness value.


3.0 Output
----------
The resultant rules are dumped into a file with the extension ".result"
The rules are displayed in a notepad window.



4.0 EXTRA CREDIT
----------------
For extra credit I implemented the thresholding values.
The values can be set on the main form.