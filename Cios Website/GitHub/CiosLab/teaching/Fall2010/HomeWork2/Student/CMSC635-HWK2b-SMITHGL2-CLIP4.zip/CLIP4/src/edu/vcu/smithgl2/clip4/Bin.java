package edu.vcu.smithgl2.clip4;

import java.util.ArrayList;
import java.util.List;

import edu.vcu.smithgl2.clip4.feature.Feature;

public class Bin {
	Dataset dataset;
	List<String> labels = new ArrayList<String>();
	int[][] matrix;

	/**
	 * create a Bin matrix from the dataset
	 * 
	 * @param dataset
	 */
	public Bin(Dataset dataset) {
		this.dataset = dataset;
		for (int i = 0; i < dataset.featureList.size(); i++) {
			Feature feature = dataset.featureList.get(i);
			for (int j = 0; j < feature.getSize(); j++) {
				String newAttribute = feature.getName() + "=" + feature.get(j).toString();
				if (!labels.contains(newAttribute)) {
					labels.add(newAttribute);
				}
			}
		}

		matrix = new int[dataset.nRows][labels.size()];
		for (int i = 0; i < dataset.nRows; i++) {
			for (int j = 0; j < dataset.featureList.size(); j++) {
				Feature feature = dataset.featureList.get(j);
				String attribute = feature.getName() + "=" + feature.get(i).toString();
				int index = find(labels, attribute);
				if (index >= 0) {
					matrix[i][index] = 1;
				}
			}
		}
	}

	public Bin(Dataset dataset, int solutionColumn, Object positiveAttribute) {
		this.dataset = dataset;
		boolean negative = false;
		if (solutionColumn < 0) {
			negative = true;
			solutionColumn = -solutionColumn;
		}
		Feature solutionFeature = null;
		for (int i = 0; i < dataset.featureList.size(); i++) {
			Feature feature = dataset.featureList.get(i);
			if (solutionColumn == i) {
				solutionFeature = feature;
			} else {
				for (int j = 0; j < feature.getSize(); j++) {
					String newAttribute = feature.getName() + "=" + feature.get(j).toString();
					if (!labels.contains(newAttribute) && i != solutionColumn) {
						labels.add(newAttribute);
					}
				}
			}
		}

		int newRows = 0;
		// count the number of resulting rows
		for (int i = 0; i < dataset.nRows; i++) {
			String solutionAttribute = solutionFeature.get(i).toString();
			if (solutionAttribute.equals(positiveAttribute) && !negative) {
				newRows++;
			} else if (!solutionAttribute.equals(positiveAttribute) && negative) {
				newRows++;
			}
		}
		matrix = new int[newRows][labels.size()];
		int rowCnt = 0;
		for (int i = 0; i < dataset.nRows; i++) {
			String solutionAttribute = solutionFeature.get(i).toString();
			if ((!negative && solutionAttribute.equals(positiveAttribute)) || (negative && !solutionAttribute.equals(positiveAttribute))) {
				for (int j = 0; j < dataset.featureList.size(); j++) {
					Feature feature = dataset.featureList.get(j);
					String attribute = feature.getName() + "=" + feature.get(i).toString();
					int index = find(labels, attribute);
					if (index >= 0) {
						matrix[rowCnt][index] = 1;
					}
				}
				rowCnt++;
			}
		}
	}

	private int find(List<String> a, String s) {
		for (int i = 0; i < a.size(); i++) {
			String t = a.get(i);
			if (t.equals(s)) {
				return i;
			}
		}
		return -1;
	}

	public void dump() {
		System.out.print("\t");
		for (int i = 0; i < labels.size(); i++) {
			System.out.print(labels.get(i) + "\t");
		}
		System.out.println();
		for (int i = 0; i < matrix.length; i++) {
			System.out.print("" + i + "\t");
			for (int j = 0; j < labels.size(); j++) {
				System.out.print("" + matrix[i][j] + "\t");
			}
			System.out.println();
		}
	}

	public void dump(int[] activeRows) {
		for (int i = 0; i < dataset.nRows; i++) {
			System.out.print("" + i + "\t" + activeRows[i] + "\t");
			for (int j = 0; j < labels.size(); j++) {
				System.out.print("" + matrix[i][j] + "\t");
			}
			System.out.println();
		}
	}

	private int countRow(int[] row) {
		int result = 0;
		for (int i = 0; i < row.length; i++) {
			result += row[i];
		}
		return result;
	}

	private int countColumn(int[][] matrix, List<Integer> rows, int col) {
		int result = 0;
		for (int row : rows) {
			result += matrix[row][col];
		}
		return result;
	}

	public List<Integer> coverage() {
		List<Integer> solution = new ArrayList<Integer>();

		int[] activeRows = new int[matrix.length];
		for (int i = 0; i < activeRows.length; i++) {
			activeRows[i] = 1;
		}
		int maxIterations = 10;
		while (countRow(activeRows) > 0) {
			if (--maxIterations == 0)
				break;
			//System.out.println("1 "+ countRow(activeRows));
			//dump(activeRows);
			// 1 - select active rows that have the minimum number of 1's
			List<Integer> minRows = new ArrayList<Integer>();
			int minRowCount = 10000000;
			for (int i = 0; i < activeRows.length; i++) {
				if (activeRows[i] == 1) {
					int cnt = countRow(matrix[i]);
					if (cnt < minRowCount) {
						minRows.clear();
						minRowCount = cnt;
					}
					if (cnt == minRowCount) {
						minRows.add(i);
					}
				}
			}

			//System.out.println("2 "+ minRows.size());
			// 2 - select columns that have the maximum number of 1's within the min-rows
			List<Integer> maxColumns = new ArrayList<Integer>();
			int maxColCount = 0;
			for (int col = 0; col < matrix[0].length; col++) {
				int cnt = countColumn(matrix, minRows, col);
				if (cnt > maxColCount) {
					maxColumns.clear();
					maxColCount = cnt;
				}
				if (cnt == maxColCount) {
					maxColumns.add(col);
				}
			}

			//System.out.println("3 "+ maxColumns.size());
			// 3 - within max-columns find columns that have the max 1's in all active rows
			List<Integer> maxmaxColumns = new ArrayList<Integer>();
			int maxCnt = 0;
			for (int col : maxColumns) {
				int cnt = 0;
				for (int row = 0; row < activeRows.length; row++) {
					if (activeRows[row] == 1 && matrix[row][col] == 1) {
						cnt++;
					}
				}
				if (cnt > maxCnt) {
					maxmaxColumns.clear();
					maxCnt = cnt;
				}
				if (cnt == maxCnt) {
					maxmaxColumns.add(col);
				}
			}

			// if there is more than one maxmaxColumn, go to 4, otherwise go to 5
			if (maxmaxColumns.size() > 1) {
				//System.out.println("4 "+ maxmaxColumns.size());
				// 4 - within maxmaxColumns find the first column that has the lowest number of 1's in the inactive rows
				int bestColumn = 0;
				int minCnt = 100000000;
				for (int col : maxmaxColumns) {
					int cnt = 0;
					for (int row = 0; row < activeRows.length; row++) {
						if (activeRows[row] == 0 && matrix[row][col] == 1) {
							cnt++;
						}
					}
					if (cnt < minCnt) {
						//System.out.println("minCnt=" + cnt + " bestColumn=" + col);
						minCnt = cnt;
						bestColumn = col;
					}
				}
				maxmaxColumns.clear();
				maxmaxColumns.add(bestColumn);
			}

			//System.out.println("5 "+ maxmaxColumns.size());
			// 5 - add the selected column to the solution
			int bestColumn = maxmaxColumns.get(0);
			//System.out.println("5 " + bestColumn);
			solution.add(bestColumn);

			//System.out.println("6 ");
			// 6 - mark the inactive rows, if all rows are inactive then terminate, otherwise go to 1
			for (int row = 0; row < activeRows.length; row++) {
				if (matrix[row][bestColumn] == 1) {
					activeRows[row] = 0;
				}
			}
			//dump(solution);
		}
		return solution;
	}

	private void dump(List<Integer> s) {
		for (Integer a : s) {
			System.out.print(" " + a);
		}
		System.out.println();
	}
}
