package edu.vcu.smithgl2.clip4;

import java.util.ArrayList;
import java.util.List;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

/**
 * The CAIM algorithm as documented in
 * LA Kurgan & KJ Cios "CAIM Discritization Algorithm" 
 * in IEEE Transactions on Knowledge and Data Engineering Vol 16, No 2
 * February 2004
 * 
 * @author Gregory Smith
 *
 */
public class CLIP4 {
	Dataset dataset;
	public int noiseThreshold = 0;
	public int stopThreshold = 0;
	public int maxIterationThreshold = 1000;
	public int pruningThreshold = 0;
	RuleSet finalRules = new RuleSet();
	private Matrix POS;
	private Matrix NEG;
	int solutionColumn;
	Object solutionValue;

	public CLIP4(Dataset dataset, int solutionColumn, Object solutionValue) {
		//
		// N[0]=1; Create POS[0,1] consisting of entire S[P]; Create NEG consisting of entire S[N] // initialize
		this.dataset = dataset;
		dataset.uniquify();
		dataset.dump();

		POS = dataset.split(solutionColumn, solutionValue);
		NEG = dataset.split(-solutionColumn, solutionValue);
		//POS.remove(NEG); // remove all negatives from the list
		
		this.solutionColumn = solutionColumn;
		this.solutionValue = solutionValue;
	}

	public void solve() {
		int solValue = dataset.discretize(solutionColumn, solutionValue);

		//POS.dump("POS", 1);
		//NEG.dump("NEG", 1);

		int iteration = 0;
		while (POS.rows() > stopThreshold) {
			////// PHASE ONE //////
			List<Matrix> posList = phase1(POS, NEG);
			for (Matrix p : posList) {
				//p.dump("FINAL", 1);
			}

			////// PHASE TWO //////
			RuleSet ruleset = phase2(posList, POS, NEG, solutionColumn, solValue);

			if (ruleset != null) {
				////// PHASE THREE //////
				Rule newRule = phase3(ruleset, POS);
				if (newRule != null) {
					finalRules.addRule(newRule);
				}
			}

			iteration++;
			if (iteration >= maxIterationThreshold) {
				break;
			}
		}

		finalRules.dump("FINAL RULES", 1);
		List<String> report = finalRules.report(dataset);
		System.out.println("\n FINAL REPORT\n");
		for (String s : report) {
			System.out.println(s);
		}
	}

	private double fitness(Matrix P, int[] s) {
		//System.out.println("P.rows()="+P.rows()+" s.count="+Matrix.countNonZero(s));
		double result = (double) P.rows() / (double) Matrix.countNonZero(s);
		return result;
	}

	public List<String> report() {
		List<String> report = finalRules.report(dataset);
		return report;
	}

	List<Matrix> phase1(Matrix POS, Matrix NEG) {
		List<Matrix> prime = new ArrayList<Matrix>();
		prime.add(POS);
		//POS.dump("PHASE 1 POS", 1);
		//NEG.dump("PHASE 1 NEG", 1);
		for (int negCnt = 0; negCnt < NEG.rows(); negCnt++) {
			int[] neg = NEG.get(negCnt);
			for(int i=0; i<prime.size(); i++) {
				//prime.get(i).dump("----pos " + i, 1);
			}
			//Matrix.dump("--NEG " + (negCnt + 1), neg, 1);
			List<Matrix> prime2 = new ArrayList<Matrix>();
			for (Matrix pos : prime) {
				if (pos.rows() == 0)
					continue;
				//pos.dump("----pos", 1);
				Matrix bin = pos.BIN(neg);
				//bin.dump("----BIN");
				int[] sol = bin.coverage();
				//Matrix.dump("----SOL COVERAGE", sol);

				double pruningFitness = fitness(pos, sol);
				//System.out.println("FITNESS="+pruningFitness);
				if (pruningFitness < pruningThreshold) {
					continue;
				}
				for (int col = 0; col < sol.length; col++) {
					if (sol[col] == 1) {
						Matrix POS1 = new Matrix(0, POS.cols());
						for (int row = 0; row < bin.rows(); row++) {
							if (bin.get(row, col) == 1) {
								POS1.add(pos.get(row));
							}
						}
						prime2.add(POS1);
						//POS1.dump("----SOLUTION " + col, 1);
					}
				}
			}
			prime = eliminateNoise(prime2);
			prime = eliminateRedundantMatrices(prime);
		}
		return prime;
	}

	private List<Matrix> eliminateNoise(List<Matrix> M) {
		List<Matrix> result = new ArrayList<Matrix>();
		for (Matrix m : M) {
			if (m.rows() > noiseThreshold) {
				result.add(m);
			} else {
				//m.dump("*** NOISE ***", 1);
			}
		}
		return result;
	}

	private List<Matrix> eliminateRedundantMatrices(List<Matrix> m) {
		List<Matrix> result = new ArrayList<Matrix>();
		for (Matrix M1 : m) {
			boolean same = false;
			for (Matrix M2 : m) {
				if (M1 == M2) {
					continue;
				}
				if (redundant(M1, M2)) {
					same = true;
					//M1.dump("*** REDUNDANT ***", 1);
					break;
				}
			}
			if (!same) {
				result.add(M1);
			}
		}
		return result;
	}

	private boolean redundant(Matrix M1, Matrix M2) {
		boolean result = false;
		int sameRowCount = 0;
		for (int i = 0; i < M1.rows(); i++) {
			int[] row1 = M1.get(i);
			for (int j = 0; j < M2.rows(); j++) {
				int[] row2 = M2.get(j);
				if (sameRow(row1, row2)) {
					sameRowCount++;
				}
			}
		}
		if (sameRowCount == M1.rows()) {
			result = true;
		}
		return result;
	}

	private boolean sameRow(int[] row1, int[] row2) {
		boolean result = true;
		for (int col = 0; col < row1.length; col++) {
			if (row1[col] != row2[col]) {
				result = false;
				break;
			}
		}
		return result;
	}

	private RuleSet phase2(List<Matrix> posList, Matrix POS, Matrix NEG, int solCol, int solValue) {
		if (posList.size() == 0)
			return null;

		Matrix TM = new Matrix(POS.rows(), posList.size());
		for (int i = 0; i < POS.rows(); i++) {
			int[] row = POS.get(i);
			for (int j = 0; j < posList.size(); j++) {
				Matrix pos = posList.get(j);
				for (int k = 0; k < pos.rows(); k++) {
					if (sameRow(row, pos.get(k))) {
						TM.set(i, j, 1);
					}
				}
			}
		}
		//TM.dump("TM");

		int[] SC = TM.coverage();
		//Matrix.dump("SC", SC);

		RuleSet ruleset = new RuleSet();

		for (int i = 0; i < SC.length; i++) {
			Matrix pos = posList.get(i);
			Matrix backproj = pos.BIN(NEG);

			//backproj.dump("backproj NEG");

			int[] sol = backproj.coverage();
			//Matrix.dump("SOL", sol);

			ruleset.addRule(sol, backproj, NEG, solCol, solValue);
		}
		//ruleset.dump("RuleSet", 1);
		return ruleset;
	}

	private Rule phase3(RuleSet ruleset, Matrix POS) {
		Rule rule = ruleset.bestRule(POS);
		if (rule != null) {
			//System.out.println("BEST RULE");
			//System.out.println(rule.report(dataset));

			Matrix examplers = rule.positiveExamplers(POS);
			//examplers.dump("REMOVE THESE", 1);

			POS.remove(examplers);
			//POS.dump("NEW POS", 1);
		}
		return rule;

	}
}
