package edu.vcu.smithgl2.clip4;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.vcu.smithgl2.clip4.feature.Feature;

/**
 * A Dataset is a collection of Features
 * 
 * @author Owner
 *
 */
public class Dataset {
	List<Feature> featureList = new ArrayList<Feature>();
	String title;
	int nRows;

	public Dataset(File infile) {
		// read all the lines into memory
		List<String> lines = FileIO.readFile(infile);

		// get the title of the database
		title = lines.get(0);

		// get the comma-separated field names
		String line2 = lines.get(1);
		String[] fieldNames = line2.split(",");

		// get the comma-separated datatypes
		String line3 = lines.get(2);
		String[] dataTypes = line3.split(",");

		// create the "empty" features
		for (int i = 0; i < fieldNames.length; i++) {
			Feature feature = Feature.instance(fieldNames[i].trim(), dataTypes[i].trim());
			featureList.add(feature);
		}

		// read all the data into memory and assign each to its correct feature set
		nRows = 0;
		for (int i = 3; i < lines.size(); i++) {
			String data = lines.get(i);
			data = data.trim();
			if (data.length() == 0) {
				continue;
			}
			String[] fields = data.split(",");
			for (int j = 0; j < fields.length; j++) {
				Feature feature = featureList.get(j);
				feature.add(fields[j].trim());
			}
			nRows++;
		}
	}

	public Feature getFeature(String name) {
		for (Feature f : featureList) {
			if (f.getName().equalsIgnoreCase(name)) {
				return f;
			}
		}
		return null;
	}

	public Feature getClassname() {
		for (Feature f : featureList) {
			if (f.getType().equalsIgnoreCase("classname")) {
				return f;
			}
		}
		return null;
	}

	public int[] getRow(int i) {
		int[] result = new int[featureList.size()];
		int j = 0;
		for (Feature f : featureList) {
			Object obj = f.get(i);
			result[j++] = f.getIndex(obj);
		}
		return result;
	}

	public void dump() {
		System.out.println("Dataset:" + title);
		for (Feature feature : featureList) {
			System.out.print(feature.getName() + "\t");
		}
		System.out.println();
		for (int i = 0; i < nRows; i++) {
			for (Feature feature : featureList) {
				Object value = feature.get(i);
				System.out.print(value + "\t");
			}
			System.out.println();
		}
	}

	public Object get(int row, int col) {
		Feature feature = featureList.get(col);
		Object obj = feature.get(row);
		return obj;
	}

	public int getIndex(int row, int col) {
		Feature feature = featureList.get(col);
		Object obj = feature.get(row);
		int result = feature.getIndex(obj);
		return result;
	}

	public Matrix split(int solutionColumn, Object solutionValue) {
		int rows = 0;
		boolean neg = false;
		if (solutionColumn < 0) {
			solutionColumn = -solutionColumn;
			neg = true;
		}
		int cols = featureList.size();
		for (int i = 0; i < nRows; i++) {
			Object obj = this.get(i, solutionColumn);
			if (!neg && solutionValue.equals(obj)) {
				rows++;
			}
			if (neg && !solutionValue.equals(obj)) {
				rows++;
			}
		}

		Matrix result = new Matrix(rows, cols - 1);
		int row = 0;
		for (int i = 0; i < nRows; i++) {
			Object solutionObject = this.get(i, solutionColumn);
			//			System.out.println("neg="+neg);
			//			System.out.println("solutionObject="+solutionObject);
			//			System.out.println("solutionValue="+solutionValue);
			if ((!neg && solutionValue.equals(solutionObject)) || (neg && !solutionValue.equals(solutionObject))) {
				//				System.out.println("\nWORKING! "+i);
				int col = 0;
				for (int j = 0; j < cols; j++) {
					if (j == solutionColumn) {
						continue;
					}
					int index = this.getIndex(i, j);
					result.set(row, col, index);
					col++;
				}
				row++;
			}
		}
		return result;
	}

	public int discretize(int col, Object value) {
		Feature feature = this.featureList.get(col);
		return feature.getIndex(value);
	}

	private int hashRow(int row) {
		int hash = 0;
		for (int j = 0; j < featureList.size(); j++) {
			hash = hash * 100 + this.getIndex(row, j);
		}
		return hash;
	}

	public void uniquify() {
		boolean[] removeList = new boolean[nRows];
		for (int i = 0; i < nRows; i++) {
			int hash = hashRow(i);
			for (int j = i + 1; j < nRows; j++) {
				int hash2 = hashRow(j);
				if (hash == hash2) {
					removeList[j] = true;
				}
			}
		}
		for (int i = nRows - 1; i >= 0; i--) {
			if (removeList[i]) {
				for (int j = 0; j < featureList.size(); j++) {
					Feature feature = featureList.get(j);
					feature.remove(i);
				}
				nRows--;
			}
		}
	}
}
