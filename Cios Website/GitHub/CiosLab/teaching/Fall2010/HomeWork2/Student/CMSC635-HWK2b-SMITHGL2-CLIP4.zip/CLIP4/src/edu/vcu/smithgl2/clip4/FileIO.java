package edu.vcu.smithgl2.clip4;
/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utilities for reading/writing entire files into/from a List of Strings
 * from http://www.java-tips.org/java-se-tips/java.io/how-to-read-file-in-java.html
 * 
 * @author Greg Smith
 *
 */
public class FileIO {
	
	/**
	 * read a file when given a filename as a String
	 * 
	 * @param fname
	 * @return
	 */
	public static List<String> readFile(String fname) {
		File file = new File(fname);
		return readFile(file);
	}

	/**
	 * read a file when given a File
	 * 
	 * @param file
	 * @return
	 */
	public static List<String> readFile(File file) {
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		ArrayList<String> results = new ArrayList<String>();
		try {
			fis = new FileInputStream(file);

			// Here BufferedInputStream is added for fast reading.
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);

			// dis.available() returns 0 if the file does not have more lines.
			while (dis.available() != 0) {

				results.add(dis.readLine());
			}

			// dispose all the resources after using them.
			fis.close();
			bis.close();
			dis.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return results;
	}

	/**
	 * write a list of strings to a file defined by its String filename
	 * 
	 * @param fname
	 * @param strings
	 */
	public static void writeFile(String fname, List<String> strings) {
		File file = new File(fname);
		writeFile(file, strings);
	}

	/**
	 * write a list of strings to a file defined by its File
	 * 
	 * @param file
	 * @param strings
	 */
	public static void writeFile(File file, List<String> strings) {
		try {
			FileOutputStream fos = new FileOutputStream(file);

			for (String s : strings) {
				fos.write(s.getBytes());
				fos.write("\r\n".getBytes());
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
