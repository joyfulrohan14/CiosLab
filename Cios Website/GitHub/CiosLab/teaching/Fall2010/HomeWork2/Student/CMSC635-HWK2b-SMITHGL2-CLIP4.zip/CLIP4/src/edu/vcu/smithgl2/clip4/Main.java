package edu.vcu.smithgl2.clip4;

/**
 * Homework 1
 * CMSC 653 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import edu.vcu.smithgl2.clip4.feature.Feature;

/**
 * This program computes the CAIM Discretization for input data.
 * Four datatypes are recognized: 
 * 
 * REAL
 * INTEGER
 * STRING
 * CLASSNAME
 * 
 * REAL and INTEGER are discretized in the same way - using the CAIM algorithm
 * STRING and CLASSNAME are dicretized in the same way - by distinct sorting
 * 
 * @author Gregory Smith
 *
 */
public class Main implements ActionListener {
	JFrame frame = null;
	JButton readmeButton = null;
	JButton startButton = null;
	JButton sourceButton = null;
	JTextField noiseThreshold = null;
	JTextField stopThreshold = null;
	JTextField iterationThreshold = null;
	JTextField pruningThreshold = null;
	JLabel noiseLabel = null;
	JLabel stopLabel = null;
	JLabel iterationLabel = null;
	JLabel pruningLabel = null;


	/**
	 * Create the GUI and show it. 
	 */
	private void createAndShowGUI() {
		// Make sure we have nice window decorations.
		JFrame.setDefaultLookAndFeelDecorated(true);

		// Create and set up the window.
		frame = new JFrame("CLIP4 By Greg Smith");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		makeGUI(frame.getContentPane());

		// Display the window.
		frame.pack();
		frame.setBounds(0, 0, 250, 250);
		frame.setVisible(true);
	}

	/**
	 * paint the GUI.  There is a single button that displays
	 * a File Chooser.
	 * 
	 * @param pane
	 */
	private void makeGUI(Container pane) {
		pane.setLayout(null);

		readmeButton = new JButton("Read Me");
		readmeButton.setBounds(0, 20, 150, 16);
		readmeButton.addActionListener(this);
		readmeButton.setActionCommand("Readme");

		startButton = new JButton("Select File");
		startButton.setBounds(0, 40, 150, 16);
		startButton.addActionListener(this);
		startButton.setActionCommand("Start");

		sourceButton = new JButton("Source Code");
		sourceButton.setBounds(0, 60, 150, 16);
		sourceButton.addActionListener(this);
		sourceButton.setActionCommand("Source");

		noiseThreshold = new JTextField("0");
		noiseThreshold.setBounds(75, 80, 75, 16);
		noiseThreshold.setToolTipText("Noise Threshold");
		noiseLabel = new JLabel("Noise Threshold");
		noiseLabel.setBounds(0, 80, 75, 16);


		stopThreshold = new JTextField("0");
		stopThreshold.setBounds(75, 100, 75, 16);
		stopThreshold.setToolTipText("Stop Threshold");
		stopLabel = new JLabel("Stop Threshold");
		stopLabel.setBounds(0, 100, 75, 16);

		iterationThreshold = new JTextField("1000");
		iterationThreshold.setBounds(75, 120, 75, 16);
		iterationThreshold.setToolTipText("Iteration Threshold");
		iterationLabel = new JLabel("Iter Threshold");
		iterationLabel.setBounds(0, 120, 75, 16);

		pruningThreshold = new JTextField("0");
		pruningThreshold.setBounds(75, 140, 75, 16);
		pruningThreshold.setToolTipText("Pruning Threshold");
		pruningLabel = new JLabel("Pruning Threshold");
		pruningLabel.setBounds(0, 140, 75, 16);


		pane.add(readmeButton);
		pane.add(startButton);
		pane.add(sourceButton);
		pane.add(noiseThreshold);
		pane.add(stopThreshold);
		pane.add(iterationThreshold);
		pane.add(pruningThreshold);
		pane.add(noiseLabel);
		pane.add(stopLabel);
		pane.add(iterationLabel);
		pane.add(pruningLabel);
	}

	/**
	 * The main routine, it just instantiates the Main object and creates the GUI
	 * @param args
	 */
	public static void main(String[] args) {
		Main thisMain = new Main();
		thisMain.createAndShowGUI();
	}

	@Override
	/*
	 * * this 'action' is called whenever a button is pressed.
	 */
	public void actionPerformed(ActionEvent e) {
		/**
		 * this is a dispatcher for the different events that come in 
		 * Basically it just redirects to another method called 'onMethodname()'
		 */
		if ("Start".equals(e.getActionCommand())) {
			onStart(e);
		}
		if ("Source".equals(e.getActionCommand())) {
			onSource(e);
		}
		if ("Readme".equals(e.getActionCommand())) {
			onReadme(e);
		}
	}

	// /////////////////////////////////////////////////////////////////
	// Methods below this line are the actions for individual buttons
	// /////////////////////////////////////////////////////////////////

	/**
	 * This method is called when the Start Button is pressed.
	 */
	private void onStart(ActionEvent e) {
		// open a file chooser dialog so the user can choose the input file
		final JFileChooser fc = new JFileChooser(new File("."));
		int returnVal = fc.showOpenDialog((Component) e.getSource());
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			// the user canceled the file selection dialog box 
			return;
		}

		// get the file selected by the user
		File file = fc.getSelectedFile();

		// read the file into a Dataset
		// Dataset holds all the values in the file
		// separated by Features
		// Dataset also discretizes all the Features
		Dataset dataset = new Dataset(file);
		dataset.dump();

		int nFeatures = dataset.featureList.size();
		Feature outcome = dataset.featureList.get(nFeatures - 1);
		String positiveOutcome = popup(outcome.getName(), outcome.getDiscretized());
		//Object posFeature = dataset.featureList.get(nFeatures - 1).get(0);
		CLIP4 clip4 = new CLIP4(dataset, nFeatures - 1, positiveOutcome);

		clip4.noiseThreshold = Integer.parseInt(noiseThreshold.getText());
		clip4.stopThreshold = Integer.parseInt(stopThreshold.getText());
		clip4.maxIterationThreshold = Integer.parseInt(iterationThreshold.getText());
		clip4.pruningThreshold = Integer.parseInt(pruningThreshold.getText());
		        
		clip4.solve();

		List<String> report = clip4.report();
		String fname = file.getPath();
		fname += ".result";
		FileIO.writeFile(fname, report);
		try {
			@SuppressWarnings("unused")
			Process p = Runtime.getRuntime().exec("notepad " + fname);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * displays the source code in a file explorer window
	 * 
	 * @param e
	 */
	private void onSource(ActionEvent e) {
		try {
			@SuppressWarnings("unused")
			Process p = Runtime.getRuntime().exec("explorer .\\src\\edu\\vcu\\smithgl2\\clip4");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * displays the readme file
	 * 
	 * @param e
	 */
	private void onReadme(ActionEvent e) {
		try {
			@SuppressWarnings("unused")
			Process p = Runtime.getRuntime().exec("notepad README.txt");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private String popup(String title, List<Object> choiceList) {
		Object[] possibilities = choiceList.toArray(new Object[choiceList.size()]);
		return (String) JOptionPane.showInputDialog(frame, title, "Select Positive Outcome", JOptionPane.PLAIN_MESSAGE, null, possibilities, null);
	}

}
