package edu.vcu.smithgl2.clip4;

import java.util.ArrayList;
import java.util.List;

public class Matrix {
	int[][] matrix;
	int nColumns = 0;

	public Matrix(int rows, int cols) {
		matrix = new int[rows][cols];
		nColumns = cols;
	}

	public void add(int[] row) {
		int[][] newMatrix = new int[matrix.length + 1][nColumns];
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < nColumns; j++) {
				newMatrix[i][j] = matrix[i][j];
			}
		}
		for (int j = 0; j < nColumns; j++) {
			newMatrix[matrix.length][j] = row[j];
		}
		matrix = newMatrix;
	}

	public static int countNonZero(int[] s) {
		int result = 0;
		for (int i = 0; i < s.length; i++) {
			if (s[i] != 0) {
				result++;
			}
		}
		return result;
	}

	public void set(int row, int col, int value) {
		matrix[row][col] = value;
	}

	public int get(int row, int col) {
		return matrix[row][col];
	}

	public int[] get(int row) {
		return matrix[row];
	}

	public void dump(String title) {
		dump(title, 0);
	}

	public void dump(String title, int bias) {
		System.out.println(title);
		for (int row = 0; row < matrix.length; row++) {
			for (int col = 0; col < matrix[row].length; col++) {
				System.out.print("\t" + (matrix[row][col] + bias));
			}
			System.out.println();
		}
	}

	public static void dump(String title, int[] x) {
		dump(title, x, 0);
	}

	public static void dump(String title, int[] x, int bias) {
		System.out.println(title);
		for (int col = 0; col < x.length; col++) {
			System.out.print("\t" + (bias + x[col]));
		}
		System.out.println();
	}

	public Matrix BIN(int[] row) {
		int rows = this.matrix.length;
		int cols = this.matrix[0].length;

		Matrix result = new Matrix(rows, cols);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (this.matrix[i][j] != row[j]) {
					result.set(i, j, 1);
				}
			}
		}
		return result;
	}

	public Matrix BIN(Matrix NEG) {
		Matrix result = new Matrix(NEG.rows(), NEG.cols());
		for (int i = 0; i < NEG.rows(); i++) {
			for (int j = 0; j < NEG.cols(); j++) {
				int n = NEG.get(i, j);
				boolean matched = false;
				for (int k = 0; k < this.rows(); k++) {
					int p = this.get(k, j);
					if (p == n) {
						matched = true;
						break;
					}
				}
				if (!matched) {
					result.set(i, j, 1);
				}
			}
		}
		return result;
	}

	private int countRow(int[] row) {
		int result = 0;
		for (int i = 0; i < row.length; i++) {
			result += row[i];
		}
		return result;
	}

	private int countColumn(int[][] matrix, List<Integer> rows, int col) {
		int result = 0;
		for (int row : rows) {
			result += matrix[row][col];
		}
		return result;
	}

	public int rows() {
		return matrix.length;
	}

	public int cols() {
		return nColumns;
	}

	public int[] coverage() {
		List<Integer> solution = new ArrayList<Integer>();
		int[] result = new int[matrix[0].length];

		int[] activeRows = new int[matrix.length];
		for (int i = 0; i < activeRows.length; i++) {
			if (countRow(matrix[i]) > 0) {
				activeRows[i] = 1;
			}
		}
		int maxIterations = 10;
		while (countRow(activeRows) > 0) {
			if (--maxIterations == 0)
				break;
			//System.out.println("1 "+ countRow(activeRows));
			//dump(activeRows);
			// 1 - select active rows that have the minimum number of 1's
			List<Integer> minRows = new ArrayList<Integer>();
			int minRowCount = 10000000;
			for (int i = 0; i < activeRows.length; i++) {
				if (activeRows[i] == 1) {
					int cnt = countRow(matrix[i]);
					if (cnt < minRowCount) {
						minRows.clear();
						minRowCount = cnt;
					}
					if (cnt == minRowCount) {
						minRows.add(i);
					}
				}
			}

			//System.out.println("2 "+ minRows.size());
			// 2 - select columns that have the maximum number of 1's within the min-rows
			List<Integer> maxColumns = new ArrayList<Integer>();
			int maxColCount = 0;
			for (int col = 0; col < matrix[0].length; col++) {
				int cnt = countColumn(matrix, minRows, col);
				if (cnt > maxColCount) {
					maxColumns.clear();
					maxColCount = cnt;
				}
				if (cnt == maxColCount) {
					maxColumns.add(col);
				}
			}

			//System.out.println("3 "+ maxColumns.size());
			// 3 - within max-columns find columns that have the max 1's in all active rows
			List<Integer> maxmaxColumns = new ArrayList<Integer>();
			int maxCnt = 0;
			for (int col : maxColumns) {
				int cnt = 0;
				for (int row = 0; row < activeRows.length; row++) {
					if (activeRows[row] == 1 && matrix[row][col] == 1) {
						cnt++;
					}
				}
				if (cnt > maxCnt) {
					maxmaxColumns.clear();
					maxCnt = cnt;
				}
				if (cnt == maxCnt) {
					maxmaxColumns.add(col);
				}
			}

			// if there is more than one maxmaxColumn, go to 4, otherwise go to 5
			if (maxmaxColumns.size() > 1) {
				//System.out.println("4 "+ maxmaxColumns.size());
				// 4 - within maxmaxColumns find the first column that has the lowest number of 1's in the inactive rows
				int bestColumn = 0;
				int minCnt = 100000000;
				for (int col : maxmaxColumns) {
					int cnt = 0;
					for (int row = 0; row < activeRows.length; row++) {
						if (activeRows[row] == 0 && matrix[row][col] == 1) {
							cnt++;
						}
					}
					if (cnt < minCnt) {
						//System.out.println("minCnt=" + cnt + " bestColumn=" + col);
						minCnt = cnt;
						bestColumn = col;
					}
				}
				maxmaxColumns.clear();
				maxmaxColumns.add(bestColumn);
			}

			//System.out.println("5 "+ maxmaxColumns.size());
			// 5 - add the selected column to the solution
			int bestColumn = -1;
			if (maxmaxColumns.size() != 0) {
				bestColumn = maxmaxColumns.get(0);
				//System.out.println("5 " + bestColumn);
				solution.add(bestColumn);
				//System.out.println("6 ");
				// 6 - mark the inactive rows, if all rows are inactive then terminate, otherwise go to 1
				for (int row = 0; row < activeRows.length; row++) {
					if (matrix[row][bestColumn] == 1) {
						activeRows[row] = 0;
					}
				}
				//dump(solution);
			}
		}
		for (Integer col : solution) {
			result[col] = 1;
		}
		return result;
	}

	private boolean sameRow(int[] a, int[] b) {
		for (int k = 0; k < a.length; k++) {
			if (a[k] != b[k]) {
				return false;
			}
		}
		return true;
	}

	public void remove(Matrix x) {
		Matrix newMatrix = new Matrix(0, x.cols());
		for (int j = 0; j < this.rows(); j++) {
			int[] jRow = this.get(j);
			boolean found = false;
			for (int i = 0; i < x.rows(); i++) {
				int[] xRow = x.get(i);
				if (sameRow(xRow, jRow)) {
					found = true;
					break;
				}
			}
			if (!found) {
				newMatrix.add(jRow);
			}
		}
		this.matrix = newMatrix.matrix;
	}
}
