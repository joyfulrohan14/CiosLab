package edu.vcu.smithgl2.clip4;

import java.util.ArrayList;
import java.util.List;

import edu.vcu.smithgl2.clip4.feature.Feature;

public class Rule {
	List<Term> terms;
	Term result;

	public Rule(int[] sol, Matrix backproj, Matrix matrix, int solCol, int solValue) {
		terms = new ArrayList<Term>();
		addTerms(sol, backproj, matrix);
		result = new Term(solCol, solValue);
	}

	public void addTerm(Term term) {
		terms.add(term);
	}

	public void addTerms(int[] sol, Matrix backproj, Matrix matrix) {
		for (int col = 0; col < sol.length; col++) {
			if (sol[col] == 1) {
				for (int row = 0; row < backproj.rows(); row++) {
					int x = backproj.get(row, col);
					int y = matrix.get(row, col);
					if (x == 1) {
						Term t = new Term(col, y);
						if (!terms.contains(t)) {
							terms.add(t);
						}
					}
				}
			}
		}
	}

	public void dump(int bias) {
		System.out.print("IF ");
		String and = "";
		for (Term t : terms) {
			System.out.print(and + " (F" + (t.feature + bias) + " <> " + (t.value + bias) + ") ");
			and = "AND";
		}
		System.out.println(" THEN F" + (result.feature + bias) + " = " + (result.value + bias));
	}

	public String report(Dataset dataset) {
		String result = "IF";
		String and = "";
		for (Term t : terms) {
			Feature f = dataset.featureList.get(t.feature);
			String feature = f.getName();
			Object value = f.getDiscretized(t.value);
			result += " " + and + " (" + feature + " <> " + value + ")";
			and = "AND";
		}
		Feature f = dataset.featureList.get(this.result.feature);
		String feature = f.getName();
		Object value = f.getDiscretized(this.result.value);

		result += " THEN " + feature + " = " + value;
		return result;
	}

	public boolean eval(int[] row) {
		boolean result = true;
		for (Term t : terms) {
			int f = t.feature;
			int v = t.value;
			if (row[f] == v) {
				result = false;
				break;
			}
		}
		//result = result && (row[this.result.feature] == this.result.value);
		return result;
	}
	
	public boolean eval2(int[] row) {
		boolean result = true;
		for (Term t : terms) {
			int f = t.feature;
			int v = t.value;
			if (row[f] == v) {
				result = false;
				break;
			}
		}
		if (result == true) {
			result = row[this.result.feature] == this.result.value;
		} else {
			result = row[this.result.feature] != this.result.value;
		}
		return result;
	}

	public Matrix positiveExamplers(Matrix matrix) {
		Matrix result = new Matrix(0, matrix.cols());
		for (int row = 0; row < matrix.rows(); row++) {
			if (eval(matrix.get(row))) {
				result.add(matrix.get(row));
			}
		}
		return result;
	}
}
