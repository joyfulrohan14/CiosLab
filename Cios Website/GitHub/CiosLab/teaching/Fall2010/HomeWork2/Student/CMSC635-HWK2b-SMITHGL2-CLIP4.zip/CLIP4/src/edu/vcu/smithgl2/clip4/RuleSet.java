package edu.vcu.smithgl2.clip4;

import java.util.ArrayList;
import java.util.List;

public class RuleSet {
	List<Rule> rules;

	public RuleSet() {
		rules = new ArrayList<Rule>();
	}

	public void addRule(Rule newRule) {
		rules.add(newRule);
	}

	public void addRule(int[] sol, Matrix backproj, Matrix pos, int solCol, int solValue) {
		Rule rule = new Rule(sol, backproj, pos, solCol, solValue);
		rules.add(rule);
	}

	public void dump(String title, int bias) {
		System.out.println(title);
		for (Rule rule : rules) {
			rule.dump(bias);
		}
	}

	public List<String> report(Dataset dataset) {
		ArrayList<String> result = new ArrayList<String>();
		int correct = 0;
		int incorrect = 0;
		for (Rule rule : rules) {
			String line = rule.report(dataset);
			result.add(line);
		}
		for (int i = 0; i < dataset.nRows; i++) {
			int[] row = dataset.getRow(i);
			boolean x = false;
			for (Rule rule : rules) {
				x = x || rule.eval2(row);
			}
			if (x) {
				correct++;
			} else {
				incorrect++;
			}
		}
		result.add(""+rules.size()+" Rules");
		result.add("Correct="+correct+" Incorrect="+incorrect);
		return result;
	}

	public Rule bestRule(Matrix matrix) {
		Rule result = null;
		ArrayList<Rule> goodRules = new ArrayList<Rule>();
		ArrayList<Rule> bestRules = new ArrayList<Rule>();
		ArrayList<Integer> goodScores = new ArrayList<Integer>();
		int maxCoverage = 0;
		for (Rule rule : rules) {
			//rule.dump(1);
			int antiCoverage = 0;
			for (int row = 0; row < matrix.rows(); row++) {
				int[] theRow = matrix.get(row);
				boolean eval = rule.eval(theRow);
				//System.out.println("" + row + ":" + eval);
				if (!eval) {
					antiCoverage++;
				}
			}
			int coverage = matrix.rows() - antiCoverage;
			goodScores.add(coverage);
			if (coverage > maxCoverage) {
				maxCoverage = coverage;
				result = rule;
			}
		}
		// get the best ones
		for (int i = 0; i < goodScores.size(); i++) {
			int score = goodScores.get(i);
			if (score == maxCoverage) {
				goodRules.add(rules.get(i));
			}
		}
		// if there is a tie, get the one with the fewest terms
		int maxTerms = 100000;
		for (int i = 0; i < goodRules.size(); i++) {
			Rule rule = goodRules.get(i);
			int nterms = rule.terms.size();
			if (nterms < maxTerms) {
				maxTerms = nterms;
				bestRules.add(rule);
			}
		}
		if (bestRules.size() == 0) {
			return null;
		}
		return bestRules.get(0);
	}
}
