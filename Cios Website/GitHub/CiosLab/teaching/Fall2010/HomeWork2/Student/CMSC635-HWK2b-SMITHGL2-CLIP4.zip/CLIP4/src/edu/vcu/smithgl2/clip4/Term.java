package edu.vcu.smithgl2.clip4;

public class Term {
	int feature;
	int value;

	public Term(int feature, int value) {
		this.feature = feature;
		this.value = value;
	}

	public boolean equals(Object tt) {
		Term t = (Term) tt;
		if (t == null)
			return false;
		return (t.feature == this.feature) && (t.value == this.value);
	}
}
