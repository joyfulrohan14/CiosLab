package edu.vcu.smithgl2.clip4.feature;

import java.util.ArrayList;
import java.util.List;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

public abstract class Feature {
	protected String name;
	protected String type;
	protected List<Object> discretized = new ArrayList<Object>();

	/**
	 * You cannot instantiate this class directly
	 */
	protected Feature() {
	}

	/**
	 * a feature has a name and a data type that we'll print out eventually
	 * 
	 * @param name
	 * @param type
	 */
	protected Feature(String name, String type) {
		setName(name);
		setType(type);
	}

	public static Feature instance(String name, String type) {
		String theType = type.toLowerCase();
		if (theType.equals("s")) {
			return new StringFeature(name, theType);
		} else if (theType.equals("i")) {
			return new IntegerFeature(name, theType);
		} else if (theType.equals("classname")) {
			return new StringFeature(name, theType);
		}
		return null;
	}

	/**
	 * adds a value to the Feature set.  It is a string and will be converted to the correct type
	 * when the sub-class receives it.
	 * 
	 * @param value
	 */
	public abstract void add(String value);

	/**
	 * get a value from the feature set
	 * @param i
	 * @return
	 */
	public abstract Object get(int i);

	/**
	 * get the Type of the data (real, integer, string, classname)
	 * 
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * set the type
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * get the name
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * set the name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public abstract int getSize();

	public int getIndex(Object obj) {
		int result = -1;
		for (int i = 0; i < discretized.size(); i++) {
			if (obj.equals(discretized.get(i))) {
				result = i;
				break;
			}
		}
		return result;
	}
	
	public Object getDiscretized(int i) {
		return discretized.get(i);
	}
	public List<Object> getDiscretized() {
		return discretized;
	}
	public abstract void remove(int i);
}
