package edu.vcu.smithgl2.clip4.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.List;

/**
 * A IntegerFeature is a set of values that are stored as Integers.
 * This implementation is not currently used in the application.
 * 
 * It sorts the feature set distinct and uses the resulting 'bins' as a discretization
 */
public class IntegerFeature extends Feature {

	List<Integer> values;

	/**
	 * constructor
	 * 
	 * @param name
	 * @param type
	 */
	protected IntegerFeature(String name, String type) {
		super(name, type);
		values = new ArrayList<Integer>();
	}

	/**
	 * add a feature to the feature set
	 */
	public void add(String value) {
		Integer i = new Integer(value);
		values.add(i);
		if (!discretized.contains(i)) {
			discretized.add(i);
		}
	}

	/**
	 * get a value from the original feature set
	 */
	public Object get(int i) {
		return values.get(i);
	}

	@Override
	public int getSize() {
		return values.size();
	}

	public void remove(int i) {
		values.remove(i);
	}
}
