package edu.vcu.smithgl2.clip4.feature;

/**
 * Homework 1
 * CMSC 635 - Data Mining and Knowledge Discovery
 * Fall 2010
 * Gregory Smith
 */

import java.util.ArrayList;
import java.util.List;

/**
 * A StringFeature is a set of values that are stored as Strings.
 * 
 * It sorts the feature set distinct and uses the resulting 'bins' as a discretization
 */
public class StringFeature extends Feature {

	List<String> values;

	/**
	 * constructor
	 * 
	 * @param name
	 * @param type
	 */
	protected StringFeature(String name, String type) {
		super(name, type);
		values = new ArrayList<String>();
	}

	/**
	 * add a value to the feature set
	 */
	public void add(String value) {
		values.add(value);
		if (!discretized.contains(value)) {
			discretized.add(value);
		}
	}

	/**
	 * get a value from the original feature set
	 */
	public Object get(int i) {
		return values.get(i);
	}

	@Override
	public int getSize() {
		return values.size();
	}

	public void remove(int i) {
		values.remove(i);
	}
}
