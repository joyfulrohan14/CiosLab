/*
 * Erik Test
 */
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.Vector;
/**
 * @author Erik
 * @version
 */
public class Clip4 {
	private static Calendar myCalendar = Calendar.getInstance();
	private static File     logFile;
	
	private static Vector<Vector<Integer>> dataSet = new Vector<Vector<Integer>>();
	private static Vector<Integer>      classifier = new Vector<Integer>();
	private static Vector<Vector<String>>    rules = new Vector<Vector<String>>();
	private static Vector<String>      theFeatures = new Vector<String>();
	
	private static Vector<Vector<Vector<Integer>>> POS = new Vector<Vector<Vector<Integer>>>();
	private static Vector<Vector<Vector<Integer>>> NEG = new Vector<Vector<Vector<Integer>>>();
	private static Vector<Vector<Vector<Integer>>> BIN = new Vector<Vector<Vector<Integer>>>();
	private static Vector<Vector<Integer>>         SOL = new Vector<Vector<Integer>>();
	
	private static final int START = 3;
	
	private static void log(String log) throws IOException
	{
		if(log.contains("START"))
		{
			Date myDate = new Date();
			DateFormat myFormat = new SimpleDateFormat("yyyy.mm.dd-hh.mm.ss");
			String currentTime = myFormat.format(myDate);
			logFile = new File(currentTime + "-ErikLog.txt");
			logFile.createNewFile();
		}
		
		FileWriter fstream = new FileWriter(logFile.getName(), true);
		BufferedWriter out = new BufferedWriter(fstream);

		out.write(log);
		out.newLine();
		
		out.close();
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		try{
			log("*****START*********");
			log("-----" + myCalendar.getTime());
			System.out.println("Please enter the name of the file to be processed: ");
			Scanner myScanner = new Scanner(System.in);
			String fileName = myScanner.nextLine();
			processFile(fileName);
			Vector<String> bestRules = new Vector<String>();
			
			for(int iteration = 1; iteration <= rules.lastElement().size(); iteration++)
			{
				generatePOSandNEG(iteration);
				log("- POS Table Origin");
				logPOS();
				log("- NEG Table Origin");
				logNEG();
				//Nneg = NEG.size()
				log("-PHASE I-");
				int lastPOS = 0;
				int matrixLimit = 0;
				int origSize = 0;
				for(int i = 0; i < NEG.lastElement().size(); i++)
				//i = NEG row
				{
					origSize = POS.size();
					for(; lastPOS < origSize; lastPOS++)
					{
						BIN.add(new Vector<Vector<Integer>>());
						logNEG(NEG.size() - 1, i);
						logPOS(lastPOS);
						initializeBIN(BIN.size()-1,lastPOS, NEG.size() - 1, i);
						solveSCProblem(0);
						generateNewPOSMatrix(i, lastPOS);
						BIN.clear();
					}
					if(lastPOS - 1 != 0)
					{
						POS.remove(lastPOS - 1);
						lastPOS --;
						if(lastPOS - 1 != 0)
						{
							POS.remove(lastPOS - 1);
							lastPOS --;
						}
					}
					matrixLimit = lastPOS;
				}

				//prunePOSmatrices(2);
				//removeRedundantMatrices(lastPOS, matrixLimit);

				log("-PHASE II-");
				reinitBIN(matrixLimit);
				SOL.clear();
				log("main: solve SC problem for BIN 0");
				solveSCProblem(0);
				
				int lastBIN = 1;
				Vector<String> featureRules  = new Vector<String>();
				int solIndex = 0;
				int solSize  = SOL.size();
				for(int i = 0; i < SOL.elementAt(0).size(); i++)
				{
					if(SOL.elementAt(0).get(i) == 1)
					{
						log("main: creating new NEG matrices");
						generateNewNEGMatrix(matrixLimit+solIndex, 0);
						if(solIndex < solSize)
						{
							solIndex++;
						}
						for(; lastBIN < BIN.size(); lastBIN++)
						{
							solveSCProblem(lastBIN);
							featureRules.add(generateRule(lastBIN, iteration));
						}
					}
				}
				log("-PHASE III-");
				
				int bestRule = findBestRule(featureRules);
				int instancesCovered = 0;
				int prevCovered      = POS.elementAt(0).size() + 1;
				int origPrev         = prevCovered;
				log("main: default prevCovered = " + prevCovered);

				log("main: featureRules size = " + featureRules.size());
				while(POS.elementAt(0).size() > 0 && featureRules.size() > 0)
				{
					log("main: bestRule = " + featureRules.elementAt(bestRule));
					instancesCovered = removeCoveredPOSInstances(featureRules.elementAt(bestRule));
					log("main: instancesCovered = " + instancesCovered);
					log("main: prevCovered = " + prevCovered);
					if(prevCovered == origPrev ||
					   prevCovered / 2 <= instancesCovered)
					{
						log("main: adding rule " + featureRules.elementAt(bestRule));
						bestRules.add(featureRules.elementAt(bestRule));
						featureRules.remove(bestRule);
						log("main: featureRules size = " + featureRules.size());
						bestRule = findBestRule(featureRules);
						prevCovered = instancesCovered;
					}
					else
					{
						break;
					}
				}
				BIN.clear();
				SOL.clear();
				POS.clear();
				NEG.clear();
				log(bestRules.toString());
			}
			displayReadableRules(bestRules);
			log("*****FINISH*********");
			log("-----" + myCalendar.getTime());
		}
		catch(Exception e)
		{
			log(e.toString());
			StackTraceElement[] myException = e.getStackTrace();
			for(int i = 0; i < myException.length; i++)
			{
				log(myException[i].toString());
			}
		}
	}// end main
		
	private static void displayReadableRules(Vector<String> bestRules)
	{
		String displayString = "";
		int column = 0;
		int value  = 0;
		int myLength = 0;
		int decision = 0;
		for(int i = 0; i < bestRules.size(); i++)
		{
			String[] ruleBreakDown = bestRules.elementAt(i).split("[,:]");
			
			myLength = ruleBreakDown.length;
			decision = Integer.parseInt(ruleBreakDown[myLength-1]);
			displayString = "IF ";
			for(int j = 0; j < myLength - 1; j+=2)
			{
				column = Integer.parseInt(ruleBreakDown[j]);
				value  = Integer.parseInt(ruleBreakDown[j+1])-1;
				
				if(value < 0)
				{
					value = 0;
				}
				
				displayString += theFeatures.get(column) + " <> " + rules.elementAt(column).elementAt(value);
					
				if(j + 2 < myLength - 1)
				{
					displayString += " AND ";
				}
			}
			displayString += " THEN " + theFeatures.lastElement() + " = " + rules.lastElement().elementAt(decision-1);
			System.out.println(displayString);
		}
	}
	
	private static int findBestRule(Vector<String> myRules) throws IOException
	{
		boolean instanceCovered = false;
		
		int numFeatures = 0;
		int myFeature   = 0;
		int lowestNumFeatures = BIN.lastElement().lastElement().size();
		int bestRule  = 0;
		int myCount   = 0;
		int bestSoFar = 0;
		int column    = 0;
		int value     = 0;
		for(int i = 0; i < myRules.size(); i++)
		{
			String[] ruleBreakDown = myRules.elementAt(i).split("[,:]");

			for(int z = 0; z < ruleBreakDown.length - 1; z+=2)
			//determine the number of features
			{
				if(z == 0)
				{
					myFeature = Integer.parseInt(ruleBreakDown[z]);
					continue;
				}
				
				if(myFeature == Integer.parseInt(ruleBreakDown[z]))
				{
					numFeatures++;
				}
			}
			
			if(numFeatures < lowestNumFeatures)
			{
				lowestNumFeatures = numFeatures;
			}
			
			for(int k = 0; k < POS.elementAt(0).size(); k++)
			//k = orig POS row
			{
				for(int j = 0; j < ruleBreakDown.length - 1; j += 2)
				{
					column = Integer.parseInt(ruleBreakDown[j]);
					value  = Integer.parseInt(ruleBreakDown[j+1]);

					if(POS.elementAt(0).elementAt(k).elementAt(column) == value)
					{
						instanceCovered = true;
						break;
					}
				}
				
				if(instanceCovered)
				{
					myCount++;
				}
				instanceCovered = false;
			}
			
			if(myCount > bestSoFar)
			{
				bestSoFar = myCount;
				bestRule = i;
			}
			else if(myCount == bestSoFar)
			{
				if(numFeatures < lowestNumFeatures)
				{
					lowestNumFeatures = numFeatures;
					bestRule = i;
				}
			}

			myCount = 0;
			numFeatures = 0;
		}

		return bestRule;
	}//end findBestRule
	
	private static Vector<Integer> findInactiveRows(int binIndex) throws IOException
	{
		Vector<Integer> inactive = new Vector<Integer>();
		
		for(int i = 0; i < BIN.elementAt(binIndex).size(); i++)
		{
			for(int pos = 0; pos < SOL.lastElement().size(); pos++)
			{
				if(SOL.lastElement().get(pos) == 1 && BIN.elementAt(binIndex).elementAt(i).elementAt(pos) == 1)
				{
					inactive.add(i);
				}
			}
		}
		
		return inactive;
	}
	
	private static Vector<Integer> findInactiveMinRows(Vector<Integer> minRows, int binIndex) throws IOException
	{
		Vector<Integer> inactiveRows = new Vector<Integer>();
		for(int i = 0; i < BIN.elementAt(binIndex).size(); i++)
		//loop through the number of rows for the given BIN
		{
			if(!minRows.contains(i))
			{
				inactiveRows.add(i);
			}
		}
		return inactiveRows;
	}
	
	private static void generateNewNEGMatrix(int posMatrix, int negMatrix) throws IOException
	{
		log("generateNewNEGMatrix: comparing POS matrix " + posMatrix + " to NEG matrix " + negMatrix);
		log("generateNewNEGMatrix: POS matrix " + posMatrix);
		
		logPOS(posMatrix);
		
		log("generateNewNEGMatrix: NEG matrix " + negMatrix);
		for(int i = 0; i < POS.elementAt(negMatrix).size(); i++)
		{
			log(POS.elementAt(negMatrix).elementAt(i).toString());
		}

		NEG.add(new Vector<Vector<Integer>>());
		BIN.add(new Vector<Vector<Integer>>());
		int negValue  = 0;
		int posValue  = 0;
		boolean match = false;
		for(int i = 0; i < NEG.elementAt(negMatrix).size(); i++)
		//i = NEG(negMatrix) row
		{
			NEG.lastElement().add(new Vector<Integer>());
			BIN.lastElement().add(new Vector<Integer>());
			for(int j = 0; j < NEG.elementAt(negMatrix).elementAt(i).size(); j++)
			//j = NEG(negMatrix) column = POS(posMatrix) column
			{
				negValue = NEG.elementAt(negMatrix).elementAt(i).elementAt(j);
				for(int l = 0; l < POS.elementAt(posMatrix).size(); l++)
				//l = POS(posMatrix) row
				{
					posValue = POS.elementAt(posMatrix).elementAt(l).elementAt(j);
					if(posValue == negValue)
					{
						match = true;
						break;
					}
				}
				if(!match)
				{
					NEG.lastElement().lastElement().add(negValue);
					BIN.lastElement().lastElement().add(1);
				}
				else
				{
					NEG.lastElement().lastElement().add(0);
					BIN.lastElement().lastElement().add(0);
					match = false;
				}
			}
		}
		logNEG();
	}
	
	private static void generateNewPOSMatrix(int negRow, int posMatrix) throws IOException
	{
		log("generateNewPOSMatrix: SOL = " + SOL.lastElement());
		//for each SOL column
		for(int i = 0; i < SOL.lastElement().size(); i++)
		{
			//that has a value of 1
			if(SOL.lastElement().get(i) == 1)
			{
				log("generateNewPOSMatrix: creating new POS matrix");
				log("generateNewPOSMatrix: based on POS " + posMatrix + " and negRow = " + negRow);
				POS.add(new Vector<Vector<Integer>>());
				//for each POS row
				for(int j = 0; j < POS.elementAt(posMatrix).size(); j++)
				{
					if(POS.elementAt(posMatrix).elementAt(j).elementAt(i) !=
					   NEG.lastElement().elementAt(negRow).elementAt(i))
					{
						POS.lastElement().add(new Vector<Integer>());
						POS.lastElement().lastElement().addAll(POS.elementAt(posMatrix).get(j));
						log(POS.lastElement().lastElement().toString());
					}
				}
			}
		}
	}
	
	private static void generatePOSandNEG(int iterationStep)
	{
		POS.add(new Vector<Vector<Integer>>());
		NEG.add(new Vector<Vector<Integer>>());
		for(int i = 0; i < classifier.size(); i++)
		{
			if(classifier.elementAt(i) == iterationStep)
			{
				POS.elementAt(0).add(new Vector<Integer>());
				POS.elementAt(0).lastElement().addAll(dataSet.elementAt(i));
			}
			else
			{
				NEG.lastElement().add(new Vector<Integer>());
				NEG.lastElement().lastElement().addAll(dataSet.elementAt(i));
			}
		}
	}
	
	private static Vector<Integer> getMaxColumns(int binIndex, Vector<Integer> minRows) throws IOException
	//finds the columns that have the maximum value in the given rows
	{
		//now find best column sums
		int bestSum = 0;
		int mySum   = 0;
		Vector<Integer> sums = new Vector<Integer>();
		for(int i = 0; i < BIN.elementAt(binIndex).lastElement().size(); i++)
		//i = BIN(binIndex) columns
		{
			for(int j = 0; j < minRows.size(); j++)
			{
				mySum += BIN.elementAt(binIndex).elementAt(minRows.elementAt(j)).get(i);
			}
			if(mySum > bestSum)
			{
				bestSum = mySum;
			}
			sums.add(mySum);
			//don't forget to reset mySum!
			mySum = 0;

		}

		log("getMaxColumns: minRows = " + minRows.toString());
		int maxCol = sums.indexOf(bestSum);
		log("getMaxColumns: maxCol  = " + maxCol);
		Vector<Integer> maxCols = new Vector<Integer>();
		maxCols.add(maxCol);
		for(int i = 0; i < BIN.lastElement().size(); i++)
		{
			if(i == maxCol)
			{
				maxCol = sums.indexOf(bestSum, maxCol+1);
				
				if(maxCol > -1)
				{
					maxCols.add(maxCol);
				}
			}
		}

		return maxCols;
	}
	
	private static Vector<Integer> getMinRows(int binIndex, Vector<Integer> inactive) throws IOException
	{
		Vector<Integer>    sums = new Vector<Integer>();
		Vector<Integer> minRows = new Vector<Integer>();
		
		int   mySum = 0;
		//the most best sum could possible be is equal to the number of columns in a row
		int bestSum = BIN.lastElement().lastElement().size();
		for(int i = 0; i < BIN.elementAt(binIndex).size(); i++)
		//i = BIN binIndex row
		{
			if(inactive.isEmpty() || !inactive.contains(i))
			{
				for(int j = 0; j < BIN.elementAt(binIndex).elementAt(i).size(); j++)
				//j = BIN binIndex column
				{
					mySum += BIN.elementAt(binIndex).elementAt(i).elementAt(j);
				}
		
				if(bestSum > mySum && mySum > 0)
				{
					bestSum = mySum;
				}
			}
			sums.addElement(mySum);

			//don't forget to reset mySum!
			mySum = 0;
		}

		int minRow = sums.indexOf(bestSum);
		while(minRow != -1)
		{
			minRows.add(minRow);
			minRow++;
			minRow = sums.indexOf(bestSum, minRow);
		}
		return minRows;
	}
	
 	private static void initializeBIN(int binIndex, int posMatrix, int negMatrix, int negRow) throws IOException
	{
 		log("initializeBIN: Creating BIN for POS " + posMatrix + " and NEG " + negRow);
		for(int i = 0; i < POS.elementAt(posMatrix).size(); i++)
		{
			BIN.elementAt(binIndex).add(new Vector<Integer>());
			for(int j = 0; j < POS.elementAt(posMatrix).elementAt(i).size(); j++)
			{
				if(POS.elementAt(posMatrix).elementAt(i).elementAt(j) ==
				   NEG.elementAt(negMatrix).elementAt(negRow).elementAt(j))
				{
					BIN.elementAt(binIndex).elementAt(i).add(0);
				}
				else
				{
					BIN.elementAt(binIndex).elementAt(i).add(1);
				}
			}
			log(BIN.elementAt(binIndex).elementAt(i).toString());
		}
		
		//clean the bin of rows that contain only zeros
		for(int i = 0; i < BIN.elementAt(binIndex).size(); i++)
		{
			if(!BIN.elementAt(binIndex).elementAt(i).contains(1))
			{
				BIN.elementAt(binIndex).remove(i);
			}
		}
	}
 	
	private static String generateRule(int binMatrix, int iteration) throws IOException
	{
		String myRule = "";
		log("generateRule: SOL = " + SOL.elementAt(binMatrix));
		log("generateRule: negMatrix = " + binMatrix);

		for(int i = 0; i < NEG.elementAt(binMatrix).size(); i++)
		{
			log(NEG.elementAt(binMatrix).elementAt(i).toString());
		}
		
		for(int j = 0; j < SOL.elementAt(binMatrix).size(); j++)
		//SOL(i) column = NEG orig col
		{
			if(SOL.elementAt(binMatrix).elementAt(j) == 1)
			{
				for(int l = 0; l < NEG.elementAt(binMatrix).size(); l++)
				//l = NEG orig row
				{
					if(BIN.elementAt(binMatrix).elementAt(l).elementAt(j) == 1)
					{
						String strTemp = j + "," + NEG.elementAt(binMatrix).elementAt(l).elementAt(j) + ",";
						if(!myRule.contains(strTemp))
						{
							log("generateRule: adding rule *" + NEG.elementAt(binMatrix).elementAt(l).elementAt(j) + "*");
							myRule += j + "," + NEG.elementAt(binMatrix).elementAt(l).elementAt(j) + ",";
						}
					}
				}
			}
		}
		
		myRule += iteration;
		return myRule;
	}
	
	private static void solveSCProblem(int binIndex) throws IOException
	{
		Vector<Integer> inactiveRows = new Vector<Integer>();

		SOL.add(new Vector<Integer>());
		
		for(int i = 0; i < BIN.elementAt(binIndex).lastElement().size(); i++)
		{
			SOL.lastElement().add(0);
		}
		
		while(inactiveRows.size() < BIN.elementAt(binIndex).size())
		{
			Vector<Integer> minRows = getMinRows(binIndex, inactiveRows);
			log("solveSCProblem: minRows = " + minRows);
			Vector<Integer> maxCols = getMaxColumns(binIndex, minRows);
			log("solveSCProblem: maxCols = " + maxCols);
			Vector<Integer> maxMaxCols = getMaxMaxColumns(binIndex, inactiveRows, maxCols);
			log("solveSCProblem: maxMaxCols = " + maxMaxCols);

			//int solPos = maxCols.elementAt(0);
			int solPos = maxMaxCols.elementAt(0);
			//if there was more than one possible solution
			/*if(maxCols.size() > 1)
			{
				Vector<Integer> inactiveMinRows = findInactiveMinRows(minRows, binIndex);
				
				Vector<Integer> sums = new Vector<Integer>();
				logBIN();
				//set bestSum to max number of rows in BIN
				int bestSum = BIN.lastElement().size();
				int mySum   = 0;
				for(int i = 0; i < maxCols.size(); i++)
				{
					for(int j = 0; j < inactiveMinRows.size(); j++)
					{
						mySum += BIN.elementAt(binIndex).elementAt(inactiveMinRows.elementAt(j)).elementAt(maxCols.get(i));
					}
					if(bestSum > mySum)
					{
						bestSum = mySum;
					}
					sums.add(mySum);
					mySum = 0;
				}
				inactiveMinRows.clear();
				int index = sums.indexOf(bestSum); 
				solPos = maxCols.elementAt(index);
			}*/
		
			SOL.lastElement().set(solPos, 1);
			log("-----Solve");
			log("       " + SOL.lastElement().toString());
			inactiveRows.addAll(findInactiveRows(binIndex));
		}
		
		logSOL();
	}
	
	private static Vector<Integer> getMaxMaxColumns(int binIndex, Vector<Integer> inactive, Vector<Integer> maxCols) throws IOException
	{
		Vector<Integer> maxMax = new Vector<Integer>();
		Vector<Integer> sums = new Vector<Integer>();
		log("getMaxMaxColumns: sums initialized = " + sums);
		int sum = 0;
		int bestSum = 0;
		
		for(int j = 0; j < maxCols.size(); j++)
		// maxCol.elementAt(j) = the columns we want to check
		{
			for(int i = 0; i < BIN.elementAt(binIndex).size(); i++)
			// i = BIN row
			{
				if(!inactive.contains(i))
				//we only want to check active rows
				{
					sum += BIN.elementAt(binIndex).elementAt(i).get(maxCols.elementAt(j));
				}
			}
			log("getMaxMaxColumns: sum = " + sum);
			if(sum > bestSum)
			{
				bestSum = sum;
			}
			sums.add(sum);
			sum = 0;
		}
		
		log("getMaxMaxColumns: sums = " + sums);
		log("getMaxMaxColumns: bestSum = " + bestSum);
		int index = sums.indexOf(bestSum);
		while(index != -1)
		{
			maxMax.add(maxCols.get(index));
			index = sums.indexOf(bestSum, index + 1);
		}
		log("getMaxMaxColumns: maxMax = " + maxMax.toString());
		log("getMaxMaxColumns: inactive = " + inactive);
		
		if(maxMax.size() > 1 && inactive.size() > 0)
		{
			sum = 0;
			bestSum = inactive.size();
			sums.clear();
			sums = new Vector<Integer>();
			int row = 0;
			for(int j = 0; j < maxMax.size(); j++)
			{
				for(int i = 0; i < inactive.size(); i++)
				{
					row = inactive.get(i);
					sum += BIN.elementAt(binIndex).elementAt(row).get(maxMax.elementAt(j));
				}
				
				sums.add(sum);
				if(sum < bestSum)
				{
					bestSum = sum;
				}
				sum = 0;
			}
			
			index = sums.indexOf(bestSum);
			int tempMaxMax = maxMax.elementAt(index);
			log("getMaxMaxColumns: sums  = " + sums.toString());
			log("getMaxMaxColumns: index = " + index);
			maxMax.clear();
			maxMax = new Vector<Integer>();
			maxMax.add(tempMaxMax);
		}
		return maxMax;
	}
	
	private static void logBIN() throws IOException
	{
		log("-- BIN");
		String myLogString = "  ";
		for(int i = 0; i < BIN.size(); i++)
		{
			for(int j = 0; j < BIN.elementAt(i).size(); j++)
			{
				for(int k = 0; k < BIN.elementAt(i).elementAt(j).size(); k++)
				{
					myLogString += BIN.elementAt(i).elementAt(j).elementAt(k) + ",";
				}
				log(myLogString);
				myLogString = "  ";
			}
		}
	}
	
	private static void logPOS() throws IOException
	{
		String myLogString = "";
		for(int i = 0; i < POS.size(); i++)
		{
			log("-- POS " + i);
			for(int j = 0; j < POS.elementAt(i).size(); j++)
			{
				for(int k = 0; k < POS.elementAt(i).elementAt(j).size(); k++)
				{
					myLogString += rules.elementAt(k).get(POS.elementAt(i).elementAt(j).get(k)-1) + ",";
				}
				log(myLogString);
				myLogString = "";
			}
		}
	}
	
	private static void logNEG() throws IOException
	//Logs entire collection of NEG matrices
	{
		String myLogString = "";
		log("-- NEG");
		for(int h = 0; h < NEG.size(); h++)
		{
			if(h == 0)
			{
				for(int i = 0; i < NEG.elementAt(h).size(); i++)
				{
					for(int j = 0; j < NEG.elementAt(h).elementAt(i).size(); j++)
					{
						myLogString += rules.elementAt(j).get(NEG.elementAt(h).elementAt(i).elementAt(j)-1) + ",";
					}
					log(myLogString);
					myLogString = "";
				}
			}
			else
			{
				for(int i = 0; i < NEG.elementAt(h).size(); i++)
				{
					log(NEG.elementAt(h).elementAt(i).toString());
				}
				log("");
			}
		}
	}
	
	private static void logNEG(int negMatrix, int i) throws IOException
	//logs the selected matrix at the selected row
	{
		String myLogString = "";
		log("-- NEG instance " + i);
		
		for(int j = 0; j < NEG.elementAt(negMatrix).elementAt(i).size(); j++)
		{
			myLogString += rules.elementAt(j).get(NEG.elementAt(negMatrix).elementAt(i).elementAt(j)-1) + ",";
		}
		log(myLogString);
	}
	
	private static void logPOS(int i) throws IOException
	{
		String myLogString = "";
		log("-- POS " + i);
		
		for(int k = 0; k < POS.elementAt(i).size(); k++)
		{
			for(int j = 0; j < POS.elementAt(i).elementAt(k).size(); j++)
			{
				myLogString += rules.elementAt(j).get(POS.elementAt(i).elementAt(k).elementAt(j)-1) + ",";
			}
			log(myLogString);
			myLogString = "";
		}
	}
	
	private static void logSOL() throws IOException
	{
		log("-- SOL");
		for(int i = 0; i < SOL.size(); i++)
		{
			log(SOL.elementAt(i).toString());
		}
	}
	
	private static void processFile(String filename) throws IOException
	{
		Scanner scan = new Scanner(new File(filename));
		String[] myLine;
		int lineNumber = 0;
		int dataLine   = 0;
		int dataValue  = 0;

		rules.add(new Vector<String>());
		while(scan.hasNext())
		{
			if(lineNumber == 1)
			{
				myLine = (scan.nextLine()).split(",");
				lineNumber++;
				for(int i = 0; i < myLine.length; i++)
				{
					theFeatures.add(myLine[i].trim());
				}
				continue;
			}
			else if(lineNumber < START)
			{
				lineNumber++;
				scan.nextLine();
				continue;
			}
			myLine = (scan.nextLine()).split(",");

			//initialize uniqueString two-dimensional Vector
			dataSet.add(new Vector<Integer>());
			for(int i = 0; i < myLine.length; i++)
			{
				if(rules.size() <= i)
				{
					rules.add(new Vector<String>());
				}
				//add uniqueStrings where applicable
				if(rules.elementAt(i).isEmpty() ||
				   !rules.elementAt(i).contains(myLine[i].trim().toLowerCase()))
				{
					rules.elementAt(i).add(myLine[i].trim().toLowerCase());
				}
				
				//get the index associated with the string found in uniqueStrings
				dataValue = rules.elementAt(i).indexOf(myLine[i].trim().toLowerCase());
				if(i != myLine.length - 1)
				{
					dataSet.elementAt(dataLine).add(dataValue+1);
				}
				else
				{
					classifier.add(dataValue+1);
				}
			}

			lineNumber++;
			dataLine++;
		}
	}

	private static void prunePOSmatrices(int NoiseThreshold) throws IOException
	//prune matrices that have less than rows than the NoiseThreshold specified
	{
		log("prunePOSmatrices: Begin pruning POS matrices with NOISETHRESHOLD = " + NoiseThreshold);
		boolean prune = false;
		for(int i = 1; i < POS.size(); i++)
		{
			if(POS.elementAt(i).size() < NoiseThreshold)
			{
				prune = true;
				log("prunePOSmatrices: Pruning POS matrix " + i);
				POS.remove(i);
				//need to decrement the loop counter
				log("prunePOSmatrices: decrementing PRUNE loop counter by one");
				i--;
			}
		}
		
		if(!prune)
		{
			log("prunePOSmatrices: No POS matrices to prune");
		}
		
		log("prunePOSmatrices: finished pruning");
		logPOS();
	}
	
	private static void reinitBIN(int matrixStart) throws IOException
	{
		BIN.add(new Vector<Vector<Integer>>());
		int columns = POS.size() - matrixStart;
		for(int i = 0; i < POS.elementAt(0).size(); i++)
		//number of rows = number of orig POS rows
		{
			BIN.lastElement().add(new Vector<Integer> ());
			for(int j = 0; j < columns; j++)
			//number of columns = number of POS matrices
			{
				BIN.lastElement().elementAt(i).add(0);
			}
		}
		log("reinitBIN: begin searching for positive entries based on POS matrices");
		int colCount = 0;
		//for(int i = 0; i < BIN.lastElement().lastElement().size(); i++)
		// i = BIN column
		{
			for(int m = matrixStart; m < POS.size(); m++)
			{
				for(int j = 0; j < POS.elementAt(0).size(); j++)
				//j = row for orig POS
				{
					for(int k = 0; k < POS.elementAt(m).size(); k++)
					//k = row for POS m
					{
						for(int l = 0; l < POS.elementAt(m).elementAt(k).size(); l++)
						//l = column index
						{
							if(POS.elementAt(0).elementAt(j).elementAt(l) ==
							   POS.elementAt(m).elementAt(k).elementAt(l))
							//if the element for POS i at (j,k) equals the
							//element for orig POS at (j,k)
							{
								//we have a match
								colCount++;
							}
							else
							{
								break;
							}
						}
						if(colCount == POS.elementAt(m).elementAt(k).size())
						//if the number of columns matched == total number of columns
						{
							//we have a row that matches
							BIN.lastElement().elementAt(j).set(m - matrixStart, 1);
						}
						colCount = 0;
					}
				}
			}
		}
		logBIN();
	}
	
	private static int removeCoveredPOSInstances(String theRule) throws IOException
	//removes rows from the original POS matrix that are covered by theRule
	{
		boolean remove = true;
		int column = 0;
		int value  = 0;
		int instancesRemoved = 0;
		String[] ruleBreakDown = theRule.split("[,:]");

		log("removedCoveredPOSInstances: origSize = " + POS.elementAt(0).size());
		for(int k = 0; k < POS.elementAt(0).size(); k++)
		//k = orig POS row
		{
			for(int j = 0; j < ruleBreakDown.length - 1; j += 2)
			{
				column = Integer.parseInt(ruleBreakDown[j]);
				value  = Integer.parseInt(ruleBreakDown[j+1]);

				if(POS.elementAt(0).elementAt(k).elementAt(column) == value)
				{
					remove = false;
					break;
				}
			}
			
			if(remove)
			{
				instancesRemoved ++;
				log("removeCoveredPOSInstances: removing row " + k);
				POS.elementAt(0).remove(k);
				k--;
			}
			remove = true;
		}
		
		return instancesRemoved;
	}
	
	private static void removeRedundantMatrices(int currentMatrix, int matrixLimit) throws IOException
	//removes matrices in the POS matrix set according to POS(matrixIndex)
	{
		if(currentMatrix == matrixLimit)
		{
			return;
		}

		log("removeRedundantMatrices: Begin removing POS matrices according to POS " + currentMatrix);
		
		int columnSimilarityCount = 0;
		int rowSimilarityCount    = 0;
		for(int i = matrixLimit; i < POS.size(); i++)
		{
			if(i != currentMatrix)
			{
				for(int j = 0; j < POS.elementAt(i).size(); j++)
				//j = POS row
				{
					for(int k = 0; k < POS.elementAt(i).elementAt(j).size(); k++)
					{
						for(int l = 0; l < POS.elementAt(currentMatrix).size(); l++)
						//l = current POS row
						{
							if(POS.elementAt(i).elementAt(j).elementAt(k) ==
							   POS.elementAt(currentMatrix).elementAt(l).elementAt(k))
							{
								columnSimilarityCount++;
							}
						}
						
						if(columnSimilarityCount == POS.elementAt(i).elementAt(j).size())
						//if all column values are the same
						{
							rowSimilarityCount++;
							
							if(rowSimilarityCount == POS.elementAt(currentMatrix).size())
							//if all rows are found
							{
								log("removeRedundatnMatrices: remove POS " + currentMatrix);
								POS.remove(currentMatrix);
								logPOS();
								return;
							}
						}
						columnSimilarityCount = 0;
					}
				}
			}
		}
	}
}
