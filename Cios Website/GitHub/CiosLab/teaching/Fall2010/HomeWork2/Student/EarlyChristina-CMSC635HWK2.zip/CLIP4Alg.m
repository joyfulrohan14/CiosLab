%CLIP4 function implemented in support of homework assignment 2 for
%CMSC 635
%Christina Early
%Turned in on 11/18/2010

%The following variables need to be set based on which data set is loaded
%Note that the Iris Data Set must have the text labels above the first data
%line removed and the class names replaced with numbers.  For the 
%iris data set the following class to number mapping has been used
%setosa = 1 versicolor = 2 virginica = 3
%and the Heart Data Set must have the text labels above the
%first data set removed as well as all the string values
%S is number of classes, assuming same number of entries per class

function [textResults] = CLIP4Alg(dataSet, classValue)

switch dataSet
    case 1
        filename = 'Iris-DS-H2PreProcessed.txt';
        file_format = '%f, %f, %f, %f, %f';   %Iris Dataset
        attributes = 5;
        classNames = ['Iris-setosa    '; 'Iris-versicolor'; 'Iris-virginica '];   %setosa = 1 versicolor = 2 virginica = 3
        attributeNames = ['sepallength '; 'sepalwidth  '; 'petallength '; 'petalwidth  '; 'classname   '];
        attributeEnum = ['[4.3-5.55] '; '(3.05-4.4] '; '[1-2.45]   '; '[0.1-0.8]  '; '(5.55-6.25]'; '(2.95-3.05]'; '(2.45-4.75]'; '(0.8-1.75] '; '(6.25-7.9] '; '[2-2.95]   '; '(4.75-6.9] '; '(1.75-2.5] '];
    case 2
        filename = 'Travel-DS-H2PreProcessed.txt';
        file_format = '%f, %f, %f, %f, %f';   %Iris Dataset
        attributes = 5;
        classNames = ['Buy    '; 'Not buy'];   %Buy = 1 Not buy = 2 
        attributeNames = ['Type of Call'; 'Lang Fluency'; 'Ticket Type '; 'Age         '; 'Decision    '];
        attributeEnum = ['Local     '; 'Fluent    '; 'Long      '; 'Very young'; 'Intern    '; 'Not Fluent'; 'Short     '; 'Old       '; 'NA        '; 'Foreign   '; 'NA        '; 'Middle    '; 'NA        '; 'Accent    '; 'NA        '; 'Very old  '; 'NA        '; 'NA        '; 'NA        '; 'Young     '];
    case 3
        filename = 'weather-DS-H2PreProcessed.txt';
        file_format = '%f, %f, %f, %f, %f';   %Iris Dataset
        attributes = 5;
        classNames = ['no '; 'yes'];   %no = 1 yes = 2 
        attributeNames = ['outlook    ';'temperature';'humidity   ';'windy      ';'play       '];
        attributeEnum = ['sunny   ';'hot     ';'high    ';'FALSE   '; 'overcast'; 'mild    '; 'normal  '; 'TRUE    '; 'rainy   '; 'cool    '; 'NA      '; 'NA      ' ];
end


fid = fopen(filename);  %Opens the specified file
a = fscanf(fid,file_format, [attributes inf]);    %Read the attributes into an array
data = a';
%data = [1 2 3 * 1;1 3 1 2 1;* 3 2 5 1;3 3 2 2 1;1 1 1 3 1;3 1 2 5 2;1 2 2 4 2;2 1 * 3 2];
%data = [1 2 3 0 1;1 3 1 2 1;0 3 2 5 1;3 3 2 2 1;1 1 1 3 1;3 1 2 5 2;1 2 2 4 2;2 1 0 3 2];
%data = [1 1 3 1 1;1 1 1 4 1; 2 3 2 5 1; 3 2 3 5 1; 1 1 2 3 1; 1 3 2 1 2; 3 1 2 3 2;3 4 3 2 2; 1 3 3 4 2];
%Assumption is that class is last column
%N;  %Variable ?array or matrix? that needs populated
%numAttributes;  %Number of Attributes.  Referred to as "K" in the pseudocode
%pos;    %Matrix of the positive examples;  Rows represent examples;  columns attributes

%neg;    %Matrix of the negative examples;  Rows represent examples;  columns attributes
noiseThreshold = 10;
stopThreshold = 10;
%i;  % row number also known as example number
%j;  % column number also known as attribute number
%classValue = 1; %Classification Value to cause a positive
classAttribute = 5; %Column containing the classification data
%data;   %Matrix of data;  Rows represent examples;  columns attributes
[numExamples, numAttributes] = size(data);  %Total number of examples or rows in the data set
posIndex = 1;
negIndex = 1;
%fullPOS;
%fullNEG;
for z = 1:numExamples 
    if (data(z,classAttribute) == classValue)            
        fullPOS(posIndex,:) = data(z,:);
        posIndex = posIndex + 1;
    else 
        fullNEG(negIndex,:) = data(z,:);
        negIndex = negIndex + 1;
    end
end
fullPOS(:,classAttribute) = [];
fullNEG(:,classAttribute) = [];
numAttributes = numAttributes - 1;

nPOS = size(fullPOS, 1);   %Number of positive examples
nNEG = size(fullNEG, 1);   %Number of negative examples

pos(:,:,1,1) = fullPOS;
neg = fullNEG;
N(1) = 1;  %Create POS(0,1) consisting of entire Sp;  Create NEG(0,1) consisting of entire SN //INITIALIZE
for i = 1 : nNEG                                %PHASE I STARTS
    neg(i,:);  %Print out the row of the Neg matrix being examined
    for j = 1 : size(pos(1,1,i,:),4)           %for each POSi-1,j matrix
        for k = 1: numAttributes               %create new BINj matrix
            for l = 1:nPOS     %to number of POSi-1,j rows do
                if pos(l,k,i,j) == neg(i,k) 
                    bin(l,k,j) = 0;
                elseif pos(l,k,i,j) ~= neg(i,k)
                    bin(l,k,j) = 1;
                else                           %missing value encountered in pos or neg matrices;  does this need done earlier?  isnull check?
                    bin(l,k,j) = 0;
                end
            end
        end

        SOL(:,j) = SolveSCProblem(bin(:,:,j));
    end
    %    PruneMatrices(pos(i-1,j),SOL(j), j = 1. . . N(i-1));
    %Remove Redundancy
    numJs = size(SOL,2);
    for q = 1:numJs
            for r = q:numJs
                    if (numJs >= q & numJs >= r)
                        if (SOL(:,q) == SOL(:,numJs - r + q))
                            if(q ~= (numJs - r + q))
                                SOL(:,numJs - r + q) = [];
                                pos(:,:,:,numJs - r + q) = [];
                                numJs = numJs - 1;
                            end
                        end
                    end
             end

    end

     %   ApplyGeneticOperators(pos(i-1,j),SOL(j),j=1,...N(i-1));
        N(i+1) = 1;                               %counter for POSi+1 matrices
        sizeNi = 1;
        for j = 1:size(pos(1,1,i,:),4)             %for each POSi,j matrix
 %           if pos(i-1,j) was not pruned or redundant
                for k=1:numAttributes             %through entire solution vector
                    if SOL(k,j) == 1              %then create new POSi,Ni matrix
                            for l = 1:nPOS
                                if (pos(l,k,i,j) ~= neg(i,k)) 
                                    pos(l,:,i+1,sizeNi) = pos(l,:,i,j);
                                end
                            end
                             %pos(:,:,i+1,sizeNi)       %Print new leaf
                             sizeNi = sizeNi + 1;
                    end

                end
             N(i+1) = N(i+1) + 1;
  %          end
        end

             for j = 1 : N(i)       %for each POSi matrix check if it large enough to be not considered as a noise
%                   if size(pos(:,:,i,j),1) < noiseThreshold    %input
%                   currently exceeding matrix dimensions
%                     pos(:,:,i,j) = [];     %Wants only one non-colon index
 %                    N(i) = N(i) - 1;
             %    end
             end           
                     %EliminateRedundantMatrices(POS(i,j) j=1,...N(i));
end
                 
    %PHASE II STARTS
    nNEGPII = size(pos,4);
    binPII = zeros(nPOS,nNEG);  %Create BIN matrix that consist of NNNEG columns and NPOS rows,and fill with zeros
    for i = 1:nNEGPII          %for all tree leaves
        for j = 1:nPOS
            for k = 1:nPOS      %to number of rows of POSnNEG,i 
                if (pos(j,:,1,1) == pos(k,:,nNEG + 1,i))
                    binPII(j,i) = 1;
                end
            end
        end
    end
    solPII = SolveSCProblem(binPII);
    
    for i = 1:nNEGPII
        binNEG(:,:,i) = neg;
        if solPII(i) == 1
            for j=1:numAttributes
                for k=1:nNEG
                    if neg(k,j) == '*'
                        binNEG(k,j, i) = 0;
                    else
                        for l=1:nPOS
                            if pos(l,j,nNEG+1,i) == neg(k,j)
%                                bin(k,j,i) = 0;
                                binNEG(k,j,i) = 0;
                            end
                        end
                    end
                end
            end

            for j = 1:numAttributes         %convert BIN i values to binary
                for k = 1:nNEG
                  %  if bin(k,j,i) ~= 0
                    if binNEG(k,j,i) ~= 0
%                        bin(k,j,i) = 0
                        binNEG(k,j,i) = 1;
                    end
                end
            end
            solRule(:,i) = SolveSCProblem(binNEG(:,:,i));
            numSelectors = 0;
            for j = 1:numAttributes
                if solRule(j,i) == 1
                    for k=1:nNEG
                        if binNEG(k,j,i) == 1
   %                         add "aj <> negkj selector to the Rule i
                            numSelectors = numSelectors + 1;
                            aTemp(numSelectors,i) = j;
                            v(j,numSelectors,i) = neg(k,j);

                        end
                    end
                end
            end
        end
     
    end
    

 
        %PHASE III START
        bestNumCovered = 0;
        blankRow = zeros(1,numAttributes);
        prevBestNumCovered = 0;
%%%        while bestNumCovered >= 0
            for i = 1:nNEGPII
                covers(i) = nPOS;
                a = unique(aTemp(:,i));
                numSelectors = size(a,1);
                coveredByRule(:,:,i) = pos(:,:,1,1);
                for j = 1:nPOS
                    for k = 1:numAttributes
                        for l = 1:numSelectors      %number of selectors in rule
                            if (a(l) == k && size(find (v(k,:,i) == pos(j,k,1,1)),2) > 0)
                                    covers(i) = covers(i) - 1;
                                    coveredByRule(j,:,i) = blankRow;
                                  %  j = j + 1;
                            end
                        end
                    end
                end
                if bestNumCovered < covers(i) 
                    bestNumCovered = covers(i);
                    best_rule = v(:,:,i);       %Rule(i);
                    rule_num = i;
                end 
            end
            nPOS = nPOS - bestNumCovered;
            if ((nPOS < stopThreshold) || nPOS == 0)
                %STOP
            end
           % POS(0,1) = POS(0,1) - examples covered by best_rule;
%%%            if (bestNumCovered < prevBestNumCovered/2 && bestNumCovered < nPOS/2)
%%%                bestNumCovered = -1;        %multiple rules
%%%            end
            prevBestNumCoveredExamples = coveredByRule(:,:,rule_num);       %prevBestNumCoveredExamples = bestNumCoveredExamples;
           for r = 1:size(v,3)
               if r == 1
                    textResults = char(sprintf('If '));
               else
                   textResults = char(textResults, sprintf('If '));
               end
            andNeeded = 0;
            for i = 1:numAttributes
                 if (solRule(i,r) == 1)
                    tempRuleValue = nonzeros(unique(v(i,:,r)));
                
              %  if (solRule(i,rule_num) == 1)
              %      tempRuleValue = nonzeros(unique(v(i,:,rule_num)));
                    for j = 1:(size(tempRuleValue,1))
                        if andNeeded > 0 
                            textResults = char(textResults, sprintf(' and '));
                        end
                        sprintf('F%d not equal to %d',i,tempRuleValue(j));
                        textResults = char(textResults, sprintf('%s not equal to %s', attributeNames(i,:), attributeEnum(i + (attributes-1)*(tempRuleValue(j)-1),:)));
                        andNeeded = andNeeded + 1;
                    end
                end
            end
            textResults = char(textResults, sprintf(' ==> %s\n',classNames(classValue,:)));
           end
%%%        end
end
                