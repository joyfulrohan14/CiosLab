function varargout = Clip4wGUI(varargin)
% CLIP4WGUI M-file for Clip4wGUI.fig
%      CLIP4WGUI, by itself, creates a new CLIP4WGUI or raises the existing
%      singleton*.
%
%      H = CLIP4WGUI returns the handle to a new CLIP4WGUI or the handle to
%      the existing singleton*.
%
%      CLIP4WGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CLIP4WGUI.M with the given input arguments.
%
%      CLIP4WGUI('Property','Value',...) creates a new CLIP4WGUI or raises
%      the existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Clip4wGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Clip4wGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Clip4wGUI

% Last Modified by GUIDE v2.5 18-Nov-2010 21:49:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Clip4wGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @Clip4wGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Clip4wGUI is made visible.
function Clip4wGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Clip4wGUI (see VARARGIN)

% Choose default command line output for Clip4wGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

initialize_gui(hObject, handles, false);

% UIWAIT makes Clip4wGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Clip4wGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function volume_CreateFcn(hObject, eventdata, handles)
% hObject    handle to volume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in calculate.
function calculate_Callback(hObject, eventdata, handles)
% hObject    handle to calculate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (hObject == handles.TravelBuy)
    set(handles.text4, 'String', CLIP4Alg(2,1));
elseif (hObject == handles.TravelNobuy)
        set(handles.text4, 'String', CLIP4Alg(2,2));
elseif (hObject == handles.IrisSetosa)
    set(handles.text4, 'String', CLIP4Alg(1,1));
elseif (hObject == handles.IrisVersicolor)
    set(handles.text4, 'String', CLIP4Alg(1,2));
elseif (hObject == handles.IrisVirginica)
    set(handles.text4, 'String', CLIP4Alg(1,3));
elseif (hObject == handles.WeatherNo)
    set(handles.text4, 'String', CLIP4Alg(3,1));
elseif (hObject == handles.WeatherYes)
    set(handles.text4, 'String', CLIP4Alg(3,2));
end

% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

initialize_gui(gcbf, handles, true);

% --- Executes when selected object changed in unitgroup.
function unitgroup_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in unitgroup 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (hObject == handles.TravelBuy)
    set(handles.text4, 'String', CLIP4Alg(2,1));
elseif (hObject == handles.TravelNobuy)
        set(handles.text4, 'String', CLIP4Alg(2,2));
elseif (hObject == handles.IrisSetosa)
    set(handles.text4, 'String', CLIP4Alg(1,1));
elseif (hObject == handles.IrisVersicolor)
    set(handles.text4, 'String', CLIP4Alg(1,2));
elseif (hObject == handles.IrisVirginica)
    set(handles.text4, 'String', CLIP4Alg(1,3));
elseif (hObject == handles.WeatherNo)
    set(handles.text4, 'String', CLIP4Alg(3,1));
elseif (hObject == handles.WeatherYes)
    set(handles.text4, 'String', CLIP4Alg(3,2));
end

% --------------------------------------------------------------------
function initialize_gui(fig_handle, handles, isreset)
% If the metricdata field is present and the reset flag is false, it means
% we are we are just re-initializing a GUI by calling it from the cmd line
% while it is up. So, bail out as we dont want to reset the data.
if isfield(handles, 'metricdata') && ~isreset
    return;
end

set(handles.unitgroup, 'SelectedObject', handles.WeatherYes);

set(handles.text4, 'String', '');

% Update handles structure
guidata(handles.figure1, handles);


% --- Executes on selection change in buy.
function buy_Callback(hObject, eventdata, handles)
% hObject    handle to buy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns buy contents as cell array
%        contents{get(hObject,'Value')} returns selected item from buy

% --- Executes during object creation, after setting all properties.
function buy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to buy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3


% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


