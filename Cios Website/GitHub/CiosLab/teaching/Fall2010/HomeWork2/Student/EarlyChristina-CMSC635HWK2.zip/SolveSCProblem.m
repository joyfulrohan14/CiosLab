%CLIP4 method for solving the SC problem
%implemented by Christina Early
%November 2010


function [SOL] = SolveSCProblem(BIN)
numRows = size(BIN,1);
SOL = zeros(size(BIN,2),1);
activeRows = ones(numRows,1);
%Given:  Binary matrix, Initialize:  Remove all empty rows from the Binary
%matrix;  if the matrix has no 1's then return error
%if (find(BIN))
    noZeroRowsBIN = BIN;
    noZeroRowsBIN(~any(BIN,2),:)=[];
    activeRows(~any(BIN,2)) = 0;
    while (find(activeRows,1))
    %Step 1 Select rows that have the minimimum number of 1's
        rowSums = sum(noZeroRowsBIN,2);
        minOnes = min(rowSums);
        index = 1;
        min_rows = [];  %Empty this temporary matrix
        for i = 1:size(rowSums)
            if (rowSums(i) == minOnes)
                min_rows(index,:) = noZeroRowsBIN(i,:);
                index = index + 1;
            end
        end
        %Step 2 Select columns that have the max number of 1's within min row
        colSums = sum(min_rows,1);
        maxOnes = max(colSums);
        max_cols = min_rows;
        numCols = size(colSums,2);
          index = 1;
          index2 = 1;
          maxValue = 0;
          num_maxes = 0;
          maxMaxIndices = [];
          maxMaxIndices(1) = 0;
          maxColIndices = [];
        for i = 1:numCols
    %        if (colSums(numCols+1-i) ~= maxOnes)
     %           max_cols(:,numCols+1-i) = [];
      %      end

             if (colSums(i) == maxOnes)
                maxColIndices(index) = i;
                index = index + 1;  
        %Step 3 Within max_cols find columns that have the maximum number of
        %1's in all active rows - max-max-columns, if there is more than one
        %max-max-column go to 4;  otherwise go to 5

                if (maxValue < sum(noZeroRowsBIN(:,i)))
                    num_maxes = 1;
                    maxValue = sum(noZeroRowsBIN(:,i));
                    maxMaxIndices(:) = [];
                    index2 = 1;
                    maxMaxIndices(index2) = i;
                    index2 = index2 + 1;
                elseif (maxValue == sum(noZeroRowsBIN(:,i)))
                    num_maxes = num_maxes + 1;
                    maxMaxIndices(index2) = i;
                    index2 = index2 + 1;                 
                end

            end

        end

        if num_maxes > 1
        %Step 4  Within max-max-columns find the first column that has the
        %lowest number of 1's in the inactive rows.
            index = 1;
            for m = 1:size(activeRows)
                if (activeRows(m) == 0)
                    tempMatrix(index,:) = BIN(m,:);
                    index = index + 1;
                end
            end
            if (index > 1)
                minInactive = size(activeRows,1);
                for  p = 1:num_maxes
                    if(sum(tempMatrix(:,maxMaxIndices(p))) < minInactive)
                        selectedIndex = maxMaxIndices(p);
                        minInactive = sum(tempMatrix(:,maxMaxIndices(p)));
                    end
                end
            else
                selectedIndex = maxMaxIndices(1);
            end
        else
            selectedIndex = maxMaxIndices(1);    
        end

        %Step 5 Add the selected column to the solution
        SOL(selectedIndex) = 1;
        numActiveRows = size(noZeroRowsBIN,1);
        q = 1;
        for p = 1:numRows
            if (activeRows(numRows - p + 1) == 1)
                if (noZeroRowsBIN(numActiveRows - q + 1,selectedIndex) == 1)
                   noZeroRowsBIN(numActiveRows - q + 1,:) = [];
                   q = q + 1;
                   activeRows(numRows - p + 1) = 0;
                else
                    q = q+1;
                end
            end            
        end
        %Step 6 Mark the inactive rows, if all the rows are inactive then
        %terminate;  otherwise go to 1
    end
end
