function [Overall_rule] = CLIP4(POS,NEG,feature_names,feature_cell,Overall_rule) 
%% each row of negative matrix
    [row_NEG, col_NEG] = size(NEG);
    [row_POS, col_POS] = size(POS);
    NEG_vector = NEG(1,:);
    vector = [row_POS];
    N = 1;

    final_leafnode_matrix = [];
    final_leng_leafnode = [];
    [final_leafnode_matrix,final_leng_leafnode] = NEG_VECTOR3(POS,vector,N,NEG,NEG_vector, final_leafnode_matrix,final_leng_leafnode );    
    
    [TM_matrix,solution] = TM(POS,final_leafnode_matrix,final_leng_leafnode) ;
    
    if length(find(solution ~=1))~=0
        indices = find(solution ~=1);
        final_leng_leafnode_sum = zeros(1,length(final_leng_leafnode));
        for i = 1:length(final_leng_leafnode)
            final_leng_leafnode_sum(i) = sum(final_leng_leafnode(1:i));
        end
        final_leng_leafnode_sum = [0 final_leng_leafnode_sum];

        row_vector = 1:length(solution);
             [row_vector index]= setdiff(row_vector,indices);
         dataset = [];
         leave_vector = [];
         for i = 1:length(index)
            dataset = [dataset;final_leafnode_matrix(final_leng_leafnode_sum(index(i))+1:final_leng_leafnode_sum(index(i)+1),:)];
            leave_vector = [leave_vector final_leng_leafnode(index(i))];
         end

           final_leafnode_matrix = dataset; 
           final_leng_leafnode = leave_vector;
    end

    if length(final_leng_leafnode)~=0

        [solution,RULE,rule_matrix] = PROJNEG2(NEG,final_leafnode_matrix,final_leng_leafnode,POS,feature_names,feature_cell);
        RULE
        Overall_rule = {Overall_rule; RULE};
    [ro,co]= size(rule_matrix); 
        if ro>0
            CLIP4(rule_matrix,NEG,feature_names,feature_cell,Overall_rule);
        end
    else
        return;    %        mainleep();
    end
         
     
end