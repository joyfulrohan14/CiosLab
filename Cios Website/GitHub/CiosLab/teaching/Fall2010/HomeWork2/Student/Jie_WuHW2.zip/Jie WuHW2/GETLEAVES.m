function [solution,matrix_total,row_vector,N] = GETLEAVES(POS_submatrix,NEG_vector,N,NEG)
    [row_POS_submatrix, col_POS_submatrix] = size(POS_submatrix);
    [row_NEG, col_NEG] = size(NEG);
    BIN = zeros(row_POS_submatrix,col_POS_submatrix);
    for j = 1:row_POS_submatrix
        for k = 1: col_POS_submatrix         
            if POS_submatrix(j,k) == NEG_vector(k)           
                BIN(j,k) = 0;
            elseif POS_submatrix(j,k) ~= NEG_vector(k)
                BIN(j,k) = 1;
            elseif POS_submatrix(j,k) == '*'
                BIN(j,k) = 0;
            elseif POS_submatrix(i,k) == '*'
                BIN(j,k) = 0;
            end
        end
    end
    BIN;
    [solution] = cover_setting(BIN);
    indices = find(solution == 1);
%     N = N+1;
%% get leave_nodes and each row number

    matrix_total = [];
    row_vector = [];
    for j = 1:length(indices)
        nonequal_index = [];
        nonequal_index = find (NEG_vector(indices(j)) ~= POS_submatrix(:,indices(j)));
        submatrix = zeros(length(nonequal_index),col_POS_submatrix);
        for k = 1:length(nonequal_index)
            submatrix(k,:) = POS_submatrix(nonequal_index(k),:);
        end
        submatrix;
        [r,c] = size(submatrix);
        matrix_total = [matrix_total;submatrix];
        row_vector = [row_vector;r];
        
    end       
end