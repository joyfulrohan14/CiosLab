function [final_leafnode_matrix,final_leng_leafnode] = NEG_VECTOR3(total_submatrix,vector,N,NEG,NEG_vector,final_leafnode_matrix,final_leng_leafnode)
%% get the leave_nodes
    vector_sum = zeros(1,length(vector));
    for i = 1:length(vector)
        vector_sum(i) = sum(vector(1:i));
    end
    vector_sum = [0 vector_sum];
    leave_matrix = [];
    leave_vector = [];
    for i = 1:length(vector) 
    [solution,submatrix,leave,N] = GETLEAVES(total_submatrix((vector_sum(i)+1):vector_sum(i+1),:),NEG_vector,N,NEG);
    leave_matrix = [leave_matrix ; submatrix];
    leave_vector = [leave_vector ; leave];
    end

%% judge if the node is redundent    
     [redundent,row_vector,matrix_total] = REDUNDENT(leave_matrix,leave_vector);
    
%%  find the final leaf nodes

        [row_NEG,col_NEG]=size(NEG);
        if N == row_NEG 

        final_leafnode_matrix = matrix_total;
        final_leng_leafnode = row_vector;
        
        end
         final_leafnode_matrix;
         final_leng_leafnode;

%% if not the final leave nodes, IF should be continue or not              
        N = N+1;        
        if N<=row_NEG
            NEG_vector2 = NEG(N,:);   
            [final_leafnode_matrix,final_leng_leafnode] = NEG_VECTOR3(matrix_total,row_vector,N,NEG,NEG_vector2,final_leafnode_matrix,final_leng_leafnode);
        end
end