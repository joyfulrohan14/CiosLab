function [solution,rule2,rule_matrix] = PROJNEG2(NEG,POS_matrix,leave_index,POS,feature_names,feature_cell)
    [row,col] = size(NEG);  
    
%     leave_index = setdiff(1:row,leave_index(inde));
    leave_index_sum = zeros(1,length(leave_index));
    for i = 1:length(leave_index)
        leave_index_sum(i) = sum(leave_index(1:i));
    end
    leave_index_sum = [0 leave_index_sum];
%     [value inde] = max(leave_index);

for p = 1:length(leave_index)
    backproj_matrix = zeros(row,col);
    BIN_matrix = zeros(row,col);
    POS_matrix_i = POS_matrix((leave_index_sum(p)+1):leave_index_sum(p+1),:);
    for j = 1:col
        for k = 1:row
            if length(find(ismember(NEG(k,j),POS_matrix_i(:,j)) ==1 ))==0
                backproj_matrix(k,j) = NEG(k,j);
                BIN_matrix(k,j) = 1;
            end
        end
    end  
    backproj_matrix ;
    BIN_matrix;
    [solution] = cover_setting(BIN_matrix);
        indices = find(solution == 1);
%% get the rules and get the reduced POS matrix
         rule_matrix = []; 
         index_selection = [];
         rule = 'IF';
         rule2 = 'IF';
         for k = 1:length(indices)
            [value index] = unique(backproj_matrix(:,indices(k)));
            in = find(value~=0);
            for l = 1:length(in)
                rr = [' (F',num2str(indices(k)),' # ',num2str(backproj_matrix(index(in(l)),indices(k))),') AND'];
                rule = [rule, rr];
                feature_name = feature_names(indices(k));
                feature_name = cell2mat(feature_name);
                for o = 1:length(feature_cell)
                    fc = cell2mat(feature_cell{o}(1,1));
                    feature_name;
                    if strcmpi(fc,feature_name) == 1%length(find(ismember(fc,feature_name)))== length(feature_name)
%                         mm = length(find(ismember(feature_name,fc)));
%                         nn = length(feature_name);
                        for m = 2:length(feature_cell{o})                            
                            if length(find(feature_cell{o}{m,2} == backproj_matrix(index(in(l)),indices(k))))~=0
                                 a = feature_cell{o}{m,2};
                                 b = backproj_matrix(index(in(l)),indices(k));
%                                 r = ['(',feature_name,' # ',num2str(backproj_matrix(index(in(l)),indices(k))),') AND'];
                                  r = ['(',feature_name,' # ',feature_cell{o}{m,1},') AND'];
                                rule2 = [rule2, r];
                            end
                        end    
                    end
                    
                end   
                index_rule = find(POS(:,indices(k))'== backproj_matrix(index(in(l)),indices(k)));
                index_selection = [index_selection index_rule];
%                 if length(index_rule)~=0
%                     for i = 1:length(index_rule)
%                         rule_matrix = [rule_matrix ;POS(index_rule(i),:) ];
%                     end
%                 end
            end
         end
         
         index_selection = unique(index_selection);
         
         if length(index_selection)~=0
            for i = 1:length(index_selection)
                rule_matrix = [rule_matrix ;POS(index_selection(i),:) ];
            end
         end
         
         rule2((length(rule2)-3):length(rule2)) = [];

         label_name = feature_cell{1,length(feature_cell)}(1,1);
         index;
         for i = 2:length(feature_cell{1,length(feature_cell)})
            if length(find(feature_cell{1,length(feature_cell)}{i,2}==1))~=0
                index = i;
            end
         end
       
         rule2 = [rule2, 'THEN ',cell2mat(label_name),' = ',feature_cell{1,length(feature_cell)}{index,1}];
         rule;
end
end