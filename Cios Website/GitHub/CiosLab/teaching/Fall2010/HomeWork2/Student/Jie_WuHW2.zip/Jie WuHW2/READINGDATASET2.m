function [POS,NEG,feature_names,feature_cell,POS_label] = READINGDATASET2(path)

    data_original = importdata(path, ',', 1);
    feature_names = data_original.colheaders(1,:);
    feature_names(1,1);
    length(feature_names);
    data = data_original.data(1:end,:);
    disp ' '
    [row, col] = size(data);

    class = unique(data(:,col));
    data_temp = [];
    for i = 1:row
        for j = 1:col-1
            data_temp(i,j) = data(i,j);
        end
    end

    for i = 1:length(class)
        POS = [];
        NEG = [];
        POS_vector = [];
        for j = 1:row
            if data(j,col) == class(i)
                POS = [POS;data_temp(j,:)];
                POS_vector = [POS_vector j];
            end
        end
        
        NEG_vector = setdiff(1:row,POS_vector);
        for j = 1:length(NEG_vector)
            NEG = [NEG;data_temp(NEG_vector(j),:)];
        end
            POS = unique(POS,'rows');
            NEG = unique(NEG,'rows');
        if length(findstr(path,'Travel'))~=0 && class(i)==1

        feature1 = {'Type of Call',1;'Local',1;'Long',2;'Intern',3};
        feature2 = {'Lang Fluency',2;'Accent',2;'Fluent',1;'Foreign',4;'Not fluent',3};
        feature3 = {'Ticket Type',3;'Local',1;'Long',3;'Short',2};
        feature4 = {'Age',4;'Middle',3;'Old',4;'Very old',5';'Very young',1;'Young',2};
        label = {'Decision',5;'Buy',1;'Not buy',2};

        feature_cell = {feature1,feature2,feature3,feature4,label};
        
    elseif length(findstr(path,'Travel'))~=0 && class(i)==2
        
        feature1 = {'Type of Call',1;'Local',1;'Long',2;'Intern',3};
        feature2 = {'Lang Fluency',2;'Accent',2;'Fluent',1;'Foreign',4;'Not fluent',3};
        feature3 = {'Ticket Type',3;'Local',1;'Long',3;'Short',2};
        feature4 = {'Age',4;'Middle',3;'Old',4;'Very old',5';'Very young',1;'Young',2};
        label = {'Decision',5;'Not Buy',1;'Buy',2};

        feature_cell = {feature1,feature2,feature3,feature4,label};

    elseif length(findstr(path,'Weather'))~=0 && class(i)==1
        
        feature1 = {'outlook',1;'sunny',1;'overcast',2;'rainy',3};
        feature2 = {'temperature',2;'hot',1;'mild',2;'cool',3};
        feature3 = {'humidity',3;'high',1;'normal',2};
        feature4 = {'windy',4;'FALSE',1;'TRUE',2};
        label = {'play',5;'no',1;'yes',2};
        
        feature_cell = {feature1,feature2,feature3,feature4,label};
    
    elseif length(findstr(path,'Weather'))~=0 && class(i)==2
        
        feature1 = {'outlook',1;'sunny',1;'overcast',2;'rainy',3};
        feature2 = {'temperature',2;'hot',1;'mild',2;'cool',3};
        feature3 = {'humidity',3;'high',1;'normal',2};
        feature4 = {'windy',4;'FALSE',1;'TRUE',2};
        label = {'play',5;'yes',1;'no',2};
        
        feature_cell = {feature1,feature2,feature3,feature4,label};
        
    elseif length(findstr(path,'Iris'))~=0 && class(i)==1
        
        feature1 = {'sepallength',1;'[4.3-5.55]',1;'(5.55-6.25]',2;'(6.25-7.9]',3};
        feature2 = {'sepalwidth',2;'[2-2.95]',1;'(2.95-3.05]',2;'(3.05-4.4]',3};
        feature3 = {'petallength',3;'[1-2.45]',1;'(2.45-4.75]',2;'(4.75-6.9]',3};
        feature4 = {'petalwidth',4;'[0.1-0.8]',1;'(0.8-1.75]',2;'(1.75-2.5]',3};
        label = {'classname',5;'Iris-setosa',1;'Iris-versicolor',2;'Iris-virginica',3};
        
        feature_cell = {feature1,feature2,feature3,feature4,label};
        
    elseif length(findstr(path,'Iris'))~=0 && class(i)==2
        
        feature1 = {'sepallength',1;'[4.3-5.55]',1;'(5.55-6.25]',2;'(6.25-7.9]',3};
        feature2 = {'sepalwidth',2;'[2-2.95]',1;'(2.95-3.05]',2;'(3.05-4.4]',3};
        feature3 = {'petallength',3;'[1-2.45]',1;'(2.45-4.75]',2;'(4.75-6.9]',3};
        feature4 = {'petalwidth',4;'[0.1-0.8]',1;'(0.8-1.75]',2;'(1.75-2.5]',3};
        label = {'classname',5;'Iris-setosa',2;'Iris-versicolor',1;'Iris-virginica',3};
        
        feature_cell = {feature1,feature2,feature3,feature4,label};
        
        elseif length(findstr(path,'Iris'))~=0 && class(i)==3
        
        feature1 = {'sepallength',1;'[4.3-5.55]',1;'(5.55-6.25]',2;'(6.25-7.9]',3};
        feature2 = {'sepalwidth',2;'[2-2.95]',1;'(2.95-3.05]',2;'(3.05-4.4]',3};
        feature3 = {'petallength',3;'[1-2.45]',1;'(2.45-4.75]',2;'(4.75-6.9]',3};
        feature4 = {'petalwidth',4;'[0.1-0.8]',1;'(0.8-1.75]',2;'(1.75-2.5]',3};
        label = {'classname',5;'Iris-setosa',3;'Iris-versicolor',2;'Iris-virginica',1};
        
        feature_cell = {feature1,feature2,feature3,feature4,label};
        
        elseif length(findstr(path,'Heart'))~=0 && class(i)==1
        feature1 = {'Age',1;'[29-54.5]',1;'(54.5-77]',2};
        feature2 = {'Sex',2;'Male',1;'Female',2};
        feature3 = {'ChestPainType',3;'1',1;'2',2;'3',3;'4',4};
        feature4 = {'RestingBloodPressure',4;'[0.1-0.8]',1;'(0.8-1.75]',2;'(1.75-2.5]',3};
        feature5 = {'SerumCholestoral',5;'[126-272]',1;'(272-564]',2};
        feature6 = {'FastingBloodSugar',6;'No',1;'Yes',2};
        feature7 = {'RestingElectrocardiographic',7;'0',1;'2',2};
        feature8 = {'MaximumHeartRateAchieved',8;'[71-147.5]',1;'(147.5-202]',2};
        feature9 = {'ExerciseInducedAngina',9;'No',1;'Yes',2};
        feature10 = {'STDepressionInducedByExercise',11;'[0-1.7]',1;'(1.7-6.2]',2};
        feature11 = {'SlopeofPeakExerciseSTSegment',12;'1',1;'2',2};
        feature12 = {'Ca',13;'0',0;'1',1;'2',2;'3',3};
        feature13 = {'Thal',14;'Normal',1;'Reversable',2};

        label = {'PredictedAttribute',15;'PresenceHeartDisease',1;'AbsenceHeartDisease',2};
        
        feature_cell = {feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,feature11,feature12,feature13,label};  
        
        elseif length(findstr(path,'Heart'))~=0 && class(i)==2
        
        feature1 = {'Age',1;'[29-54.5]',1;'(54.5-77]',2};
        feature2 = {'Sex',2;'Male',1;'Female',2};
        feature3 = {'ChestPainType',3;'1',1;'2',2;'3',3;'4',4};
        feature4 = {'RestingBloodPressure',4;'[0.1-0.8]',1;'(0.8-1.75]',2;'(1.75-2.5]',3};
        feature5 = {'SerumCholestoral',5;'[126-272]',1;'(272-564]',2};
        feature6 = {'FastingBloodSugar',6;'No',1;'Yes',2};
        feature7 = {'RestingElectrocardiographic',7;'0',1;'2',2};
        feature8 = {'MaximumHeartRateAchieved',8;'[71-147.5]',1;'(147.5-202]',2};
        feature9 = {'ExerciseInducedAngina',9;'No',1;'Yes',2};
        feature10 = {'STDepressionInducedByExercise',11;'[0-1.7]',1;'(1.7-6.2]',2};
        feature11 = {'SlopeofPeakExerciseSTSegment',12;'1',1;'2',2};
        feature12 = {'Ca',13;'0',0;'1',1;'2',2;'3',3};
        feature13 = {'Thal',14;'Normal',1;'Reversable',2};

        label = {'PredictedAttribute',15;'PresenceHeartDisease',2;'AbsenceHeartDisease',1};
        
        feature_cell = {feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,feature11,feature12,feature13,label};     
        
        else
            fprintf('Sorry, your dataset format is uncorrected!');
        end     
        Overall_rule = {};
           CLIP4(POS,NEG,feature_names,feature_cell,Overall_rule);

    end
        reply = input('Do you want to continue for other datasets? Y/N [Y]: ', 's');
        if strcmp(reply, 'y')||strcmp(reply, 'Y')
            main();
        else
            fprintf('Thanks for using!');
        
        end   
    
end