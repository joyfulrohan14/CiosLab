function [redundent,row_vector,matrix_total] = REDUNDENT(matrix_total,row_vector)

%% if membership of another submatrix   
    row_vector_sum = zeros(1,length(row_vector));
    for j = 1:length(row_vector)
        row_vector_sum(j) = sum(row_vector(1:j));
    end
    row_vector_sum = [0 row_vector_sum];
%% get the redundent index number    
    redundent = [];
    for k = 1:length(row_vector)
        for j = 1:length(row_vector)
            matrix1 = matrix_total(row_vector_sum(k)+1:row_vector_sum(k+1),:);
            matrix2 = matrix_total(row_vector_sum(j)+1:row_vector_sum(j+1),:);
            [row1,col1] = size(matrix1);
            [row2,col2] = size(matrix2);
            if (k~=j)&&(row1<=row2)
                if length(find(ismember(matrix1,matrix2,'rows'))==1)== row1 
                    redundent = [redundent k];
                end
            end
        end
    end

%% remove the redundent node
%     for j = 1:length(redundent)
%         row_vector(redundent(j)) = [];
%         matrix_total(row_vector_sum(redundent(j))+1:row_vector_sum(redundent(j)+1),:) = [];
%     end
%    matrix_total;
%    row_vector;
%    redundent;
  
    full = 1:length(row_vector);
     [row_vector_index index]= setdiff(full,redundent);
     
     new_row_vector = [];

     dataset = [];
     
     for i = 1:length(index)
        new_row_vector =  [new_row_vector row_vector(index(i))];
        dataset = [dataset;matrix_total(row_vector_sum(index(i))+1:row_vector_sum(index(i)+1),:)];
     end

       matrix_total = dataset; 
       row_vector = new_row_vector;
       matrix_total;
       row_vector;
end