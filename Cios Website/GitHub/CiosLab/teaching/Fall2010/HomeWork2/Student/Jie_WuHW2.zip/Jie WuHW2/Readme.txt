Hi Dear Dat:

1. Please zip the file, run main.m. 
2. You will see "Please put the path and name of the data file in TXT format: ", then you could input the path and dataset name. like: "F:\HH\dataset\Weather.txt" or "F:\HH\dataset\Travel.txt" or "F:\HH\dataset\Iris.txt". Then you could get the rules.
   The datasets are the ones that I changed to numerical type. So, whenever there is new dataset, it should be changed to the numerical type.
3. After getting the rules of one dataset, you could input "Y" or "N" to continue the program or not.
4. For your conveience, I also changed the Heart dataset to my format, so that you could also run it. 

The final running results is as follows:

Please put the path and name of the data file in TXT format: 
F:\HH\Jie WuHW2\dataset\Weather.txt
 

RULE =

IF(outlook # overcast) AND(outlook # rainy) AND(humidity # normal)THEN play = no


RULE =

IF(outlook # sunny) AND(outlook # overcast) AND(windy # FALSE)THEN play = no


RULE =

IF(outlook # rainy) AND(humidity # high)THEN play = yes


RULE =

IF(outlook # sunny) AND(windy # TRUE)THEN play = yes


RULE =

IF(outlook # sunny) AND(outlook # rainy)THEN play = yes

Do you want to continue for other datasets? Y/N [Y]: Y
Please put the path and name of the data file in TXT format: 
F:\HH\Jie WuHW2\dataset\Travel.txt
 

RULE =

IF(Type of Call # Intern) AND(Lang Fluency # Not fluent) AND(Lang Fluency # Foreign)THEN Decision = Buy


RULE =

IF(Age # Very young) AND(Age # Young) AND(Age # Middle)THEN Decision = Buy


RULE =

IF(Type of Call # Long) AND(Lang Fluency # Fluent) AND(Lang Fluency # Accent)THEN Decision = Not Buy


RULE =

IF(Type of Call # Local) AND(Type of Call # Long) AND(Lang Fluency # Accent) AND(Lang Fluency # Not fluent)THEN Decision = Not Buy

Do you want to continue for other datasets? Y/N [Y]: Y
Please put the path and name of the data file in TXT format: 
F:\HH\Jie WuHW2\dataset\Iris.txt
 

RULE =

IF(petallength # (2.45-4.75]) AND(petallength # (4.75-6.9])THEN classname = Iris-setosa


RULE =

IF(sepalwidth # [2-2.95]) AND(petallength # [1-2.45]) AND(petallength # (4.75-6.9])THEN classname = Iris-versicolor


RULE =

IF(sepallength # [4.3-5.55]) AND(petallength # [1-2.45]) AND(petallength # (4.75-6.9])THEN classname = Iris-versicolor


RULE =

IF(sepalwidth # [2-2.95]) AND(sepalwidth # (2.95-3.05]) AND(petalwidth # [0.1-0.8]) AND(petalwidth # (1.75-2.5])THEN classname = Iris-versicolor


RULE =

IF(sepalwidth # (3.05-4.4]) AND(petalwidth # [0.1-0.8]) AND(petalwidth # (0.8-1.75])THEN classname = Iris-virginica


RULE =

IF(sepallength # [4.3-5.55]) AND(sepallength # (5.55-6.25]) AND(petalwidth # [0.1-0.8]) AND(petalwidth # (0.8-1.75])THEN classname = Iris-virginica

Do you want to continue for other datasets? Y/N [Y]: n
Thanks for using!>> 