function [TM_matrix,solution] = TM(POS,POS_matrix,leave_index) 
    [row,col] = size(POS);    
    leave_index_sum = zeros(1,length(leave_index));
    for i = 1:length(leave_index)
        leave_index_sum(i) = sum(leave_index(1:i));
    end
    leave_index_sum = [0 leave_index_sum];
    
    TM_matrix = zeros(row,length(leave_index));
    for i = 1:length(leave_index)
        for j = (leave_index_sum(i)+1):leave_index_sum(i+1)
            index = find(ismember(POS,POS_matrix(j,:),'rows')==1);                
            TM_matrix(index,i) = 1;
        end
    end
    TM_matrix;
    [solution] = cover_setting(TM_matrix);
end