function [solution] = cover_setting(data) 
     [rrr,ccc] = size(data);
     empty_vector = [];
     for i = 1:rrr
        if sum(data(i,:)) == 0
            empty_vector = [empty_vector i];
        end
     end
 
     full = 1:rrr;

     d = setdiff(full,empty_vector);
     dataset = [];
     for i = 1:length(d)
        dataset(i,:) = data(d(i),:);
     end
     
        [row,column] = size(dataset);
        full_rows = [1:row];
        active_rows = [1:row];
        inactive_rows = [];
        solution = zeros(1,column);
    
    while(length(active_rows)~=0)
    %% get the full active_rows_matrix
        active_rows_matrix = zeros(length(active_rows),column);
        for i = 1:length(active_rows)
            active_rows_matrix(i,:) = dataset(active_rows(i),:);
        end
        %active_rows_matrix
    %% get the min_row
        min_row = [];
        for i = 1:length(active_rows)
            indices = find(active_rows_matrix(i,:)==1);
            min_row(i) = length(indices);
        end
        %min_row
    %% get the selected min_row_matrix from original matrix
        [minrow, index] = find(min_row == min(min_row));
        min_row_matrix = zeros(length(index),column);
        for i = 1:length(index)
            min_row_matrix(i,:) = active_rows_matrix(index(i),:);
        end
        %min_row_matrix
    %% get the max_column  
        max_column = [];
        [r,c] = size(min_row_matrix);
        for j = 1:c
            indices = find(min_row_matrix(:,j)==1);
            max_column(j) = length(indices);
        end
        %max_column

        [maxcolumn, index2] = find(max_column == max(max_column));
    %    active_rows_matrix = zeros(length(active_rows),column)
    %% get the max_max_column
    %     for i = 1:length(active_rows)
    %         active_rows_matrix(i,:) = dataset(active_rows(i),:);
    %     end
    %    active_rows_matrix
        %% get the sub_matrix
        max_max_matrix = zeros(length(active_rows),length(index2));
        for i = 1:length(index2)
            max_max_matrix(:,i) = active_rows_matrix(:,index2(i));
        end
        %max_max_matrix

        max_max_column = [];
        [rr,cc] = size(max_max_matrix);
        for j = 1:cc
            indices = find(max_max_matrix(:,j)==1);
            max_max_column(j) = length(indices);
        end
       [maxmaxcolumn, index3] = find(max_max_column == max(max_max_column));

    %% get the lowest number of 1
        final_index = 0;
        if length(index3)>1
            inactive_rows_matrix = zeros(length(inactive_rows),column);
            for i = 1:length(inactive_rows)
                inactive_rows_matrix(i,:) = dataset(inactive_rows(i),:);
            end
            max_low_matrix = zeros(length(inactive_rows),length(index3));
            for j = 1:length(index3)
                max_low_matrix(:,j) = inactive_rows_matrix(:,index2(j));
            end
            max_low_column = [];
            [rrr,ccc] = size(max_low_matrix);
            for j = 1:ccc
                indices = find(max_low_matrix(:,j)==1);
                max_low_column(j) = length(indices);
            end
           [maxlowcolumn, index4] = find(max_low_column == min(max_low_column));
           final_index = index4(1);
        else
           final_index = index3;
        end
        %final_index

    %% get the solution   
        solution(index2(final_index)) = 1;

    %% active rows remark   

        for i = 1:length(active_rows)
            if dataset(active_rows(i),index2(final_index)) == solution(index2(final_index))
                inactive_rows = unique([inactive_rows active_rows(i)]);
            end
        end
        active_rows = setdiff(full_rows,inactive_rows);  %% remove the inactive one index
 
    end
    solution;
end
   
    