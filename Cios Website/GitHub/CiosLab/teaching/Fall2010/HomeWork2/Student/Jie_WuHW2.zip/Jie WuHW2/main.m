function[] = main()
 %% Read a "txt" data file input by a user
    reply_data = ...
        input('Please put the path and name of the data file in TXT format: \n', 's');

    [POS,NEG,feature_names,feature_cell] = READINGDATASET2(reply_data);

end

