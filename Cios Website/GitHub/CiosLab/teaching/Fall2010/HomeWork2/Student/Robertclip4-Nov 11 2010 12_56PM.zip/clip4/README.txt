In order to run CLIP4 you have to unpack this archive and execute clip4.jar. Double clicking the clip4.jar file should open window which lets you chose parameters for CLIP4 algorithm. First you have to select dataset - click "Select" button and chose any file you want. Then you have to specify thresholds (if you do not want to use pruning threshold set its value to 0!). After you set all thresholds you can chose whether you want to generate rules that contains inequality signs "!=" or equality signs "=". Program sholud generate rules after you click "Generate rules" button.

The archive contains following directories:
- .settings - settings for eclipse project
- bin - binary files (not used)
- datasets - contains 4 datasets
- lib - libraries required by the project (just Look & Feel)
- src - java sources
- test - java sources of the unit tests
- clip4.jar - executable program
