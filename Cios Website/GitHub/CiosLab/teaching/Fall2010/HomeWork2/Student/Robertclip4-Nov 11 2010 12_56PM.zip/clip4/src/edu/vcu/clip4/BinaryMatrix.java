package edu.vcu.clip4;

import java.util.ArrayList;
import java.util.List;

public class BinaryMatrix {

	private final boolean[][] values;

	public BinaryMatrix(boolean[][] values) {
		this.values = values;
	}

	public boolean[] solveSetCovering() {
		boolean[] result = new boolean[values[0].length];
		boolean[] passive = new boolean[values.length];
		while (getTrueNumber(passive) < passive.length
				&& getTrueNumber(result) < result.length) {
			int[] minRows = getMinRows(passive);
			int[] maxCols = getMaxCols(minRows, result);
			int maxMaxCol = getMaxMaxCol(maxCols, passive);
			result[maxMaxCol] = true;
			for (int i = 0; i < passive.length; i++) {
				if (values[i][maxMaxCol]) {
					passive[i] = true;
				}
			}
		}
		return result;
	}

	public boolean get(int i, int j) {
		return values[i][j];
	}

	private int getTrueNumber(boolean[] passive) {
		int sum = 0;
		for (boolean element : passive) {
			if (element) {
				sum++;
			}
		}
		return sum;
	}

	private int getMaxMaxCol(int[] maxCols, boolean[] passive) {
		List<Integer> maxIndexes = new ArrayList<Integer>();
		int maxColSum = Integer.MIN_VALUE;
		for (int maxCol : maxCols) {
			int sum = getColSum(maxCol, passive);
			if (sum >= maxColSum) {
				if (sum > maxColSum) {
					maxIndexes.clear();
					maxColSum = sum;
				}
				maxIndexes.add(maxCol);
			}
		}
		return getMinMaxMaxCol(toArray(maxIndexes), passive);
	}

	private int getMinMaxMaxCol(int[] columns, boolean[] passive) {
		int minIndex = columns[0];
		if (columns.length > 1) {
			int minSum = Integer.MAX_VALUE;
			for (int column : columns) {
				int sum = 0;
				for (int i = 0; i < passive.length; i++) {
					if (passive[i] && values[i][column]) {
						sum++;
					}
				}
				if (sum < minSum) {
					minSum = sum;
					minIndex = column;
				}
			}
		}
		return minIndex;
	}

	private int[] getMaxCols(int[] minRows, boolean[] result) {
		List<Integer> maxIndexes = new ArrayList<Integer>();
		int maxColSum = Integer.MIN_VALUE;
		for (int j = 0; j < values[0].length; j++) {
			if (!result[j]) {
				int sum = getColSum(j, minRows);
				if (sum >= maxColSum) {
					if (sum > maxColSum) {
						maxIndexes.clear();
						maxColSum = sum;
					}
					maxIndexes.add(j);
				}
			}
		}
		return toArray(maxIndexes);
	}

	private int[] getMinRows(boolean[] passive) {
		List<Integer> minIndexes = new ArrayList<Integer>();
		int minRowSum = Integer.MAX_VALUE;
		for (int i = 0; i < passive.length; i++) {
			if (!passive[i]) {
				int sum = getRowSum(i);
				if (sum <= minRowSum) {
					if (sum < minRowSum) {
						minIndexes.clear();
						minRowSum = sum;
					}
					minIndexes.add(i);
				}
			}
		}
		return toArray(minIndexes);
	}

	private int[] toArray(List<Integer> listIndexes) {
		int[] indexes = new int[listIndexes.size()];
		for (int i = 0; i < indexes.length; i++) {
			indexes[i] = listIndexes.get(i);
		}
		return indexes;
	}

	private int getRowSum(int i) {
		int sum = 0;
		for (int j = 0; j < values[i].length; j++) {
			if (values[i][j]) {
				sum++;
			}
		}
		return sum;
	}

	private int getColSum(int j, int[] rows) {
		int sum = 0;
		for (int row : rows) {
			if (values[row][j]) {
				sum++;
			}
		}
		return sum;
	}

	private int getColSum(int j, boolean[] passive) {
		int sum = 0;
		for (int i = 0; i < passive.length; i++) {
			if (!passive[i] && values[i][j]) {
				sum++;
			}
		}
		return sum;
	}

}
