package edu.vcu.clip4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Clip4 {

	private final RuleFactory factory;

	private double noiseThreshold = 0.2;
	private double stopThreshold = 0.9;
	private int pruningThreshold = 0;

	public Clip4() {
		this.factory = new RuleFactory();
	}

	public Clip4(boolean equalities) {
		this.factory = new RuleFactory(equalities);
	}

	public Clip4(boolean equalities, double noiseThreshold,
			double stopThreshold, int pruningThreshold) {
		this.factory = new RuleFactory(equalities);
		this.noiseThreshold = noiseThreshold;
		this.stopThreshold = stopThreshold;
		this.pruningThreshold = pruningThreshold;
	}

	public List<Rule> generate(DataSet dataSet) {
		List<Rule> rules = new ArrayList<Rule>();
		for (String className : dataSet.getClassNames()) {
			DataSet negative = dataSet.extract(className, false);
			DataSet positive = dataSet.extract(className, true);

			List<DataSet> currentPositives = new ArrayList<DataSet>();
			currentPositives.add(positive);
			for (DataPoint negDataPoint : negative.getDataPoints()) {
				final Map<DataSet, Double> fitnes = new HashMap<DataSet, Double>();
				Map<DataSet, List<DataSet>> branches = new HashMap<DataSet, List<DataSet>>();
				for (DataSet currentPositive : currentPositives) {
					List<DataSet> branched = prune(positive, currentPositive.branch(negDataPoint));
					double fitVal = (double) currentPositive.getDataPoints().size() / branched.size();
					fitnes.put(currentPositive, fitVal);
					branches.put(currentPositive, branched);
				}
				Set<DataSet> sorted = new TreeSet<DataSet>(new Comparator<DataSet>() {
					@Override
					public int compare(DataSet o1, DataSet o2) {
						int res = fitnes.get(o1).compareTo(fitnes.get(o2));
						if (res == 0 && o1 != o2) {
							return 1;
						}
						return res;
					}
				});
				sorted.addAll(currentPositives);
				List<DataSet> sortedList = new ArrayList<DataSet>(sorted);
				if (sortedList.size() > pruningThreshold && pruningThreshold > 0) {
					sortedList = sortedList.subList(0, pruningThreshold);
				}
				List<DataSet> branched = new ArrayList<DataSet>();
				for (DataSet currentPositive : currentPositives) {
					if (sortedList.contains(currentPositive)) {
						branched.addAll(branches.get(currentPositive));
					}
				}

				currentPositives.clear();
				currentPositives.addAll(removeRedundant(branched));

				// for (DataSet currentPositive : currentPositives) {
				// List<DataSet> branched =
				// currentPositive.branch(negDataPoint);
				// nextPositive.addAll(prune(positive, branched));
				// }
				// currentPositives.clear();
				// currentPositives.addAll(removeRedundant(nextPositive));
				// nextPositive.clear();
			}

			BinaryMatrix totalMatrix = createTotalMatrix(positive, currentPositives);
			boolean[] result = totalMatrix.solveSetCovering();
			List<DataSet> resultDataSets = new ArrayList<DataSet>();
			for (int i = 0; i < result.length; i++) {
				if (result[i]) {
					resultDataSets.add(currentPositives.get(i));
				}
			}
			resultDataSets = removeOverStopThreshold(positive, resultDataSets);
			for (DataSet resultDataSet : resultDataSets) {
				BinaryMatrix backNegMatrix = createBackNegMatrix(negative, resultDataSet);
				rules.add(factory.createRule(dataSet, className, backNegMatrix));
			}
		}
		return rules;
	}

	private List<DataSet> removeOverStopThreshold(DataSet positive, List<DataSet> resultDataSets) {
		Set<DataPoint> positiveDataPoints = new HashSet<DataPoint>(positive.getDataPoints());
		Set<DataPoint> resultDataPoints = new HashSet<DataPoint>();
		List<DataSet> necessaryDataSets = new ArrayList<DataSet>();
		for (DataSet dataSet : resultDataSets) {
			resultDataPoints.addAll(dataSet.getDataPoints());
			necessaryDataSets.add(dataSet);
			if ((double) resultDataPoints.size() / positiveDataPoints.size() > stopThreshold) {
				return necessaryDataSets;
			}
		}
		return necessaryDataSets;
	}

	private Collection<? extends DataSet> removeRedundant(List<DataSet> list) {
		List<DataSet> dataSets = new ArrayList<DataSet>(list);
		for (DataSet dataSet : list) {
			List<DataSet> most = new ArrayList<DataSet>(list);
			most.remove(dataSet);
			for (DataSet other : most) {
				if (other.containsDataSet(dataSet)) {
					dataSets.remove(dataSet);
					break;
				}
			}
		}
		return dataSets;
	}

	private List<DataSet> prune(DataSet positive, List<DataSet> branches) {
		List<DataSet> dataSets = new ArrayList<DataSet>();
		for (DataSet dataSet : branches) {
			if (!isNoise(positive, dataSet, noiseThreshold)) {
				dataSets.add(dataSet);
			}
		}
		return dataSets;
	}

	private boolean isNoise(DataSet positive, DataSet branch, double noise) {
		return (double) branch.getDataPoints().size() / positive.getDataPoints().size() < noise;
	}

	private BinaryMatrix createBackNegMatrix(DataSet negative, DataSet positive) {
		int featureNumber = negative.getDataPoints().get(0).getFeatures().length;
		int negNumber = negative.getDataPoints().size();
		boolean[][] binary = new boolean[negNumber][featureNumber];
		for (int in = 0; in < negative.getDataPoints().size(); in++) {
			DataPoint negativeDataPoint = negative.getDataPoints().get(in);
			String[] negativeFeatures = negativeDataPoint.getFeatures();
			for (int jn = 0; jn < negativeFeatures.length; jn++) {
				binary[in][jn] = true;
				for (int ip = 0; ip < positive.getDataPoints().size(); ip++) {
					DataPoint positiveDataPoint = positive.getDataPoints().get(ip);
					String[] positiveFeatures = positiveDataPoint.getFeatures();
					if (Features.isFeatureEmpty(negativeFeatures[jn])
							|| !Features.isFeatureEmpty(positiveFeatures[jn])
							&& Features.isFeatureEqualOrEmpty(
									negativeFeatures[jn], positiveFeatures[jn])) {
						binary[in][jn] = false;
					}
				}
			}
		}
		return new BinaryMatrix(binary);
	}

	private BinaryMatrix createTotalMatrix(DataSet positive,
			List<DataSet> finalPositives) {
		List<DataPoint> positiveDataPoints = positive.getDataPoints();
		boolean[][] binary = new boolean[positiveDataPoints.size()][finalPositives.size()];
		for (int i = 0; i < positiveDataPoints.size(); i++) {
			for (int j = 0; j < finalPositives.size(); j++) {
				if (finalPositives.get(j).containsDataPoint(positiveDataPoints.get(i))) {
					binary[i][j] = true;
				}
			}
		}
		return new BinaryMatrix(binary);
	}
}
