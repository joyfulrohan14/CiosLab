package edu.vcu.clip4;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class Clip4Runner {

	public static void main(String[] args) throws IOException {
		DataReader reader = new DataReader();
		DataSet dataSet = reader.readDataPoints(
				new File("datasets/Travel-DS.txt"));
		Clip4 clip = new Clip4();
		List<Rule> rules = clip.generate(dataSet);
		for (Rule rule : rules) {
			System.out.println(rule);
		}
	}

}
