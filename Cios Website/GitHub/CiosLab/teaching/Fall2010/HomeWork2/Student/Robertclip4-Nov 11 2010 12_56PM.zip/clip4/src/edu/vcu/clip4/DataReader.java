package edu.vcu.clip4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataReader {

	public DataSet readDataPoints(File input) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(input));
		try {
			List<String> headers = readHeaders(reader);
			List<DataPoint> dataPoints = new ArrayList<DataPoint>();
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				String[] values = line.split("\\s*,\\s*");
				DataPoint dataPoint = new DataPoint(
						values[values.length - 1].trim(),
						Arrays.copyOf(values, values.length - 1));
				dataPoints.add(dataPoint);
			}
			return new DataSet(headers, dataPoints);
		} finally {
			reader.close();
		}
	}

	private List<String> readHeaders(BufferedReader reader) throws IOException {
		reader.readLine();
		List<String> headers = Arrays.asList(reader.readLine().split("\\s*,\\s*"));
		reader.readLine();
		return headers;
	}

}
