package edu.vcu.clip4;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class DataSet {

	private final List<String> featureNames;

	private final List<DataPoint> dataPoints;

	public DataSet(List<String> featureNames, List<DataPoint> dataPoints) {
		this.featureNames = featureNames;
		this.dataPoints = dataPoints;
	}

	public List<String> getClassNames() {
		Set<String> classNames = new TreeSet<String>();
		for (DataPoint dataPoint : dataPoints) {
			classNames.add(dataPoint.getClassName());
		}
		return new ArrayList<String>(classNames);
	}

	public List<DataPoint> getDataPoints() {
		return dataPoints;
	}

	public List<String> getFeatureNames() {
		return featureNames;
	}

	public DataSet extract(String className, boolean positive) {
		List<DataPoint> extracted = new ArrayList<DataPoint>();
		for (DataPoint dataPoint : dataPoints) {
			if (dataPoint.getClassName().equals(className) == positive) {
				extracted.add(dataPoint);
			}
		}
		return new DataSet(featureNames, extracted);
	}

	public List<DataSet> branch(DataPoint negativeDataPoint) {
		BinaryMatrix binary = extractBinary(negativeDataPoint);
		boolean[] features = binary.solveSetCovering();
		List<DataSet> dataSets = new ArrayList<DataSet>();
		for (int i = 0; i < features.length; i++) {
			if (features[i]) {
				List<DataPoint> newDataPoints = new ArrayList<DataPoint>();
				String negativeFeature = negativeDataPoint.getFeatures()[i];
				for (DataPoint currentDataPoint : dataPoints) {
					String currentFeature = currentDataPoint.getFeatures()[i];
					if (Features.isFeatureEmpty(currentFeature)
							|| !Features.isFeatureEqualOrEmpty(currentFeature, negativeFeature)) {
						newDataPoints.add(currentDataPoint);
					}
				}
				if (!newDataPoints.isEmpty()) {
					DataSet dataSet = new DataSet(featureNames, newDataPoints);
					if (!isPrunningDecisionPositive(dataSet)) {
						dataSets.add(dataSet);
					}
				}
			}
		}
		return dataSets;
	}

	private boolean isPrunningDecisionPositive(DataSet dataSet) {
		// TODO prunning
		return dataSet.getDataPoints().size() < 2;
	}

	private BinaryMatrix extractBinary(DataPoint negativeDataPoint) {
		boolean[][] binary = new boolean[dataPoints.size()][negativeDataPoint.getFeatures().length];
		for (int i = 0; i < binary.length; i++) {
			DataPoint current = dataPoints.get(i);
			for (int j = 0; j < binary[i].length; j++) {
				String currentFeature = current.getFeatures()[j];
				String negativeFeature = negativeDataPoint.getFeatures()[j];
				binary[i][j] = !Features.isFeatureEqualOrEmpty(currentFeature, negativeFeature);
			}
		}
		return new BinaryMatrix(binary);
	}

	public boolean containsDataPoint(DataPoint dataPoint) {
		for (DataPoint current : dataPoints) {
			if (current.equals(dataPoint)) {
				return true;
			}
		}
		return false;
	}

	public boolean containsDataSet(DataSet dataSet) {
		for (DataPoint dataPoint : dataSet.getDataPoints()) {
			if (!containsDataPoint(dataPoint)) {
				return false;
			}
		}
		return true;
	}

}
