package edu.vcu.clip4;

public class Features {

	public static boolean isFeatureEmpty(String feature) {
		return feature == null || feature.isEmpty();
	}

	public static boolean isFeatureEqualOrEmpty(String feature1, String feature2) {
		return isFeatureEmpty(feature1) || isFeatureEmpty(feature2)
				|| feature1.equals(feature2);
	}

}
