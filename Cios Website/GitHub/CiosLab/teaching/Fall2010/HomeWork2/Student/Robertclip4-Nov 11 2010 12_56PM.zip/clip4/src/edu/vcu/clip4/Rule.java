package edu.vcu.clip4;

public class Rule {

	private final String text;

	public Rule(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}

	public String getText() {
		return text;
	}

}
