package edu.vcu.clip4;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RuleFactory {

	private final boolean equalities;

	public RuleFactory() {
		equalities = false;
	}

	public RuleFactory(boolean equalities) {
		this.equalities = equalities;
	}

	public Rule createRule(DataSet dataSet, String className, BinaryMatrix backNegMatrix) {
		DataSet negative = dataSet.extract(className, false);

		boolean[] features = backNegMatrix.solveSetCovering();
		List<String> featureTerms = new ArrayList<String>();
		for (int j = 0; j < features.length; j++) {
			if (features[j]) {
				Set<String> posValues = new TreeSet<String>();
				Set<String> negValues = new TreeSet<String>();
				for (int i = 0; i < negative.getDataPoints().size(); i++) {
					DataPoint dataPoint = negative.getDataPoints().get(i);
					if (!Features.isFeatureEmpty(dataPoint.getFeatures()[j])) {
						if (backNegMatrix.get(i, j)) {
							negValues.add(dataPoint.getFeatures()[j]);
						}
					}
				}
				for (int i = 0; i < dataSet.getDataPoints().size(); i++) {
					DataPoint dataPoint = dataSet.getDataPoints().get(i);
					if (!Features.isFeatureEmpty(dataPoint.getFeatures()[j])) {
						posValues.add(dataPoint.getFeatures()[j]);
					}
				}
				posValues.removeAll(negValues);
				List<String> terms = new ArrayList<String>();
				if (equalities) {
					if (!posValues.isEmpty()) {
						for (String value : posValues) {
							terms.add(MessageFormat.format(
									"<font color=''blue''>{0}</font> <b>=</b> <font color=''green''>{1}</font>",
									dataSet.getFeatureNames().get(j), value));
						}
						String featureTerm = join(terms, " <b>or</b> ");
						if (terms.size() > 1) {
							featureTerms.add("(" + featureTerm + ")");
						} else {
							featureTerms.add(featureTerm);
						}
					}
				} else {
					if (!negValues.isEmpty()) {
						for (String value : negValues) {
							terms.add(MessageFormat.format(
									"<font color=''blue''>{0}</font> <b>!=</b> <font color=''green''>{1}</font>",
									dataSet.getFeatureNames().get(j), value));
						}
						featureTerms.add(join(terms, " <b>and</b> "));
					}
				}
			}
		}
		String text = MessageFormat.format("<b>if</b> {0} <b>then</b> <font color='red'>{1}</font>",
				join(featureTerms, " <b>and</b> "), className);
		return new Rule(text);
	}

	private String join(List<?> objects, String delim) {
		StringBuilder buffer = new StringBuilder();
		if (!objects.isEmpty()) {
			Iterator<?> iter = objects.iterator();
			buffer.append(iter.next());
			while (iter.hasNext()) {
				buffer.append(delim).append(iter.next());
			}
		}
		return buffer.toString();
	}

}
