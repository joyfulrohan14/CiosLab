package edu.vcu.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.TitledBorder;

import org.pushingpixels.substance.api.skin.SubstanceBusinessBlueSteelLookAndFeel;

import edu.vcu.clip4.Clip4;
import edu.vcu.clip4.DataReader;
import edu.vcu.clip4.DataSet;
import edu.vcu.clip4.Rule;

public class Clip4Dialog extends JDialog {

	private static final long serialVersionUID = -2368845108665295001L;

	private final JPanel contentPanel = new JPanel();
	private JTextField fileTextField;
	private JTextPane rulesTextPane;
	private JCheckBox equalitiesCheckBox;
	private JSpinner noiseThresholdSpinner;
	private JButton generateButton;
	private JSpinner stopThresholdSpinner;
	private JSpinner pruningThresholdSpinner;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					UIManager.setLookAndFeel(new SubstanceBusinessBlueSteelLookAndFeel());

					Clip4Dialog dialog = new Clip4Dialog();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (UnsupportedLookAndFeelException e) {
					throw new IllegalStateException("unable to initialize L&F", e);
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Clip4Dialog() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Clip4Dialog.class.getResource("/edu/vcu/ui/rule.jpeg")));
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setMinimumSize(new Dimension(380, 340));
		setTitle("CLIP4");
		setBounds(100, 100, 540, 560);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new TitledBorder(null, "CLIP4 parameters", TitledBorder.LEADING, TitledBorder.TOP, null,
				null));
		getContentPane().add(contentPanel, BorderLayout.NORTH);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[] { 130, 0, 0, 0 };
		gbl_contentPanel.rowHeights = new int[] { 0, 0, 0, 0, 0, 0 };
		gbl_contentPanel.columnWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		gbl_contentPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel fileLabel = new JLabel("File");
			GridBagConstraints gbc_fileLabel = new GridBagConstraints();
			gbc_fileLabel.anchor = GridBagConstraints.WEST;
			gbc_fileLabel.insets = new Insets(0, 5, 5, 5);
			gbc_fileLabel.gridx = 0;
			gbc_fileLabel.gridy = 0;
			contentPanel.add(fileLabel, gbc_fileLabel);
		}
		{
			fileTextField = new JTextField();
			fileTextField.setEditable(false);
			GridBagConstraints gbc_fileTextField = new GridBagConstraints();
			gbc_fileTextField.insets = new Insets(0, 0, 5, 5);
			gbc_fileTextField.fill = GridBagConstraints.HORIZONTAL;
			gbc_fileTextField.gridx = 1;
			gbc_fileTextField.gridy = 0;
			contentPanel.add(fileTextField, gbc_fileTextField);
			fileTextField.setColumns(10);
		}
		{
			JButton fileButton = new JButton("Select");
			fileButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JFileChooser chooser = new JFileChooser();
					chooser.setCurrentDirectory(new File("./datasets/"));
					chooser.setDialogTitle("Select data set");
					chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
					if (chooser.showOpenDialog(Clip4Dialog.this) == JFileChooser.APPROVE_OPTION) {
						try {
							fileTextField.setText(chooser.getSelectedFile().getCanonicalPath());
							generateButton.setEnabled(true);
						} catch (IOException ex) {
							JOptionPane.showMessageDialog(Clip4Dialog.this,
									"Error occured (" + ex.getMessage() + ")",
									"Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			});
			GridBagConstraints gbc_fileButton = new GridBagConstraints();
			gbc_fileButton.insets = new Insets(0, 0, 5, 0);
			gbc_fileButton.gridx = 2;
			gbc_fileButton.gridy = 0;
			contentPanel.add(fileButton, gbc_fileButton);
		}
		{
			JLabel noiseThresholdLabel = new JLabel("Noise threshold [%]");
			GridBagConstraints gbc_noiseThresholdLabel = new GridBagConstraints();
			gbc_noiseThresholdLabel.anchor = GridBagConstraints.WEST;
			gbc_noiseThresholdLabel.insets = new Insets(0, 5, 5, 5);
			gbc_noiseThresholdLabel.gridx = 0;
			gbc_noiseThresholdLabel.gridy = 1;
			contentPanel.add(noiseThresholdLabel, gbc_noiseThresholdLabel);
		}
		{
			noiseThresholdSpinner = new JSpinner();
			noiseThresholdSpinner.setPreferredSize(new Dimension(60, 20));
			noiseThresholdSpinner.setModel(new SpinnerNumberModel(20.0, 0.0, 100.0, 1.0));
			GridBagConstraints gbc_noiseThresholdSpinner = new GridBagConstraints();
			gbc_noiseThresholdSpinner.anchor = GridBagConstraints.WEST;
			gbc_noiseThresholdSpinner.insets = new Insets(0, 0, 5, 5);
			gbc_noiseThresholdSpinner.gridx = 1;
			gbc_noiseThresholdSpinner.gridy = 1;
			contentPanel.add(noiseThresholdSpinner, gbc_noiseThresholdSpinner);
		}
		{
			JLabel pruningThresholdLabel = new JLabel("Pruning threshold");
			GridBagConstraints gbc_pruningThresholdLabel = new GridBagConstraints();
			gbc_pruningThresholdLabel.insets = new Insets(0, 5, 5, 5);
			gbc_pruningThresholdLabel.anchor = GridBagConstraints.WEST;
			gbc_pruningThresholdLabel.gridx = 0;
			gbc_pruningThresholdLabel.gridy = 2;
			contentPanel.add(pruningThresholdLabel, gbc_pruningThresholdLabel);
		}
		{
			pruningThresholdSpinner = new JSpinner();
			pruningThresholdSpinner.setPreferredSize(new Dimension(60, 20));
			pruningThresholdSpinner.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null,
					new Integer(1)));
			GridBagConstraints gbc_pruningThresholdSpinner = new GridBagConstraints();
			gbc_pruningThresholdSpinner.anchor = GridBagConstraints.WEST;
			gbc_pruningThresholdSpinner.insets = new Insets(0, 0, 5, 5);
			gbc_pruningThresholdSpinner.gridx = 1;
			gbc_pruningThresholdSpinner.gridy = 2;
			contentPanel.add(pruningThresholdSpinner, gbc_pruningThresholdSpinner);
		}
		{
			JLabel stopThresholdLabel = new JLabel("Stop threshold [%]");
			GridBagConstraints gbc_stopThresholdLabel = new GridBagConstraints();
			gbc_stopThresholdLabel.insets = new Insets(0, 5, 5, 5);
			gbc_stopThresholdLabel.anchor = GridBagConstraints.WEST;
			gbc_stopThresholdLabel.gridx = 0;
			gbc_stopThresholdLabel.gridy = 3;
			contentPanel.add(stopThresholdLabel, gbc_stopThresholdLabel);
		}
		{
			stopThresholdSpinner = new JSpinner();
			stopThresholdSpinner.setPreferredSize(new Dimension(60, 20));
			stopThresholdSpinner.setModel(new SpinnerNumberModel(90.0, 0.0, 100.0, 1.0));
			GridBagConstraints gbc_stopThresholdSpinner = new GridBagConstraints();
			gbc_stopThresholdSpinner.anchor = GridBagConstraints.WEST;
			gbc_stopThresholdSpinner.insets = new Insets(0, 0, 5, 5);
			gbc_stopThresholdSpinner.gridx = 1;
			gbc_stopThresholdSpinner.gridy = 3;
			contentPanel.add(stopThresholdSpinner, gbc_stopThresholdSpinner);
		}
		{
			JLabel equalityLabel = new JLabel("Equalities");
			GridBagConstraints gbc_equalityLabel = new GridBagConstraints();
			gbc_equalityLabel.anchor = GridBagConstraints.WEST;
			gbc_equalityLabel.insets = new Insets(0, 5, 5, 5);
			gbc_equalityLabel.gridx = 0;
			gbc_equalityLabel.gridy = 4;
			contentPanel.add(equalityLabel, gbc_equalityLabel);
		}
		{
			equalitiesCheckBox = new JCheckBox("");
			GridBagConstraints gbc_equalitiesCheckBox = new GridBagConstraints();
			gbc_equalitiesCheckBox.insets = new Insets(0, 0, 0, 5);
			gbc_equalitiesCheckBox.anchor = GridBagConstraints.WEST;
			gbc_equalitiesCheckBox.gridx = 1;
			gbc_equalitiesCheckBox.gridy = 4;
			contentPanel.add(equalitiesCheckBox, gbc_equalitiesCheckBox);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				generateButton = new JButton("Generate rules");
				generateButton.setEnabled(false);
				generateButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						try {
							DataReader reader = new DataReader();
							DataSet dataSet = reader.readDataPoints(
									new File(fileTextField.getText()));
							Clip4 clip = new Clip4(equalitiesCheckBox.isSelected(),
									(Double) noiseThresholdSpinner.getValue() / 100,
									(Double) stopThresholdSpinner.getValue() / 100,
									(Integer) pruningThresholdSpinner.getValue());
							generateButton.setEnabled(false);
							List<Rule> rules = clip.generate(dataSet);
							StringBuilder builder = new StringBuilder();
							for (Rule rule : rules) {
								builder.append(rule).append("<br><br>");
							}
							rulesTextPane.setText(builder.toString());
						} catch (Exception ex) {
							ex.printStackTrace();
							JOptionPane.showMessageDialog(Clip4Dialog.this,
									"Error occured (" + ex.getMessage() + ")",
									"Error", JOptionPane.ERROR_MESSAGE);
						} finally {
							generateButton.setEnabled(true);
						}
					}
				});
				generateButton.setActionCommand("OK");
				buttonPane.add(generateButton);
				getRootPane().setDefaultButton(generateButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		{
			JPanel rulesPanel = new JPanel();
			rulesPanel.setBorder(new TitledBorder(null, "Rules", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			getContentPane().add(rulesPanel, BorderLayout.CENTER);
			GridBagLayout gbl_rulesPanel = new GridBagLayout();
			gbl_rulesPanel.columnWidths = new int[] { 23, 0 };
			gbl_rulesPanel.rowHeights = new int[] { 24, 0 };
			gbl_rulesPanel.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
			gbl_rulesPanel.rowWeights = new double[] { 1.0, Double.MIN_VALUE };
			rulesPanel.setLayout(gbl_rulesPanel);
			{
				JScrollPane rulesScrollPane = new JScrollPane();
				rulesScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				GridBagConstraints gbc_rulesScrollPane = new GridBagConstraints();
				gbc_rulesScrollPane.fill = GridBagConstraints.BOTH;
				gbc_rulesScrollPane.gridx = 0;
				gbc_rulesScrollPane.gridy = 0;
				rulesPanel.add(rulesScrollPane, gbc_rulesScrollPane);
				{
					rulesTextPane = new JTextPane();
					rulesTextPane.setContentType("text/html");
					rulesTextPane.setFont(new Font("Segoe UI", Font.PLAIN, 12));
					rulesTextPane.setEditable(false);
					rulesScrollPane.setViewportView(rulesTextPane);
				}
			}
		}
	}

}
