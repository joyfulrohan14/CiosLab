package edu.vcu.clip4;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class BinaryMatrixTest {

	@Test
	public void testSolveSetCovering() {
		boolean[][] values = {
				{ true, false, true, true, false },
				{ false, true, true, false, true },
				{ false, false, true, true, true },
				{ false, true, true, false, true },
				{ false, true, true, false, true },
				{ true, false, false, true, false },
				{ true, false, false, true, false }
		};
		BinaryMatrix matrix = new BinaryMatrix(values);
		boolean[] sc = matrix.solveSetCovering();
		boolean[] expecteds = { false, true, false, true, false };
		Assert.assertTrue(Arrays.equals(expecteds, sc));
	}

}
