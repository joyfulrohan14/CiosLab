package edu.vcu.clip4;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class Clip4Test {

	@Test
	public void testDataSets() throws IOException {
		List<String> fileNames = Arrays.asList(
				"datasets/Hea-DS.txt",
				"datasets/Iris-DS.txt",
				"datasets/Travel-DS.txt",
				"datasets/weather.txt");
		DataReader reader = new DataReader();
		for (String fileName : fileNames) {
			DataSet dataSet = reader.readDataPoints(new File(fileName));
			Clip4 clip = new Clip4();
			List<Rule> rules = clip.generate(dataSet);
			Assert.assertNotNull(rules);

			display(fileName, rules);
		}
	}

	@Test
	public void testDataSet1() {
		Clip4 clip = new Clip4();
		List<DataPoint> dataPoints = Arrays.asList(
				new DataPoint("1", new String[] { "1", "2", "3", null }),
				new DataPoint("1", new String[] { "1", "3", "1", "2" }),
				new DataPoint("1", new String[] { null, "3", "2", "5" }),
				new DataPoint("1", new String[] { "3", "3", "2", "2" }),
				new DataPoint("1", new String[] { "1", "1", "1", "3" }),
				new DataPoint("2", new String[] { "3", "1", "2", "5" }),
				new DataPoint("2", new String[] { "1", "2", "2", "4" }),
				new DataPoint("2", new String[] { "2", "1", null, "3" }));
		DataSet dataSet = new DataSet(Arrays.asList("F1", "F2", "F3", "F4"), dataPoints);
		List<Rule> rules = clip.generate(dataSet);
		Assert.assertNotNull(rules);

		display("data set 1", rules);
	}

	@Test
	public void testDataSet2() {
		Clip4 clip = new Clip4();
		List<DataPoint> dataPoints = Arrays.asList(
				new DataPoint("1", new String[] { "1", "1", "3", "1" }),
				new DataPoint("1", new String[] { "1", "1", "1", "4" }),
				new DataPoint("1", new String[] { "2", "3", "2", "5" }),
				new DataPoint("1", new String[] { "3", "2", "3", "5" }),
				new DataPoint("1", new String[] { "1", "1", "2", "3" }),
				new DataPoint("2", new String[] { "1", "3", "2", "1" }),
				new DataPoint("2", new String[] { "3", "1", "2", "3" }),
				new DataPoint("2", new String[] { "3", "4", "3", "2" }),
				new DataPoint("2", new String[] { "1", "3", "3", "4" }));
		DataSet dataSet = new DataSet(Arrays.asList("F1", "F2", "F3", "F4"), dataPoints);
		List<Rule> rules = clip.generate(dataSet);
		Assert.assertNotNull(rules);

		display("data set 2", rules);
	}

	private void display(String name, List<Rule> rules) {
		System.out.println("...::: " + name + " :::...");
		for (Rule rule : rules) {
			System.out.println(rule);
		}
		System.out.println();
	}
}
