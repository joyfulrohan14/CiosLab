function RuleOut=test2(filename)

% filename = input('Enter name of file:  ', 's');
% fprintf('testing the supplied dataset\n');
file = strcat('.\',filename);
% NumberAtt = input('Enter the number of attributes: ', 'd');
% NoofAtt = str2num(NumberAtt);
nRulX=1;

[At1, At2, At3, At4, Class] = textread(file,'%s %s %s %s %s', 2, 'delimiter',',');
Attribute{1}=At1{2};
Attribute{2}=At2{2};
Attribute{3}=At3{2};
Attribute{4}=At4{2};

[F1 F2 F3 F4 F5] = textread(file,'%s %s %s %s %s','delimiter',',','headerlines',3);
Data = [F1 F2 F3 F4 F5]; %Data = csvread(file,3,0);
% convert Data to numbers?
X=Data(:, 1:size(Data,2)-1); %% features
response=Data(:, size(Data,2)); %% responses column

c=unique(response); %% classes
% numInEachF=zeros(1, size(X, 2));
% for i=1:length(numInEachF)
%     numInEachF(i)=length(unique(X(:,i)));
% end

for z=1:length(c)

StopThresh=1;

fornotZ = 1:length(c);
presponse = c(z); %'Buy'; %input('Which class is your positive class? Enter response: ','s');
nresponse = c(setdiff(fornotZ,z)); %'Not buy'; %input('Which class is your negative class? Enter response: ','s');
pc=1;
nc=1;

N(1)=1;
for i=1:length(response)
    if strcmp(response(i),presponse)
        pos{N(1)}(pc,:) = Data(i,:);
        pc=pc+1;
    end
    for l=1:size(nresponse,1)
        if strcmp(response(i),nresponse(l))
            neg(nc,:) = Data(i,:);
            nc=nc+1;
        end
    end
end
pos1 = pos{1};
PosPrs = pos;
nRul=1;

while ~isempty(PosPrs) % (1)
    N(1)=1;
    pos1 = pos{1};
    PosPrs={};
%PhaseI
for i=1:size(neg,1)
  for j=1:N(i)  
    for k=1:size(X,2)
        for l=1:size(pos{j},1)
            if strcmp(pos{j}(l,k),neg(i,k))||strcmp(pos{j}(l,k),'*')||strcmp(neg(i,k),'*')
                bin(l,k)=0;
            else if ~strcmp(pos{j}(l,k),neg(i,k))
                    bin(l,k)=1;
                end
            end
        end
    end
    sol{j} = solveSCprob(bin);
  end
 %prune matrices
 %apply genetic operators
 N(i+1)=0;
 
 % ----------------------------Split Pos Matrix-------------------
 for j=1:N(i)
     %if pos not pruned or redundant
     seleF = find(sol{j});
     for k = 1:length(seleF)
         N(i+1)=N(i+1)+1;
         m=1;
         for l=1:size(pos{j},1)
             if ~strcmp(neg(i,seleF(k)),pos{j}(l,seleF(k)))
                 posleaf{N(i+1)}(m,:)= pos{j}(l,:);
                 m=m+1;
             end
         end
     end
 end
 
 if exist('posleaf')
     N(i+1)=size(posleaf,2);
     % Remove redundant matrix
     if N(i+1) >1
         for j=1:N(i+1)
             for k=1:N(i+1)
                 if k~=j && ~isempty(posleaf{k})
                     matchBrows(:,k) = compareMatrix(posleaf{k},posleaf{j});
                 end
             end
             if exist('matchBrows')
                 if ~isempty(find(sum(matchBrows,1)==size(posleaf{j},1)))
                     posleaf{j} = [];
                 end
                 clear matchBrows
             end
         end
         m=1;
         for j=1:N(i+1)
             if ~isempty(posleaf{j})
                 intactLeav{m}=posleaf{j};
                 m=m+1;
             end
         end
         pos = intactLeav;
     else
         pos = posleaf;
     end
     else return
 end
 % ---------------------------------------------------------
 
 N(i+1)=size(pos,2);
 clear posleaf intactLeav
end

%PhaseII
clear bin sol

if N(size(neg,1)+1)>1
    for j=1:N(size(neg,1)+1)
     for k=1:size(pos1,1)
         for l=1:size(pos{j},1)
             if strcmp(pos1(k,:),pos{j}(l,:))
                 TM(k,j)=1;
    %          else
    %              TM(k,j)=0;
             end
         end
     end
    end
    sol = solveSCprob(TM);
    ind=find(sol);
    for lol=1:length(ind)
        newPos{lol}=pos{ind(lol)};
    end
    pos=newPos;
    clear TM sol
end
N(i+1)=size(pos,2);

for j=1:N(size(neg,1)+1)
    for l=1:size(neg,1)
        for k=1:size(pos{j},1)
              tempBin(k,:) = (strcmp(pos{j}(k,1:size(pos{j},2)-1),neg(l,1:size(neg,2)-1)));
         end
         bin{j}(l,:) = sum(tempBin,1);
         clear tempBin;
    end
     bin{j}(find(bin{j}>0))=7986;
     bin{j}(find(bin{j}==0))=1;
     bin{j}(find(bin{j}==7986))=0;
     
 sol{j} = solveSCprob(bin{j});
end

for j=1:N(size(neg,1)+1)
s=1; 
 for k=1:size(pos1,2)-1
     recuRule=[];
     if sol{j}(k)==1
         for l=1:size(neg,1)
             if bin{j}(l,k)==1
                 for n=1:(l-1)
                     recuRule(n)=strcmp(neg(l,k),neg(n,k));
                 end
                 if isempty(find(recuRule))
                     rule{j}{s} = strcat(Attribute{k},'!=',neg(l,k));
                     F{j}(s)=k;
                     notVal{j}{s} = neg(l,k);
                     s=s+1;
                 end
             end
         end
     end
 end
end

clear bin sol

addedRows=[];
%PHASE III
for j=1:size(F,2)
mm=1;
    for k=1:size(F{j},2)
        for l=1:size(pos1,1)
            if isempty(find(addedRows==l)) && strcmp(pos1{l,F{j}(k)},notVal{j}{k})
                PosPrs{j}(mm,:) = pos1(l,:);
                addedRows(mm)=l;
                mm=mm+1;
            end
        end
    end
end

if ~isempty(PosPrs)
    for j=1:size(PosPrs,2)
        uncovRows(j) = size(PosPrs{j},1);
    end
    rul2keep = find(uncovRows==min(uncovRows),1);
    rule2 = rule{rul2keep};
    PosPr = PosPrs{rul2keep};
    pos{1} = PosPr;
else
    rule2 = rule{1};
end

% Rules{z}{nRul} = rule2;
% nRul=nRul+1;
% nRul

strin='';
for k=1:length(rule2)-1
    strin=strcat(strin, rule2{k}, ' AND ');
end
strin=strcat(strin, rule2{length(rule2)}, ' THEN', c{z});
RuleOut{nRulX}=strin;
display(strin);

nRulX=nRulX+1;
clear rule notVal F N uncovRows strin

% if size(pos,1)<StopThresh || isempty(PosPr)
%     break 
% end
end
clear pos neg rule2
end
