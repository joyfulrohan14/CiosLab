function matchBrows = compareMatrix(A,B)
rA=size(A,1);
rB=size(B,1);
matchBrows = zeros(size(B,1),1);
for l=1:rB
    for k=1:rA
        comp=strcmp(A(k,:),B(l,:));
        compv(k) = sum(comp)==size(B,2);
    end
    matchBrows(l)=~isempty(find(compv));
end