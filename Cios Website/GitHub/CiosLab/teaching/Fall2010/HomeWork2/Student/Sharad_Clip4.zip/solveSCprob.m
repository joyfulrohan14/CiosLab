function sol = solveSCprob(bin)

% Remove the row with all zeros
for ll=1:size(bin,1)
    zroT(ll)=sum(bin(ll,:)==0)==size(bin,2);
end
nonZeroRows=find(zroT==0);
if ~isempty(nonZeroRows)
    conrow=1;
    for ll=1:length(nonZeroRows)
        nTM(conrow,:)=bin(nonZeroRows(ll),:);
        conrow=conrow+1;
    end
    bin=nTM;
end

if ~isempty(find(bin==1))
 %remove empty rows

sol = zeros(1,size(bin,2));
inaR=[];
tempbin = bin;
Bin=bin;

while length(inaR) < size(bin,1)
%'bin' below has active rows only
bin = tempbin;
tempbin=[];

numInEachR = zeros(size(bin,1),1);
for i=1:size(bin,1)
    numInEachR(i) = sum(bin(i,:),2);
end
minR = find(numInEachR==min(numInEachR));
numInEachC = zeros(1,size(bin,2));
for j=1:size(bin,2)
    numInEachC(j) = sum(bin(minR,j),1);
end
maxC = find(numInEachC==max(numInEachC));
if length(maxC)>1
    numInMaxC_actR = zeros(1,max(maxC));
    for k=1:length(maxC)
    numInMaxC_actR(1,maxC(k)) = sum(bin(:,maxC(k)),1);
    end
    maxmaxC = find(numInMaxC_actR==max(numInMaxC_actR));
else
sol(1,maxC) = 1;
end

if exist('maxmaxC')
if length(maxmaxC)>1
    if ~isempty(inaR)
        numInMaxmaxC_inaR = zeros(1,max(maxmaxC));
        for k=1:length(maxmaxC)
        numInMaxmaxC_inaR(maxmaxC(k)) = sum(Bin(inaR,maxmaxC(k)),1);
        end
        maxmaxC_minInaR = find(numInMaxmaxC_inaR(:,maxmaxC)==min(numInMaxmaxC_inaR(:,maxmaxC)),1);
        maxmaxC_minInaR = maxmaxC(maxmaxC_minInaR);
    else
        maxmaxC_minInaR = min(maxmaxC);
    end
    sol(1,maxmaxC_minInaR) = 1;
else
sol(1,maxmaxC) = 1;
end
end
    [inar f] = find(bin(:,find(sol==1))==1);
    cover = length(inaR);
    for o=1:size(inar,1)
        inaR(cover+o,:) = inar(o,:);
    end
    m=1;
    for l=1:size(bin,1)
        if isempty(find(l==inaR))
            tempbin(m,:) = bin(l,:);
            m=m+1;
        end
    end
end
end