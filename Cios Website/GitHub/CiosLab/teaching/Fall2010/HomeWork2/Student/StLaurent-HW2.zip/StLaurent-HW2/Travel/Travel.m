%Homework 2
%Initialize POSij and NEG N
%eval([ 'Bin' num2str(i) ' = Bin;' ]);
load('POS.mat');
load('NEG.mat');
load('TravelData.mat');
load('Labels.mat');
load('Labels2.mat');
POS0=POS;
NEG0=NEG;
i = 1;
for k=1:size(NEG,2)
    for L=1:size(POS,1)
    if POS(L,k) == NEG (i,k)
        Bin(L,k) = 0;
    end
    if POS(L,k) ~= NEG (i,k)
        Bin(L,k) = 1;
    end
    eval([ 'Bin' num2str(i) ' = Bin;' ]);                      
end 
end
%SOL Calc
    Lenr=size(Bin1,1);
    Lenc=size(Bin1,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin1));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin1(a,:))
            sumb1 = sum(Bin1(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin1(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
        %keyboard
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end       
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin1));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin1(holdmatrix(1),c) + Bin1(holdmatrix(2),c)+ Bin1(holdmatrix(3),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end    
      POS2 = POS;
      e = 0;
      Lenr = size(POS2,1);
      while Lenr > e 
         e = e + 1;
        if POS2(e,1) == SOL(1,1)
            POS2(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End      
     i = 2;
for k=1:size(NEG,2)
    for L=1:size(POS2,1)
    if POS2(L,k) == NEG (i,k)
        Bin2(L,k) = 0;
    end
    if POS2(L,k) ~= NEG (i,k)
        Bin2(L,k) = 1;
    end                    
end 
end   
   %SOL Calc
    Lenr=size(Bin2,1);
    Lenc=size(Bin2,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin2));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin2(a,:))
            sumb1 = sum(Bin2(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin2(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end      
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin2));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin2(holdmatrix(1),c) + Bin1(holdmatrix(2),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS4 = POS2;
      e = 0;
      Lenr = size(POS4,1);
      while Lenr > e 
         e = e + 1;
        if POS4(e,1) == SOL(1,1)
            POS4(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End      
           i = 3;
for k=1:size(NEG,2)
    for L=1:size(POS4,1)
    if POS4(L,k) == NEG (i,k)
        Bin4(L,k) = 0;
    end
    if POS4(L,k) ~= NEG (i,k)
        Bin4(L,k) = 1;
    end                     
end 
end 
      %SOL Calc
    Lenr=size(Bin4,1);
    Lenc=size(Bin4,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin4));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin4(a,:))
            sumb1 = sum(Bin4(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin4(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end      
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin4));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin4(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS6 = POS4;
      e = 0;
      Lenr = size(POS6,1);
      while Lenr > e 
         e = e + 1;
        if POS6(e,1) == SOL(1,1)
            POS6(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End    
i = 4;
for k=1:size(NEG,2)
    for L=1:size(POS6,1)
    if POS6(L,k) == NEG (i,k)
        Bin6(L,k) = 0;
    end
    if POS6(L,k) ~= NEG (i,k)
        Bin6(L,k) = 1;
    end                    
end 
end 

  %SOL Calc
    Lenr=size(Bin6,1);
    Lenc=size(Bin6,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin6));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin6(a,:))
            sumb1 = sum(Bin6(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin6(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end      
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin6));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin6(holdmatrix(1),c)+ Bin6(holdmatrix(2),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 0;
            SOL(1,Lenc) = 1;
        end
      POS8 = POS6;
      %Prune the matrix
      e = 0;
      Lenr = size(POS8,1);
      while Lenr > e 
         e = e + 1;
        if POS8(e,1) == SOL(1,1)
            POS8(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      SOL1=SOL;
      %SOL End
      %Final Bi 
for kk=1:size(NEG,2)
      for z=1:size(NEG,1)        
          for zz=1:size(POS8,1)
            if NEG(z,kk) ~= POS8(zz,kk)
               NEG1(z,kk) = NEG(z,kk);
           end
           if NEG(z,kk) == POS8(zz,kk)
               NEG1(z,kk) = 0;
           end  
              
          end
      end  
end  
 
% Rule display pattern 0001 with Neg1
disp('If')
for d=1:4
    if SOL(1,d) == 1
        disp(Labels(1,d))
        temp=unique(NEG1(:,d));
        
      for zzz = 1:size(temp,1)
          if temp(zzz,1) ~= 0
             disp(Labels2(temp(zzz,1),d))
             if zzz < size(temp,1)
                disp('and')
             end
          end
      end
    end
    if SOL(1,(d))== 1 && d < size(SOL,2 ) 
        disp('and')
    end
end
disp(' then Decision = Buy')

%slide one NEG row over POS Matrix create Bins
i = 1;
for k=1:size(NEG,2)
    for L=1:size(POS,1)
    if POS(L,k) == NEG (i,k)
        Bin(L,k) = 0;
    end
    if POS(L,k) ~= NEG (i,k)
        Bin(L,k) = 1;
    end
    eval([ 'Bin' num2str(i) ' = Bin;' ]);                     
end 
end
%keyboard
%SOL Calculation
    Lenr=size(Bin1,1);
    Lenc=size(Bin1,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin1));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin1(a,:))
            sumb1 = sum(Bin1(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin1(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
        %keyboard
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end      
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin1));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin1(holdmatrix(1),c) + Bin1(holdmatrix(2),c)+ Bin1(holdmatrix(3),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      %keyboard
      POS3 = POS;
      e = 0;
      Lenr = size(POS3,1);
      while Lenr > e 
         e = e + 1;
        if POS3(e,1) == SOL(1,1)+ SOL(1,1)
            POS3(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End  
     i = 2;
for k=1:size(NEG,2)
    for L=1:size(POS3,1)
    if POS3(L,k) == NEG (i,k)
        Bin3(L,k) = 0;
    end
    if POS3(L,k) ~= NEG (i,k)
        Bin3(L,k) = 1;
    end                    
end 
end   
   %SOL Calc
    Lenr=size(Bin3,1);
    Lenc=size(Bin3,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin3));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin3(a,:))
            sumb1 = sum(Bin3(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin3(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end     
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin3));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin3(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end     
      POS5 = POS3;
      e = 0;
      Lenr = size(POS5,1);
      while Lenr > e 
         e = e + 1;
        if POS5(e,1) == SOL(1,1)* 3
            POS5(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End
           i = 3;
for k=1:size(NEG,2)
    for L=1:size(POS5,1)
    if POS5(L,k) == NEG (i,k)
        Bin5(L,k) = 0;
    end
    if POS5(L,k) ~= NEG (i,k)
        Bin5(L,k) = 1;
    end                    
end 
end 
      %SOL Calc
    Lenr=size(Bin5,1);
    Lenc=size(Bin5,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin5));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin5(a,:))
            sumb1 = sum(Bin5(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin5(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end      
    end
    
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin5));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin5(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS7 = POS5;
      %keyboard
      e = 0;
      Lenr = size(POS7,1);
      while Lenr > e 
         e = e + 1;
        if POS7(e,1) == SOL(1,1)*2
            POS7(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End    

i = 4;
for k=1:size(NEG,2)
    for L=1:size(POS7,1)
    if POS7(L,k) == NEG (i,k)
        Bin7(L,k) = 0;
    end
    if POS7(L,k) ~= NEG (i,k)
        Bin7(L,k) = 1;
    end                    
end 
end 

  %SOL Calc
    Lenr=size(Bin7,1);
    Lenc=size(Bin7,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin7));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin7(a,:))
            sumb1 = sum(Bin7(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin7(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end     
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin7));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin7(holdmatrix(1),c)+ Bin7(holdmatrix(2),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS9 = POS7;
      %Prune the matrix
      e = 0;
      Lenr = size(POS9,1);
      while Lenr > e 
         e = e + 1;
        if POS9(e,1) == SOL(1,1)*2
            POS9(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End
for kk=1:size(NEG,2)
      for z=1:size(NEG,1)
          for zz=1:size(POS9,1)
            if NEG(z,kk) ~= POS9(zz,kk)
               NEG2(z,kk) = NEG(z,kk);
           end
           if NEG(z,kk) == POS9(zz,kk)
               NEG2(z,kk) = 0;
           end  
              
          end
      end
    
end  
% Rule display
disp('If')
for d=1:4
    if SOL(1,d) == 1
        disp(Labels(1,d))
        temp=unique(NEG2(:,d));
        
      for zzz = 1:size(temp,1)
          if temp(zzz,1) ~= 0
             disp(Labels2(temp(zzz,1),d))
             if zzz < size(temp,1)
                disp('and')
             end
          end
      end
    end
    if d < size(SOL,2 ) && SOL(1,(d+1))== 1
        disp('and')
    end
end
disp(' then Decision = Buy')
clear
load('POSr.mat');
load('NEGr.mat');
load('Labels.mat');
load('Labels2.mat');
POS=POSr;
NEG=NEGr;
%slide one NEG row over POS Matrix create Bins
i = 1;
for k=1:size(NEG,2)
    for L=1:size(POS,1)
    if POS(L,k) == NEG (i,k)
        Bin(L,k) = 0;
    end
    if POS(L,k) ~= NEG (i,k)
        Bin(L,k) = 1;
    end
    eval([ 'Bin' num2str(i) ' = Bin;' ]);                     
end 
end
%keyboard
%SOL Calculation
    Lenr=size(Bin1,1);
    Lenc=size(Bin1,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin1));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin1(a,:))
            sumb1 = sum(Bin1(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin1(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
        %keyboard
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end     
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin1));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin1(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      %keyboard
      POS3 = POS;
      e = 0;
      Lenr = size(POS3,1);
      while Lenr > e 
         e = e + 1;
        if POS3(e,1) == SOL(1,1)+ SOL(1,1)
            POS3(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End   
     i = 2;
for k=1:size(NEG,2)
    for L=1:size(POS3,1)
    if POS3(L,k) == NEG (i,k)
        Bin3(L,k) = 0;
    end
    if POS3(L,k) ~= NEG (i,k)
        Bin3(L,k) = 1;
    end                    
end 
end   
   %SOL Calc
    Lenr=size(Bin3,1);
    Lenc=size(Bin3,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin3));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin3(a,:))
            sumb1 = sum(Bin3(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin3(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end    
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin3));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin3(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end      
      POS5 = POS3;
      e = 0;
      Lenr = size(POS5,1);
      while Lenr > e 
         e = e + 1;
        if POS5(e,1) == SOL(1,1)* 3
            POS5(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End
           i = 3;
for k=1:size(NEG,2)
    for L=1:size(POS5,1)
    if POS5(L,k) == NEG (i,k)
        Bin5(L,k) = 0;
    end
    if POS5(L,k) ~= NEG (i,k)
        Bin5(L,k) = 1;
    end                  
end 
end 
      %SOL Calc
    Lenr=size(Bin5,1);
    Lenc=size(Bin5,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin5));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin5(a,:))
            sumb1 = sum(Bin5(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin5(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end    
    end   
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin5));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin5(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS7 = POS5;
      %keyboard
      e = 0;
      Lenr = size(POS7,1);
      while Lenr > e 
         e = e + 1;
        if POS7(e,1) == SOL(1,1)*2
            POS7(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End    
i = 4;
for k=1:size(NEG,2)
    for L=1:size(POS7,1)
    if POS7(L,k) == NEG (i,k)
        Bin7(L,k) = 0;
    end
    if POS7(L,k) ~= NEG (i,k)
        Bin7(L,k) = 1;
    end
    %eval([ 'Bin' num2str(i) ' = Bin;' ]);
   
                      
end 
end 

  %SOL Calc
    Lenr=size(Bin7,1);
    Lenc=size(Bin7,2);
    holdmatrix = zeros(Lenr,1);
    sumb1 = sum(max(Bin7));%Initialize to high value
    for a = 1:Lenr
        if sumb1 > sum(Bin7(a,:))
            sumb1 = sum(Bin7(a,:));
        end
    end
    for a = 1:Lenr
        if sumb1==sum(Bin7(a,:))
            holdmatrix(a,1)= a;
        end
    end
    %Find SOL Columns
    b = 0;
    while Lenr > b 
         b = b + 1;
        if holdmatrix(b,1) == 0
            holdmatrix(b,:) = [];
            b = b-1;
            Lenr = Lenr-1;
        end     
    end
    %Solve SOL
    SOL = zeros(1,Lenc);
     sumb2 = sum(min(Bin7));%Initialize to low value
    for c = 1:Lenc
        sumb3 = Bin7(holdmatrix(1),c);
           if sumb3 > sumb2;
               sumb2 = sumb3;
               column = c;
            end
    end
        for d = 1:column
            SOL(1,d) = 1;
        end
      POS9 = POS7;
      %Prune the matrix
      e = 0;
      Lenr = size(POS9,1);
      while Lenr > e 
         e = e + 1;
        if POS9(e,1) == SOL(1,1)*2
            POS9(e,:) = [];
            e = e-1;
            Lenr = Lenr-1;
        end
      end
      %SOL End
      %Final Bi 
      %keyboard
for kk=1:size(NEG,2)
      for z=1:size(NEG,1)
        
          for zz=1:size(POS9,1)

            if NEG(z,kk) ~= POS9(zz,kk)
               NEG2(z,kk) = NEG(z,kk);
           end
           if NEG(z,kk) == POS9(zz,kk)
               NEG2(z,kk) = 0;
           end  
              
          end
      end   
end  
% Negative Rule display
disp('If')
for d=1:4
    if SOL(1,d) == 1
        disp(Labels(1,d))
        temp=unique(NEG2(:,d));
        
      for zzz = 1:size(temp,1)
          if temp(zzz,1) ~= 0
             disp(Labels2(temp(zzz,1),d))
             if zzz < size(temp,1)
                disp('and')
             end
          end
      end
    end
    if d < size(SOL,2 ) && SOL(1,(d+1))== 1
        disp('and')
    end
end
disp(' then Decision = Not Buy')

