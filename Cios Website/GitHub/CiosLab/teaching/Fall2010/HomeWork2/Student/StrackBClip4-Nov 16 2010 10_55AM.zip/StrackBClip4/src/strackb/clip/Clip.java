package strackb.clip;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Clip {
	StringMatrix Pos = new StringMatrix();
	StringMatrix Neg = new StringMatrix();
	String posCase;
	int pTereshold;

	Clip(StringMatrix data, String pos, int pter) {
		int n = data.ncols() - 1;
		pTereshold = pter;
		for (int i = 0; i < data.nrows(); i++) {
			if (data.get(i, n).equals(pos)) {
				String[] r = new String[n];
				for (int j = 0; j < n; j++) {
					r[j] = data.get(i, j);
				}
				Pos.add(r);
			} else {
				String[] r = new String[n];
				for (int j = 0; j < n; j++) {
					r[j] = data.get(i, j);
				}
				Neg.add(r);

			}
			posCase = pos;
		}
	}

	void solveClip(List<String> featname, FileWriter outFile)
			throws IOException {

		outFile.write("---------------------------------------------------------------------------------------\r\n ");
		outFile.write("Rules for positive case:   "
				+ featname.get(featname.size() - 1) + " = " + posCase + "\r\n");
		outFile.write("---------------------------------------------------------------------------------------\r\n \r\n");

		List<StringMatrix> tpos = new ArrayList<StringMatrix>();
		tpos.add(Pos);
		IntMatrix sol = new IntMatrix();
		for (int negnum = 0; negnum < Neg.nrows(); negnum++) { // dla kazdego
																// negatywnego
																// przykladu
			List<StringMatrix> temppos = new ArrayList<StringMatrix>();
			for (int mnum = 0; mnum < tpos.size(); mnum++) {// dla kazdej
															// macierzy na tpos
				StringMatrix matr = tpos.get(mnum);
				int rows = matr.nrows();
				sol = tpos.get(mnum).convert(Neg.getrow(negnum)); // rozwiazujemy
																	// problem
				sol = sol.solve();
				for (int i = 0; i < sol.ncols(); i++) { // tworzymy nowa macierz

					if (sol.get(0, i) == 1) {
						StringMatrix temp = new StringMatrix(matr);
						for (int row = rows - 1; row >= 0; row--) {
							if (matr.get(row, i).equals(Neg.get(negnum, i))) {
								temp.rem(row);
							}
						}
						if (isNotRedundand(temppos, temp)) {
							temppos.add(temp);
						}
					}
				}

			}
			tpos = temppos; // nowa lista macierzy do przeanalizowania
		}

		// Koniec PIERWSZEJ fazy
		IntMatrix tm = startPhase2(tpos).solve();

		for (int i = tpos.size() - 1; i >= 0; i--) {
			if (tm.get(0, i) == 0) {
				tpos.remove(i);
			}
		}

		for (StringMatrix m : tpos) {
			StringMatrix backNeg = new StringMatrix();
			IntMatrix bin = new IntMatrix();
			int cols = Neg.ncols();
			for (int r = 0; r < Neg.nrows(); r++) {
				String[] srow = new String[cols];
				Integer[] irow = new Integer[cols];
				for (int c = 0; c < cols; c++) {
					if (m.isNotInColumn(c, Neg.get(r, c))) {
						srow[c] = Neg.get(r, c);
						irow[c] = 1;
					} else {
						irow[c] = 0;
						srow[c] = "!";
					}
				}
				backNeg.add(srow);
				bin.add(irow);
			}
			IntMatrix result = bin.solve();
			String rule = "IF ";
			for (int i = 0; i < result.ncols(); i++) {
				if (result.get(0, i) == 1) {
					List<String> used = new ArrayList<String>();

					for (int r = 0; r < backNeg.nrows(); r++) {
						String s = backNeg.get(r, i);
						if (!s.equals("!")) {
							if (!used.contains(s)) {
								rule = rule + featname.get(i) + " != " + s
										+ " AND ";
								used.add(s);
							}

						}
					}

				}
			}
			if (rule.length() > 3) {
				rule = rule.substring(0, rule.length() - 4);
				rule = rule + "THEN " + featname.get(featname.size() - 1)
						+ " = " + posCase;
				outFile.write(rule + "\r\n \r\n");
			}
		}

	}

	IntMatrix startPhase2(List<StringMatrix> posList) {
		IntMatrix res = new IntMatrix();
		for (int r = 0; r < Pos.nrows(); r++) {
			Integer[] row = new Integer[posList.size()];

			for (int c = 0; c < posList.size(); c++) {
				if (posList.get(c).has(Pos.getrow(r))) {
					row[c] = 1;
				} else {
					row[c] = 0;
				}

			}
			res.add(row);
		}
		return res;
	}

	boolean isNotRedundand(List<StringMatrix> all, StringMatrix m) {
		if (m.nrows() < pTereshold)
			return false;
		StringMatrix small, big;
		int srows =0;
		for(StringMatrix mall: all){
			if (mall.nrows()>m.nrows()){
				big = mall;
				small = m;
				srows = m.nrows();
			}else{
				big = m;
				small = mall;
				srows = mall.nrows();
			}
			int i = 0;
			while(i<srows && big.has(small.getrow(i))){
				i++;
			}
			if (i == srows){
				return false;
			}
		}
		
		return true;
	}

}
