package strackb.clip;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataLoader {
	String datasetname;
	List<String> featname = new ArrayList<String>();
	List<String> classname = new ArrayList<String>();
	StringMatrix d = new StringMatrix();

	public void load(String pathname) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(pathname));
		datasetname = in.readLine();
		String str;
		String[] strtable;
		str = in.readLine();
		strtable = str.split(",");
		int size = strtable.length;
		for (int i = 0; i < size; i++) {

			featname.add(strtable[i].trim());
		}
		str = in.readLine();
		while ((str = in.readLine()) != null) {
			strtable = str.split(",");
			for (int i = 0; i < strtable.length; i++) {
				strtable[i] = strtable[i].trim();
			}
			d.add(strtable);
			if (!classname.contains(strtable[size - 1])) {
				classname.add(strtable[size - 1]);
			}
		}
		in.close();
	}
}
