package strackb.clip;
import java.util.ArrayList;
import java.util.List;

public class IntMatrix {
	List<Integer[]> m = new ArrayList<Integer[]>();

	void add(Integer[] row) {
		m.add(row);
	}

	void rem(int num) {
		m.remove(num);
	}

	IntMatrix solve() {

		IntMatrix res = new IntMatrix();
		res.initZeros(this.ncols());

		List<Integer> active = new ArrayList<Integer>();
		List<Integer> usedCols = new ArrayList<Integer>();
		List<Integer> activeCols = new ArrayList<Integer>();
		for (int i = 0; i < this.nrows(); i++) {
			active.add(i);
		}

		for (int i = 0; i < this.ncols(); i++) {
			activeCols.add(i);
		}

		List<Integer> inActive = new ArrayList<Integer>();

		while (!active.isEmpty() && !activeCols.isEmpty()) {

			int min1Rows = getMin1Rows(active);
			List<Integer> minRows = new ArrayList<Integer>();
			for (Integer i : active) {
				int sum = sumRow(i);
				if (min1Rows == sum) {
					minRows.add(i);
				}
			}

			int max1col = getMax1Cols(minRows, usedCols, activeCols);
			List<Integer> maxCols = new ArrayList<Integer>();

			for (int nc = 0; nc < this.ncols(); nc++) {
				if (!usedCols.contains(nc)) {
					int sum = 0;

					for (Integer i : minRows) {
						sum += this.get(i, nc);
					}
					if (max1col == sum) {
						maxCols.add(nc);
					}
				}
			}

			List<Integer> maxMaxCols = new ArrayList<Integer>();

			if (maxCols.size() > 1) {
				int maxmax1col = getMax1Cols(active, usedCols, maxCols);

				for (Integer nc : maxCols) {
					int sum = 0;

					for (Integer i : active) {
						sum += this.get(i, nc);
					}
					if (maxmax1col == sum) {
						maxMaxCols.add(nc);
					}

				}

			} else {
				maxMaxCols = maxCols;

			}

			int idx = -1;

			if (maxMaxCols.size() > 1) {
				if (inActive.isEmpty()) {
					idx = maxMaxCols.get(0);
					res.set(0, idx, 1);
					usedCols.add(idx);
					activeCols.remove(activeCols.indexOf(idx));

				} else {
					int min = this.nrows() + 2;
					int colnum = -1;
					for (int nc = 0; nc < this.ncols(); nc++) {
						if (activeCols.contains(nc) && maxMaxCols.contains(nc)) {
							int sum = 0;

							for (Integer i : inActive) {
								sum += this.get(i, nc);
							}
							if (min > sum) {
								min = sum;
								colnum = nc;
							}
						}
					}
					idx = colnum;
					res.set(0, idx, 1);
					// System.out.println("set: " + idx);
					usedCols.add(colnum);
					activeCols.remove(activeCols.indexOf(colnum));

				}
			} else {
				idx = maxMaxCols.get(0);
				res.set(0, idx, 1);
				usedCols.add(idx);
				activeCols.remove(activeCols.indexOf(idx));

			}
			// uzupelnic aktywne i nieaktywne

			for (int row = 0; row < this.nrows(); row++) {
				if (this.get(row, idx) == 1) {

					if (active.contains(row)) {

						active.remove(active.indexOf(row));
						inActive.add(row);

					}
				}
			}

		}
		// res.print();
		return res;

	}

	void print() {
		for (int r = 0; r < this.nrows(); r++) {
			for (int c = 0; c < this.ncols(); c++) {
				System.out.print(get(r, c) + " ");
			}
			System.out.println();
		}
	}

	int getMax1Cols(List<Integer> rows, List<Integer> cols,
			List<Integer> actCols) {
		int max = 0;
		for (Integer nc : actCols) {
			if (!cols.contains(nc)) {
				int sum = 0;

				for (Integer i : rows) {
					sum += this.get(i, nc);
				}
				if (max < sum) {
					max = sum;
				}
			}
		}

		return max;
	}

	int getMin1Rows(List<Integer> act) {
		int min = this.ncols();
		for (Integer i : act) {
			int sum = sumRow(i);
			if (min > sum) {
				min = sum;
			}
		}

		return min;
	}

	int sumRow(int row) {
		int sum = 0;
		for (int i = 0; i < this.ncols(); i++) {
			sum += this.get(row, i);
		}
		return sum;
	}

	int get(int row, int col) {
		return m.get(row)[col];
	}

	void set(int row, int col, int value) {
		m.get(row)[col] = value;
	}

	void initZeros(int size) {
		Integer[] t = new Integer[size];
		for (int i = 0; i < size; i++) {
			t[i] = 0;
		}
		this.add(t);
	}

	int nrows() {
		return m.size();
	}

	int ncols() {
		return m.get(0).length;
	}

}
