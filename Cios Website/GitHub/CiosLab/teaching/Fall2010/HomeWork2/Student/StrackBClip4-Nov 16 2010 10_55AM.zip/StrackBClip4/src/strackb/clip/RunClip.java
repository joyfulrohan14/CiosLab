package strackb.clip;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class RunClip {

	
	public static void main(String[] args) {
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
		JFrame frame = new JFrame("Output");
		frame.setSize(800, 600);
		JScrollPane scroll = new JScrollPane(textArea);
		frame.add(scroll);
		frame.setVisible(true);

		try {
			FileWriter outFile = new FileWriter("output.txt");
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Select input file");
			fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fc.setCurrentDirectory(new File("."));
			int result = fc.showOpenDialog(null);
			
			int pruneTereshold = 2;
			
			textArea.append("Implementation of CLIP4 Algorithm - Beata Strack -\n - results will be both displayed in a window and saved in output file \n\n");
			
			try{
				BufferedReader parFile = new BufferedReader(
						new FileReader(new File("config.txt")));
				String line = parFile.readLine();
				String[] words = line.trim().split("\\s+");
				pruneTereshold = Integer.parseInt(words[1]);
			}catch (Exception e) {
				textArea.append("Config file not found or in improper format. Default settings applied.\n\n");
			}
			
			textArea.append("Noise tereshold:" + pruneTereshold+" \n\n");
			
			if (result == JFileChooser.APPROVE_OPTION) {
				DataLoader DL = new DataLoader();
				DL.load(fc.getSelectedFile().getAbsolutePath());
				outFile.write("Dataset name: " + DL.datasetname + "\r\n \r\n");

				for (String cl : DL.classname) {
					Clip C = new Clip(DL.d, cl, pruneTereshold);
					C.solveClip(DL.featname, outFile);
				}

				outFile.close();

				BufferedReader inOutFileReader = new BufferedReader(
						new FileReader(new File("output.txt")));
				try {

					String line = null;
					while ((line = inOutFileReader.readLine()) != null) {
						textArea.append(line + "\n");
					}

					textArea.append("-----------Output saved in output.txt file-----------");
				} finally {
					inOutFileReader.close();
				}
			}
		} catch (Exception e) {
			textArea.append("Something went wrong. Check your input file!");
			e.printStackTrace();

		}

	}

}
