package strackb.clip;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringMatrix {
	List<String[]> m = new ArrayList<String[]>();

	StringMatrix() {

	}

	StringMatrix(StringMatrix matr) {
		for (String[] row : matr.m) {
			this.add(row);
		}
	}

	void add(String[] row) {
		String[] r = new String[row.length];
		for (int i = 0; i < row.length; i++) {
			r[i] = row[i];
		}
		m.add(r);
	}

	void rem(int num) {
		m.remove(num);
	}

	int nrows() {
		return m.size();
	}

	int ncols() {
		return m.get(0).length;
	}

	String get(int row, int col) {
		return m.get(row)[col];
	}

	String[] getrow(int row) {
		return m.get(row);
	}

	void print() {
		for (int r = 0; r < this.nrows(); r++) {
			for (int c = 0; c < this.ncols(); c++) {
				System.out.print(get(r, c) + " ");
			}
			System.out.println();
		}
	}

	boolean has(String[] row) {
		for (String[] r : this.m) {
			if (Arrays.equals(row, r)) {
				return true;
			}
		}
		return false;
	}

	IntMatrix convert(String[] neg) {
		IntMatrix res = new IntMatrix();
		int ncols = this.ncols();
		for (int row = 0; row < this.nrows(); row++) {
			Integer[] r = new Integer[ncols];
			for (int c = 0; c < ncols; c++) {
				if ((neg[c].equals("*")) || (this.get(row, c).equals("*"))) {
					r[c] = 0;
				} else {
					if (neg[c].equals(this.get(row, c))) {
						r[c] = 0;
					} else {
						r[c] = 1;
					}
				}
			}
			res.add(r);
		}
		return res;
	}

	boolean isNotInColumn(int c, String string) {
		if (string.equals("*"))
			return false;
		for (String[] row : this.m) {
			if (row[c].equals(string)) {
				return false;
			}
		}
		return true;
	}
}
