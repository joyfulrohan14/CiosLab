package clip4;


import java.io.FileReader;
import java.io.BufferedReader;
public class clip4 
{


public void read()
{
	BufferedReader br=null;
	BufferedReader br1=null;
try
{
   br=new BufferedReader(new FileReader("C:\\Users\\raja\\vcu-mat\\data mining\\hw2\\test1w.txt"));
   br1=new BufferedReader(new FileReader("C:\\Users\\raja\\vcu-mat\\data mining\\hw2\\test1w.txt"));
   String input=null;
  ///* 
   String[] set1;
   int a2=0,a1=0;
   while((input=br1.readLine())!=null)
   {
	   set1=input.split("\\s");
	   a2=set1.length;
	   a1++;
   }
  // System.out.println("value of rows"+a1);
  // System.out.println("value of coloumns"+a2);
   // */
   int rows=0;
   int[][] userdata = new int [a1][a2];
     while((input=br.readLine())!=null)
     {
    	 String[] set2=input.split("\\s");
    	 for(int a=0;a<set2.length;a++ )
    	 {
    		 userdata[rows][a]=Integer.parseInt(set2[a]);
    	 }
    	 rows++;
     }
    //System.out.println("value of matrix at 1,1"+userdata[1][1]);   
    // matrix output
    /*
     for(int i=0;i<a1;i++)
    {
    	for(int j=0;j<a2;j++)
    	{
    		System.out.print(" "+userdata[i][j]);
    	}
    	System.out.println("");
    }
     */
    // divide the matrix into pos and neg
    int d=0,e=0;
    for(int c=0;c<a1;c++)
    {
      if(userdata[c][4]==1)
       {
    	d++;
    	//System.out.println("d is "+d);
       }
      else
       {
    	e++;
    	//System.out.println("e is "+e);
       }
    }
    int d1=a2-1;
    int[][] posdata = new int [d][d1];
    int[][] negdata = new int [e][d1];
    int f=0,g=0;
    for(int c1=0;c1<a1;c1++)
    {
      if(userdata[c1][4]==1)
       {
    	for(int c2=0;c2<d1;c2++)
    	{
    		posdata[f][c2]=userdata[c1][c2];
    	}
    	f++;
       }
      else
       {
    	  for(int c3=0;c3<d1;c3++)
      	{
      		negdata[g][c3]=userdata[c1][c3];
      	}
      	g++;
       }
    }
    
   /* for(int i=0;i<e;i++)
    {
    	for(int j=0;j<d1;j++)
    	{
    		System.out.print(" "+negdata[i][j]);
    	}
    	System.out.println("");
    } */
   
   
    
    int[][] binmatrix = new int[d][d1];
    int negvalue=0;
    for(int h=0;h<d;h++)
    {
    	for(int h1=0;h1<d1;h1++)
    	{
    		if(posdata[h][h1]==negdata[negvalue][h1])
    		{
    			binmatrix[h][h1]=0;
    		}
    		else
    		{
    			binmatrix[h][h1]=1;
    		}
    	}
    }
    
   for(int i=0;i<d;i++)
    {
    	for(int j=0;j<d1;j++)
    	{
    		//System.out.print(" "+binmatrix[i][j]);
    	}
    	//System.out.println("");
    }
   
 
    int mcount=0,mc1=0,mc2=0;
    for(int m=0;m<d;m++)
    {
    	for(int m1=0;m1<d1;m1++)
    	{
    		if(binmatrix[m][m1]==1)
    		{
    		mcount++;	
    		}
    	}
    	if(mc2==0)
    	{
    		mc1=mcount;
    	}
    	if(mc1>=mcount)
    	{
    		mc1=mcount;
    	}
    	mc2++;
    	mcount=0;
    	//System.out.println("count is "+mc1);
    }
    
    //System.out.println("count is "+mcount);
    int ncount=0,p=0,p1=0,n,n2,pn=0;
    int[] array1=new int[10];
    //int[] array2=new int[10];
    for(n=0;n<d;n++)
    {
    	for(n2=0;n2<d1;n2++)
    	{
    		if(binmatrix[n][n2]==1)
    		{
    			ncount++;
    		}
    	}
    	    //System.out.println("n count"+ncount);
    	    //System.out.println("n is"+n);
    	    //System.out.println("n2 is"+n2);
    	    if (ncount==mc1)
    		{
    		array1[p]=n;
    		
    		
    		p++;
    		p1++;
    		pn++;
    		}
    	ncount=0;
    	
    }
    
    //System.out.println("pn is"+pn);
    for(int r=0;r<pn;r++)
    {
    	//System.out.println("array1"+array1[r]);
    }
    
    
    int[][] array2=new int[1][d1];
    int mscount=0,ms1=0,ms2=0,ms,mxs=0;
    for(ms=0;ms<d1;ms++)
    {
    	for(int rt=0;rt<pn;rt++)
    	{
    		if(binmatrix[array1[rt]][ms]==1)
    		{
    		mscount++;	
    		}
    	}
    	//System.out.println("count is"+mscount);
    	if(ms1==0)
    	{
    		ms2=mscount;
    	}
    	if(ms2<mscount)
    	{
    		ms2=mscount;
    		
    		array2[0][ms]=1;	
    	//	System.out.println("col sc is "+ms);
    	    mxs=ms;	
    	}
    	ms1++;
    	mscount=0;
    }
    
      
    
        int it=0;
    	for(int j=0;j<d1;j++)
    	{
    		//System.out.print(" "+array2[it][j]);
    	}
    	//  System.out.println(""); 
    //System.out.println("ms is "+mxs);
    int[] array3=new int[10];
    int nt1=0,nt,nt2=0;
    for(nt=0;nt<d;nt++)
    {
    	if(array2[it][mxs]!=binmatrix[nt][mxs])
    	{
    		array3[nt1]=nt;
    		//System.out.println("nt is "+nt);
    		nt1++;
    		nt2++;
    	}
    
    }
    int[] posarray1 = new int[10];
    int dk1=0;
    for(int dk=0;dk<d;dk++)
    {
    	posarray1[dk1]=posdata[dk][mxs];
        dk1++;
    }
    
    for(int kd=0;kd<d;kd++)
    {
    	//System.out.println("pos array is"+posarray1[kd]);
    }
    int dg=d;
    
    int vc1=0;
    for(int vc=1;vc<dg;vc++)
    {
    	if (posarray1[vc]!=posarray1[vc1])
    	{
           vc1++;
           posarray1[vc1]=posarray1[vc];
    	}
    	
    }
    dg=vc1+1;

    for(int kp=0;kp<dg;kp++)
    {
    	//System.out.println("pos array dup is"+posarray1[kp]);
    }
    
    // printing the results
    
    System.out.println("The result is ");
    System.out.print("if ");
    for(int kp1=0;kp1<dg;kp1++)
    {
    System.out.print(" coloumn "+mxs+"!="+posarray1[kp1]);	
    }
    System.out.print(" then true(buy/play)");
    
    
    	
    
}
catch(Exception ex)
{
   System.out.println(ex);
}

}


public static void main(String[] args)
{
clip4 abc=new clip4();
abc.read();

}
}