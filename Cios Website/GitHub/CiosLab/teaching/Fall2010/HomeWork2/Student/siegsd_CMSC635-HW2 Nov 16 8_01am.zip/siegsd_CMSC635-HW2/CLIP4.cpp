/*
 Author: Sam Sieg
 Project: An implementation of the CLIP4 algorithm for rule learning, a step in the data mining processes
 Date: 11/03/10
 Language: C++
 Compiler: gcc version 4.5.0 (GCC)

 Usage: CLIP4 infile.extension -(v,b) -c nameOfClassSignifier
 			This program axpects a comma delimited file of the following format

 		1	Project Name
 		2	Column Heading 1,Column Heading 2,...,Column Heading N
 		3	Data Type 1,Data Type 2,...,Data Type N
 		4	Data Point 1 Info,...,Final info for data point 1
 		5	Data Point 2 Info,...,Final info for data point 2
 			.
 			.
 			.

 		Valid data types are
 			Integer String Real ClassName

		DO NOT use commas in any data cell as commas are used as delimiters

		The data file should already be descritized, if desired.

		The v option "verbose" is enabled by default and will print ou t a list of the descritized ranges for each feature.
		The b option "brief" will disable analitic output
		The c option "class" tells the program the name of the column signifying which data paoints are in which class
*/

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
#include <string>
#include <cmath>
#include <climits>
#include <vector>
#include <list>

using namespace std;

template <class T> void QuickSort(T* array, int startIndex, int endIndex);
template <class T> int SplitArray(T* array, T pivotValue, int startIndex, int endIndex);
template <class T, class U> void QuickSort2(T* arr, U* brr, int startIndex, int endIndex);
template <class T, class U> int SplitArray2(T* arr, U* brr, T pivotValue, int startIndex, int endIndex);
template <class T> double CAIM(T* dataV, string* dataC, int* indexC, list<string> uniqueC, list<double> bounds);

void usage()
{
	cout<<" Author: Sam Sieg\n Project: An implementation of the CLIP4 algorithm for rule learning, a step in the data mining processes\n Date: 11/03/10\n Language: C++\n Compiler: gcc version 4.5.0 (GCC)\n\n Usage: CLIP4 infile.extension -(v,b) -c nameOfClassSignifier\n        	This program axpects a comma delimited file of the following format\n\n    1	Project Name\n    2	Column Heading 1,Column Heading 2,...,Column Heading N\n    3	Data Type 1,Data Type 2,...,Data Type N\n    4	Data Point 1 Info,...,Final info for data point 1\n    5	Data Point 2 Info,...,Final info for data point 2\n       .\n       .\n       .\n\n    Valid data types are\n    	Integer String Real ClassName\n\n    DO NOT use commas in any data cell as commas are used as delimiters\n\n    The data file should already be descritized, if desired.\n\n    The v option \"verbose\" is enabled by default and will print ou t a list of the descritized ranges for each feature.\n\n    The b option \"brief\" will disable analitic output\n\n    The c option \"class\" tells the program the name of the column signifying which data paoints are in which class\n\n";
}

string toLower(string in)
{
	for (int j=0; j<in.length(); ++j)
	{
		in[j]=tolower(in[j]);
	}
	return in;
}

string toUpper(string in)
{
	for (int j=0; j<in.length(); ++j)
	{
		in[j]=toupper(in[j]);
	}
	return in;
}

enum DATATYPE {INTEGER, REAL, STRING, CLASSNAME};

struct Feature
{
	int intdata;
	double realdata;
	string stringdata;
};

int numFeatures;
int numDescFeatures;
int numData;
int numClasses=0;
int classIndex=-1;

string datasetName;

vector<string> featureNames;
vector<string> typeNames;
vector<DATATYPE> featureTypes;
vector<vector<Feature> > dataPoints;//outter is the list of data points, inner is the list of values for a single data point

vector<vector<string> > stringVals;//this is a list of the unique possible values for each string feature
							   //outter in the list of features, inner is the list of possible values for that feature
							   //to make things easy, the feature indicies are the same in this list as for the data point list
							   //non-string fatures will simply have a single item in their vector, the string "CLIP4NULL".
string sc_stringVectorNull="CLIP4NULL";

bool verbose=false;
bool gotClassColumn=false;
string OutFileName="rules.txt";
string InFileName="";
string className="";
fstream file;

ostream& printData(ostream& out=std::cout);
vector<int> solveSCproblem(vector<vector<int> > BIN);

template <class T> ostream& printList(list<T> l, ostream& out=std::cout)
{
	out<<"?\"";
	for(typename list<T>::iterator it=l.begin();it!=l.end();it++)
	{
		out<<(*it)<<"    ";
	}
	out<<"\"?\n";
	return out;
}

template <class T> ostream& printArray(T* arr, unsigned int sz, ostream& out=std::cout)
{
	out<<"?\"";
	for(int i=0;i<sz;i++)
	{
		out<<arr[i]<<"    ";
	}
	out<<"\"?\n";
	return out;
}

template <class T> int inVector(vector<T> source, T target)
{
	int toret=-1;
	int count=0;
	typename vector<T>::iterator listit=source.begin();
	typename vector<T>::iterator theend=source.end();
	while(listit != theend)
	{
		if((*listit)!=target)
		{
			count++;
			listit++;
		}
		else
		{
			toret=count;
			listit=theend;
		}
	}
	return toret;
}

int main(int argc, char* argv[])
{
	bool DEBUG1=true;
	bool DEBUG2=false;

	//This code checks for command line parameters.
	if(argc<2)
	{
		cout<<"Error: no input file named ...\n\n";
		usage();
		return 1;
	}
	else if(argc > 6)
	{
		cout<<"Error: too many arguments to CLIP4.exe\n\n";
		usage();
		return 1;
	}
	else
	{
		bool gotInput=false;
		for(int x=1; x < argc; x++)
		{
			//this option supresses verbose output
			if(strcmp(argv[x],"-b")==0)
			{
				verbose=false;
			}
			//this option enables verbose output
			else if(strcmp(argv[x],"-v")==0)
			{
				verbose=true;
			}
			//this option sets the class name to check for
			else if(strcmp(argv[x],"-c")==0)
			{
				x++;
				if(x>=argc)
				{
					cout<<"Error: see usage for -c option\n\n";
					usage();
					return 1;
				}
				className=toLower(argv[x]);
			}
			//this looks for the filenames the command should be getting
			else
			{
				if(!gotInput)
				{
					gotInput=true;
					InFileName=argv[x];
				}
				else
				{
					if(verbose)cout<<"Erroneous command line parameter \""<<argv[x]<<"\" being ignored\n";
				}
			}
		}
	}//done with command line args

	//try to open input file
	file.open(InFileName.c_str(),fstream::in);
	if(file.fail())
	{
		cout<<"Failure to open "<<InFileName<<"\n\n";
		return 2;
	}

	//read in data
	bool done=false;
	string input;

	//get title
	getline(file,datasetName);
	if(!file.good())
	{
		cout<<"Error: Bad file format for "<<InFileName<<"\n\n";
		return 2;
	}

	//get feature names
	getline(file,input);
	if(!file.good())
	{
		cout<<"Error: No feature names (column headers) in "<<InFileName<<"\n\n";
		return 2;
	}
	char * tok;
	tok = strtok ((char*)input.c_str(),",");
	while (tok != NULL)
	{
		featureNames.push_back(tok);
		numFeatures++;
		tok = strtok(NULL, ",");
	}

	//get feature type
	getline(file,input);
	if(!file.good())
	{
		cout<<"Error: No type names (integer, real, etc.) in "<<InFileName<<"\n\n";
		return 2;
	}
	tok = strtok ((char*)input.c_str(),",");
	int clcnt=0;
	while (tok != NULL)
	{
		typeNames.push_back(tok);//store the name used by the data file for this feature
		tok=(char *)toLower(tok).c_str();
		vector<string> temp;
		//find out if it is a type we recognize and need to process
		if(strcmp(tok,"integer")==0 || strcmp(tok,"int")==0 || strcmp(tok,"i")==0)
		{
			featureTypes.push_back(INTEGER);
			temp.push_back(sc_stringVectorNull);
		}
		else if(strcmp(tok,"real")==0 || strcmp(tok,"double")==0 || strcmp(tok,"float")==0 || strcmp(tok,"floating point")==0 || strcmp(tok,"r")==0 || strcmp(tok,"f")==0 || strcmp(tok,"d")==0)
		{
			featureTypes.push_back(REAL);
			temp.push_back(sc_stringVectorNull);
		}
		else if(strcmp(toLower(featureNames[clcnt].c_str()).c_str(),className.c_str())==0)
		{
			gotClassColumn=true;
			featureTypes.push_back(CLASSNAME);
			if(classIndex<0)
			{
				classIndex=clcnt;
			}
			else
			{
				cout<<"Error in data file. More than one column declaring classname\n\n";
				return 3;
			}
		}
		else//it is either a string or not a type this program recognizes
		{
			featureTypes.push_back(STRING);
		}
		stringVals.push_back(temp);
		clcnt++;
		tok = strtok(NULL, ",");
	}
	if(!gotClassColumn)
	{
		//cout<<"Error: no column with "<<className<<" found. Use option -c to indicate the column header for classes\n\n";
		//usage();
		//return 1;
		//assume it is the last feature listed
		classIndex=numFeatures-1;
		featureTypes.pop_back();
		featureTypes.push_back(CLASSNAME);
		gotClassColumn=true;
		className=typeNames[numFeatures-1];
	}

	/**********************************************************

		figure out what the possible string values are
		and index them, then store everything as ints

	**********************************************************/

	//get the data points
	done=false;
	while(!done)
	{
		getline(file,input);
		if(input.length()>0)
		{
			int count=0;
			tok = strtok ((char*)input.c_str(),",");
			vector<Feature> temp;
			while(tok != NULL)
			{
				//find out what type of feature we are dealing with then store it
				Feature f;
				switch(featureTypes[count])
				{
					case REAL:f.realdata=atof(tok);
					case INTEGER:f.intdata=atoi(tok);

					//change these to use ints based on a search through the possible values list
					case STRING:
					case CLASSNAME:
					{
						//f.stringdata=tok;//removed this since its just extra storage space
						string temptok=tok;
						int findit=inVector(stringVals[count],temptok);
						if(findit>=0)
						{//string is already in unique list
							f.intdata=findit;//store index
						}
						else
						{//string is not in unique list
							stringVals[count].push_back(tok);//add to list
							f.intdata=stringVals[count].size()-1;//store index
							if(featureTypes[count]==CLASSNAME)//add to the number of classes if this is a class column
							{
								numClasses++;
							}
						}
					}break;
				}
				temp.push_back(f);
				//move to next feature
				count++;
				tok = strtok(NULL, ",");
			}
			dataPoints.push_back(temp);
		}
		if(!file.good())
		{
			done=true;
		}
	}
	file.close();

	numData=dataPoints.size();

	//debug
	//numClasses=1;
	//debug

	vector<vector<vector<vector<int> > > > allRules;
	//outter most layer is rules for class
	//next layer is the list of rules for that class
	//next two layers are the rules, first layer = column/feature, second layer = value that shouldn't be in feature

			//debug, should be 0
	for(int classCyc=0;classCyc<numClasses;classCyc++)
	{
		vector<vector<vector<int> > > classRules;

		//pre phaseI
		//make pos and neg mats
		vector<int> POS;
		vector<int> NEG;
		for(int i=0;i<numData;i++)
		{
			if(dataPoints[i][classIndex].intdata==classCyc)
			{
				POS.push_back(i);
			}
			else
			{
				NEG.push_back(i);
			}
		}
		//confirm that there are no entries that are in both POS and NEG
		for(int p=0;p<POS.size();p++)
		{
			for(int n=0;n<NEG.size();n++)
			{
				bool duplicate=true;
				for(int f=0;f<(numFeatures-1);f++)
				{
					if(dataPoints[NEG[n]][f].intdata != dataPoints[POS[p]][f].intdata)
						duplicate=false;
				}
				if(duplicate)
				{
					//remove the entry from both lists
					cout<<"Conflicting/duplicate entries: "<<POS[p]<<", "<<NEG[n]<<"\n";
					POS.erase(POS.begin()+p);
					p--;
					NEG.erase(NEG.begin()+n);
					n--;
				}
			}
		}
		//make the BIN matrix
		vector<vector<int> > POSmats;
		vector<vector<int> > newPOSmats;

		//begin phase I
		//************************
		while(POS.size()>0)
		{
			POSmats.clear();
			newPOSmats.clear();
			POSmats.push_back(POS);
			if(verbose)cout<<"****************************************\n    PHASE I\n\n";
			for(int negs=0;negs<NEG.size();negs++)//for each negative example
			{
				for(int PMcount=0;PMcount<POSmats.size();PMcount++)//for each current POS matrix
				{
					if(verbose)
					{
						//display the POS matrix
						cout<<"POS matrix\n";
						for(int bcc=0;bcc < POSmats[PMcount].size();bcc++)//for each row in the POS matrix
						{
							vector<int> bRow;
							for(int dcc=0;dcc<dataPoints[POSmats[PMcount][bcc]].size()-1;dcc++)//for each feature in the data point
							{
								cout<<"    "<<dataPoints[POSmats[PMcount][bcc]][dcc].intdata;
							}
							cout<<"\n";
						}
						cout<<"\n";

						cout<<"NEG [ ";
						for(int dcc=0;dcc<numFeatures-1;dcc++)//for each feature in the data point
						{
							cout<<dataPoints[NEG[negs]][dcc].intdata;
							if(dcc<(numFeatures-2))cout<<", ";
						}
						cout<<"]\n\n";
					}//end if verbose

					vector<int> SOL;//all zeros until we find the winning columns
					//make the BIN matrix
					vector<vector<int> > BIN;
					for(int bcc=0;bcc < POSmats[PMcount].size();bcc++)//for each row in the POS matrix
					{
						vector<int> bRow;
						int count=0;
						for(int dcc=0;dcc<numFeatures-1;dcc++)//for each feature in the data point
						{
							if(featureTypes[dcc]!=CLASSNAME)
							{
								bool bintest=false;
								switch(featureTypes[dcc])
								{
									case STRING:
									case INTEGER:
									{
										bintest=dataPoints[POSmats[PMcount][bcc]][dcc].intdata == dataPoints[NEG[negs]][dcc].intdata;
									}break;
									case REAL:
									{
										bintest=dataPoints[POSmats[PMcount][bcc]][dcc].realdata == dataPoints[NEG[negs]][dcc].realdata;
									}
									break;
								}
								if(bintest)
									bRow.push_back(0);
								else
								{
									bRow.push_back(1);
									count++;
								}
							}
						}
						if(count>0)BIN.push_back(bRow);
					}

					bool kludge=false;

					if(BIN.size()==0)
					{
						cout<<"Error: the BIN matrix for the SC problem algorithm contains no 1's.\n\n";
						//return 4;
						/*POSmats.erase(POSmats.begin()+PMcount);
						PMcount--;
						goto kludge;*/
						kludge=true;
					}

					if(!kludge)
					{

						if(verbose)
						{
							cout<<"\nBINmat\n";
							for(int i=0; i < BIN.size(); i++)
							{
								for(int j=0; j < BIN[i].size(); j++)
								{
									cout<<"    "<<BIN[i][j];
								}
								cout<<"\n";
							}
							cout<<"\n";
						}

						//now we have the BIN matrix. Find the solution vector
						if(verbose)cout<<"SOL = [ ";
						SOL=solveSCproblem(BIN);

						if(verbose)//if verbose then show solution for this BIN matrix
						{
							for(int i=0;i<SOL.size();i++)
							{
								cout<<SOL[i];
								if(i<(SOL.size()-1))cout<<", ";
							}
							cout<<"]\n\n";
						}

						//now that we have a solution, make any new POS matricies
						for(int s=0;s<SOL.size();s++)//for each entry in SOL
						{
							//if this column was one chosen for the solution
							if(SOL[s]==1)
							{
								if(verbose)cout<<"new POS mat "<<s<<"\n";
								//create an empty new POS
								vector<int> tempPOS;
								//compare the negative value in the SOL column with the positive value in all POS columns.
								for(int pr=0;pr < POSmats[PMcount].size();pr++)
								{
									if(dataPoints[NEG[negs]][s].intdata != dataPoints[POSmats[PMcount][pr]][s].intdata)
									{
										tempPOS.push_back(POSmats[PMcount][pr]);
										if(verbose)//show us the new POS mat being made
										{
											for(int i=0;i<numFeatures-1;i++)
											{
												cout<<"    "<<dataPoints[POSmats[PMcount][pr]][i].intdata;
											}
											cout<<"\n";
										}
									}
								}
								if(verbose)cout<<"\n";
								//check to see if this pos matrix is already present in the new list
								bool dupdup=false;
								for(int pmc=0;pmc<newPOSmats.size();pmc++)
								{
									bool dupPOS=true;
									if(tempPOS.size()==newPOSmats[pmc].size())
									{
										for(int pr=0;pr<newPOSmats[pmc].size();pr++)
										{
											if(tempPOS[pr] != newPOSmats[pmc][pr])
											{
												dupPOS=false;
												pr=newPOSmats[pmc].size();
											}
										}
									}
									else
									{
										dupPOS=false;
									}
									if(dupPOS)//already exists
									{
										dupdup=true;
										pmc=newPOSmats.size();
									}
								}
								if(!dupdup)
								{
									newPOSmats.push_back(tempPOS);//only add the new pos mat if it isn't a duplicate
									if(verbose)
										cout<<"\tPOS mat added\n\n";
								}
								else if(verbose)
								{
									cout<<"\tduplicate POS mat not added\n\n";
								}
								//else//debug
								//{
								//	cout<<"\tduplicate POS mat not added\n\n";
								//}
							}
						}
					}
				}//end fpr each POS matrix

				//move any PMs from newPOSmats to POSmats
				POSmats.swap(newPOSmats);
				newPOSmats.clear();
				if(verbose)cout<<"****************\n\n";
			}//end for each negative example

			//begin phase II
			//************************

			if(verbose)cout<<"****************************************\n\n    PHASE II\n\n";

			vector<vector<int> > bestRule;//2xq matrix: first row has column/feature number, second row has value that feature shouldn't equal
			int ruleCover=0;

			//for each POS matrix
			for(int PMcount=0;PMcount<POSmats.size();PMcount++)//for each current POS matrix
			{
				if(verbose)//verbose display of POS matrix
				{
					//display the POS matrix
					cout<<"POS matrix\n";
					for(int bcc=0;bcc < POSmats[PMcount].size();bcc++)//for each row in the POS matrix
					{
						vector<int> bRow;
						for(int dcc=0;dcc<dataPoints[POSmats[PMcount][bcc]].size()-1;dcc++)//for each feature in the data point
						{
							cout<<"    "<<dataPoints[POSmats[PMcount][bcc]][dcc].intdata;
						}
						cout<<"\n";
					}
					cout<<"\n";
				}//end verbose display of POS matrix

				//make the BIN matrix
				vector<int> SOL;//all zeros until we find the winning columns
				vector<vector<int> > BIN;
				vector<vector<int> > tempPOS;
				for(int negs=0;negs<NEG.size();negs++)//for each negative example
				{
					vector<int> binRow;
					vector<int> tempPOSr;
					int countr=0;
					for(int pc=0;pc < numFeatures-1;pc++)//for each column in the POS matrix
					{
						bool matched=false;
						for(int pr=0;pr < POSmats[PMcount].size();pr++)//for each row in the POS matrix
						{
							if(dataPoints[NEG[negs]][pc].intdata == dataPoints[POSmats[PMcount][pr]][pc].intdata)matched=true;
						}
						if(matched)
						{
							binRow.push_back(0);
							tempPOSr.push_back(-1);
						}
						else
						{
							binRow.push_back(1);
							tempPOSr.push_back(dataPoints[NEG[negs]][pc].intdata);
							countr++;
						}
					}
					if(countr>0)
					{
						BIN.push_back(binRow);
						tempPOS.push_back(tempPOSr);
					}
				}//end for each NEG row

				//now we have the BIN matrix. Find the solution vector
				if(verbose)cout<<"SOL = [ ";
				SOL=solveSCproblem(BIN);

				if(verbose)//if verbose then show solution for this BIN matrix
				{
					for(int i=0;i<SOL.size();i++)
					{
						cout<<SOL[i];
						if(i<(SOL.size()-1))cout<<", ";
					}
					cout<<"]\n\n";

					//show NEG matrix
					cout<<"NEG mat\n";
					for(int nr=0;nr<tempPOS.size();nr++)
					{
						for(int nc=0;nc<tempPOS[nr].size();nc++)
						{
							cout<<"    "<<tempPOS[nr][nc];
						}
						cout<<"\n";
					}
					cout<<"\n";
				}

				//make the new rule
				vector<vector<int> > rule;
				vector<int> rulerow1;
				vector<int> rulerow2;
				for(int s=0;s<SOL.size();s++)
				{
					if(SOL[s]==1)
					{
						for(int pr=0;pr<tempPOS.size();pr++)//POSmats[PMcount].size();pr++)
						{
							bool present=false;
							for(int t=0;t<rulerow1.size();t++)
							{
								if(s==rulerow1[t])//the columns match, see if the value is present
								{
									//cout<<"    "<<rulerow2[t]<<"    "<<tempPOS[pr][s]<<"\n";
									if(rulerow2[t]==tempPOS[pr][s])//dataPoints[POSmats[PMcount][pr]][s].intdata)
									{
										present=true;
									}
								}
							}
							if(tempPOS[pr][s]==-1)//this is our exclusion case. These shouldn't get added to the rules
							{
								present=true;
							}
							if(!present)
							{
								rulerow1.push_back(s);
								rulerow2.push_back(tempPOS[pr][s]);//dataPoints[POSmats[PMcount][pr]][s].intdata);
							}
						}
					}
				}
				rule.push_back(rulerow1);
				rule.push_back(rulerow2);

				if(verbose)
				{
					cout<<"Rule\n";
					for(int rp=0;rp<rule[1].size();rp++)
					{
						cout<<"    "<<rule[0][rp]<<"!="<<rule[1][rp];
					}
					cout<<"    : ";
				}

				//test the new ruleset to see how many examples it covers
				int newRuleCount=0;
				int wrongcount=0;
				for(int p=0;p<POS.size();p++)
				{
					bool broken=false;
					for(int r=0;r<rule[0].size();r++)
					{
						//          original POS matrix           matrix our rules are coming from
						if(dataPoints[POS[p]][rule[0][r]].intdata == rule[1][r])
						{
							broken=true;
						}
					}
					if(!broken)
					{
						newRuleCount++;
					}
					else
					{
						wrongcount++;
					}
				}

				if(verbose)cout<< newRuleCount<<"/"<< wrongcount<<"\n\n";

				//check to see if the new rule is better than the previous rule
				if(newRuleCount>ruleCover)
				{
					ruleCover=newRuleCount;
					bestRule.swap(rule);
					rule.clear();
				}
			}//end for each POS matrix

			//begin phase III

			//keep rule
			classRules.push_back(bestRule);

			if(verbose)
			{
				cout<<"****************************************\n\n    PHASE III\n\nChosen Rule\n";
				for(int rp=0;rp<bestRule[1].size();rp++)
				{
					cout<<"    "<<bestRule[0][rp]<<"!="<<bestRule[1][rp];
				}
				cout<<"\n\n";
			}

			//we've got the best rule for this run. Narrow down the POS matrix and do another run.
			for(int p=0;p<POS.size();p++)
			{
				bool broken=false;
				for(int r=0;r<bestRule[0].size();r++)
				{
					//          original POS matrix           matrix our rules are coming from
					if(dataPoints[POS[p]][bestRule[0][r]].intdata == bestRule[1][r])
					{
						broken=true;
					}
				}
				if(!broken)
				{
					//remove this entry from the POS matrix
					POS.erase(POS.begin()+p);
					p--;
				}
			}

			if(verbose)//display new POS mat
			{
				//display the POS matrix
				cout<<"POS matrix\n";
				for(int bcc=0;bcc < POS.size();bcc++)//for each row in the POS matrix
				{
					vector<int> bRow;
					for(int dcc=0;dcc<dataPoints[POS[bcc]].size()-1;dcc++)//for each feature in the data point
					{
						cout<<"    "<<dataPoints[POS[bcc]][dcc].intdata;
					}
					cout<<"\n";
				}
				if(POS.size()<=0)
					cout<<"EMPTY\n    End Rule Search for Class "<<classCyc<<"\n";
				cout<<"\n";
			}
		}//end while( POS still has rows )
		//add rules for this class to the master rule list
		allRules.push_back(classRules);
		classRules.clear();
	}//end for each class

	//ALL DONE
	//if(verbose)//display entire rule list for this dataset
	{
		cout<<"************************************************\n************************************************\n\n  Final Rule List\n\n";
		for(int cls=0;cls<allRules.size();cls++)
		{
			cout<<"  Class "<<cls<<" - "<<featureNames[classIndex] <<" = "<<stringVals[classIndex][cls] <<"\n\n";
			for(int rln=0;rln<allRules[cls].size();rln++)
			{
				cout<<"    Rule "<<rln<<"\n      If ";
				for(int col=0;col<allRules[cls][rln][0].size();col++)
				{
					cout<< featureNames[allRules[cls][rln][0][col]] <<"<>";
					cout<< stringVals[allRules[cls][rln][0][col]][allRules[cls][rln][1][col]];
					if(col<(allRules[cls][rln][0].size()-1))
					{
						cout<<" AND ";
					}
				}
				cout<<" THEN "<<featureNames[classIndex] <<" = "<< stringVals[classIndex][cls]<<"\n\n";
			}
		}
	}
	//output rules to file
	//file.open(OutFileName.c_str(), fstream::out | fstream::trunc);
	//printData(file);
	//file.close();

	//end
	return 0;
}

vector<int> solveSCproblem(vector<vector<int> > BIN)
{
	if(BIN.size()==0)
	{
		cout<<"\nError! Empty BIN matrix\n";
		vector<int> toret;
		return toret;
	}

	if(verbose)
	{
		cout<<"\n\n";
		for(int i=0;i<BIN.size();i++)
		{
			for(int j=0;j<BIN[0].size();j++)
			{
				cout<<"\t"<<BIN[i][j];
			}
			cout<<"\n";
		}
		cout<<"\n";
	}

	vector<int> toret(BIN[0].size(),0);
	vector<bool> activeRows(BIN.size(),true);//all rows start active
	int numActive=BIN.size();

	while(numActive > 0)
	{
		vector<int> rowTots(BIN.size(),0);//to store the total number of ones in each row of the BIN matrix
		vector<int> colTotsA(numFeatures-1,0);//to store the number of ones in columns, from active rows
		vector<int> colTotsI(numFeatures-1,0);//to store the number of ones in columns, from inactive rows
		vector<int> chosenRows;
		vector<int> chosenCols(1,0);
		//cout<<"here   ";
		for(int row=0;row<BIN.size();row++)
		{
			//cout<<"row:"<<row<<"  ";
			if(activeRows[row])
			{
				if(chosenRows.size()==0)
				{
					chosenRows.push_back(row);
				}
				//cout<<"active   ";
				for(int col=0;col<BIN[row].size();col++)
				{
					rowTots[row]+=BIN[row][col];
				}
				//cout<<rowTots[row]<<"   "<<rowTots[chosenRows[0]]<<"   ";
				//we've finished a row, see if it is an active row or not
				if(rowTots[chosenRows[0]]>rowTots[row])
				{
					chosenRows.clear();
					chosenRows.push_back(row);
				}
				else if(rowTots[chosenRows[0]]==rowTots[row])
				{
					if(row>0)
					{
						chosenRows.push_back(row);
					}
				}
			}
		}

		//now go through and get our column info
		int activecount=0;
		for(int row=0;row<BIN.size();row++)
		{
			//cout<<"r: "<<row<<"   ";
			if(activeRows[row])
			{
				//cout<<"active   ";
				//determine if this is a chosen row
				bool active=false;
				if(activecount < chosenRows.size())
				{
					//cout<<"makeing changes...   ";
					if(chosenRows[activecount]==row)
					{
						active=true;
						activecount++;
					}
				}

				//now add the columns
				for(int col=0;col<BIN[row].size();col++)
				{
					if(active)
						colTotsA[col]+=BIN[row][col];
					else
						colTotsI[col]+=BIN[row][col];
				}
			}//end if(activeRows[row])
			//if we are on the last row, start chekcing for max columns
			if(row==(BIN.size()-1))
			{
				for(int col=0;col<BIN[row].size();col++)
				{
					//cout<<"a: "<<colTotsA[col]<<"  i:"<< colTotsI[col] <<"\n";
					if(colTotsA[chosenCols[0]]<colTotsA[col])
					{
						chosenCols.clear();
						chosenCols.push_back(col);
					}
					else if(colTotsA[chosenCols[0]]==colTotsA[col])
					{
						if(col>0)
						{
							chosenCols.push_back(col);
						}
					}
				}
			}
		}

		//narrow down column selections if there are more than one
		vector<int> bestColsIndex(1,0);
		if(chosenCols.size()>1)
		{
			for(int i=1;i<chosenCols.size();i++)
			{
				if(colTotsI[chosenCols[bestColsIndex[0]]] > colTotsI[chosenCols[i]])
				{
					bestColsIndex.clear();
					bestColsIndex.push_back(i);
				}
				else if(colTotsI[chosenCols[bestColsIndex[0]]] == colTotsI[chosenCols[i]])
				{
					if(i>0)
					{
						bestColsIndex.push_back(i);
					}
				}
			}
		}

		//if there is more than one entry in bestColsIndex then the first one will suffice
		toret[chosenCols[bestColsIndex[0]]]=1;

		//now go through and mark any rows inactive that match the latest entry in the solution vector
		for(int i=0;i<BIN.size();i++)
		{
			//cout<<"\nBIN "<< BIN[i][chosenCols[bestColsIndex[0]]] << "  i"<<i<<"  col ind "<<chosenCols[bestColsIndex[0]] <<"\n";
			if(BIN[i][chosenCols[bestColsIndex[0]]] == 1)
			{
				activeRows[i]=false;
				numActive--;
			}
		}
	}

	return toret;
}

//printData - to print out the collected data. This can be passed a stream
ostream& printData(ostream& out)
{
	out<<datasetName<<"\n";
	for(int i=0;(unsigned int)i<featureNames.size();i++)
	{
		out<<featureNames[i];
		if(i<(featureNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;(unsigned int)i<typeNames.size();i++)
	{
		out<<typeNames[i];
		if(i<(typeNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;i<dataPoints.size();i++)
	{
		for(int j=0;j<dataPoints[i].size();j++)
		{
			switch(featureTypes[j])
			{
				case INTEGER:{out<<dataPoints[i][j].intdata;}break;
				case REAL:{out<<dataPoints[i][j].realdata;}break;
				default :{out<<dataPoints[i][j].stringdata;}break;
			}
			if(j<(dataPoints[i].size()-1))out<<",";
		}
		if(i<(dataPoints.size()-1))out<<"\n";
	}
	return out;
}

//eof

