/*
 Author: Sam Sieg
 Project: An implementation of the CAIM algorithm for feature descritization, a step in data mining processes
 Date: 10/01/10
 Language: C++
 Compiler: gcc version 4.5.0 (GCC)

 Usage: CAIM infile.extension outfile.extension -(v,b)
 			This program axpects a comma delimited file of the following format

 		1	Project Name
 		2	Column Heading 1,Column Heading 2,...,Column Heading N
 		3	Data Type 1,Data Type 2,...,Data Type N
 		4	Data Point 1 Info,...,Final info for data point 1
 		5	Data Point 2 Info,...,Final info for data point 2
 			.
 			.
 			.
 		M+3	Data Point M Info,...,Final info for data point M

 		Valid data types are
 			Integer	String	Real	ClassName

		DO NOT use commas in any data cell as commas are used as delimiters

		If no outfile is given then the output file will be the same name as the input file. You will recieve one warning before the algorithm begins.

		The v option "verbose" is enabled by default and will print ou t a list of the descritized ranges for each feature.
		The b option "brief" will disable analitic output
*/

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
#include <string>
#include <cmath>
#include <vector>
#include <list>

using namespace std;

template <class T> void QuickSort(T* array, int startIndex, int endIndex);
template <class T> int SplitArray(T* array, T pivotValue, int startIndex, int endIndex);
template <class T, class U> void QuickSort2(T* arr, U* brr, int startIndex, int endIndex);
template <class T, class U> int SplitArray2(T* arr, U* brr, T pivotValue, int startIndex, int endIndex);
template <class T> double CAIM(T* dataV, string* dataC, int* indexC, list<string> uniqueC, list<double> bounds);

template <class T> T* vectorToArray(vector<T> vec)
{
	T* toret=new T[vec.size()];
	for(unsigned int i=0;i<vec.size();i++)
	{
		toret[i]=vec[i];
	}
	return toret;
}

void usage()
{
	cout<<"\nAuthor: Sam Sieg\nProject: An implementation of the CAIM algorithm for feature descritization, a step in data mining processes\nDate: 10/01/10\n";
	cout<<"Language: C++\nCompiler: gcc version 4.5.0 (GCC)\n\nUsage: CAIM infile.extension outfile.extension -(v,b,y)\n\t\tThis program axpects a comma delimited file of the following format\n\n";
	cout<<"\t1	Project Name\n\t2	Column Heading 1,Column Heading 2,...,Column Heading N\n\t3	Data Type 1,Data Type 2,...,Data Type N\n\t4	Data Point 1 Info,...,Final info for data point 1\n";
	cout<<"\t5	Data Point 2 Info,...,Final info for data point 2\n\t	.\n\t	.\n\t	.\n\tM+3	Data Point M Info,...,Final info for data point M\n\n\tValid data types are\n";
	cout<<"\t\tInteger\tString\tReal\tClassName\n\n\tDO NOT use commas in any data cell as commas are used as delimiters\n\n";
	cout<<"\tIf no outfile is given then the output file will be the same name as the input file. This will overwrite the original data with the processed data. You will recieve one warning before the algorithm begins.\n\n";
	cout<<"\t-v\tverbose: enabled by default and will print out a list of the descritized ranges for each feature.\n\n\t-b\tbrief: disables verbose output\n\n\t-y\tyes: disables overwrite warning\n\n";
}

string toLower(string in)
{
	for (int j=0; j<in.length(); ++j)
	{
		in[j]=tolower(in[j]);
	}
	return in;
}

string toUpper(string in)
{
	for (int j=0; j<in.length(); ++j)
	{
		in[j]=toupper(in[j]);
	}
	return in;
}

enum DATATYPE {INTEGER, REAL, STRING, CLASSNAME};

struct Feature
{
	int intdata;
	double realdata;
	string stringdata;
};

int numFeatures;
int numDescFeatures;
int numData;

string datasetName;

vector<string> featureNames;
vector<string> typeNames;
vector<DATATYPE> featureTypes;
vector<vector<Feature> > dataPoints;//outter is the list of data points, inner is the list of values for a single data point
vector<vector<double> > boundaries;//outter is the feature, inner is the list of boundaries for that feature

bool verbose=true;
bool preconfirm=false;
string OutFileName="";
string InFileName="";
fstream file;

bool DEBUG=false;

ostream& printData(ostream& out=std::cout);
ostream& printDescritized(ostream& out=std::cout);

template <class T> ostream& printList(list<T> l, ostream& out=std::cout)
{
	out<<"?\"";
	for(typename list<T>::iterator it=l.begin();it!=l.end();it++)
	{
		out<<(*it)<<"\t";
	}
	out<<"\"?\n";
	return out;
}

template <class T> ostream& printArray(T* arr, unsigned int sz, ostream& out=std::cout)
{
	out<<"?\"";
	for(int i=0;i<sz;i++)
	{
		out<<arr[i]<<"\t";
	}
	out<<"\"?\n";
	return out;
}

int main(int argc, char* argv[])
{
	bool DEBUG1=true;
	bool DEBUG2=false;

	//This code checks for command line parameters.
	if(argc<2)
	{
		cout<<"Error: no input file named ...\n\n";
		usage();
		return 1;
	}
	else if(argc > 5)
	{
		cout<<"Error: too many arguments to CAIM.exe\n\n";
		usage();
		return 1;
	}
	else
	{
		bool gotInput=false;
		for(int x=1; x < argc; x++)
		{
			//this option supresses verbose output
			if(strcmp(argv[x],"-b")==0)
			{
				verbose=false;
			}
			//this option enables verbose output
			else if(strcmp(argv[x],"-v")==0)
			{
				verbose=true;
			}
			//this option disables the overwrite warning message
			else if(strcmp(argv[x],"-y")==0)
			{
				preconfirm=true;
			}
			//this looks for the filenames the command should be getting
			else
			{
				if(!gotInput)
				{
					gotInput=true;
					InFileName=argv[x];
					OutFileName=argv[x];
				}
				else
				{
					OutFileName=argv[x];
				}
			}
		}
	}//done with command line args

	//check for output file name
	if(!preconfirm)
	{
		if(InFileName.compare(OutFileName)==0)
		{
			cout<<"You have chosen to overwrite your data file with the processed data.\n\tContinue? (y/n): ";
			char c=getchar();
			if(tolower(c)!='y')
			{
				cout<<"\nAborting.\n";
				usage();
				return 3;//user abort
			}
		}
	}

	//try to open input file
	file.open(InFileName.c_str(),fstream::in);
	if(file.fail())
	{
		cout<<"Failure to open "<<InFileName<<"\n\n";
		return 2;
	}

	//read in data
	bool done=false;
	string input;

	//get title
	getline(file,datasetName);
	if(!file.good())
	{
		cout<<"Error: Bad file format for "<<InFileName<<"\n\n";
		return 2;
	}

	//get feature names
	getline(file,input);
	if(!file.good())
	{
		cout<<"Error: No feature names (column headers) in "<<InFileName<<"\n\n";
		return 2;
	}
	char * tok;
	tok = strtok ((char*)input.c_str(),",");
	while (tok != NULL)
	{
		featureNames.push_back(tok);
		numFeatures++;
		tok = strtok(NULL, ",");
	}

	//get feature type
	getline(file,input);
	if(!file.good())
	{
		cout<<"Error: No type names (integer, real, etc.) in "<<InFileName<<"\n\n";
		return 2;
	}
	tok = strtok ((char*)input.c_str(),",");
	while (tok != NULL)
	{
		typeNames.push_back(tok);//store the name used by the data file for this feature
		tok=(char *)toLower(tok).c_str();
		//find out if it is a type we recognize and need to process
		if(strcmp(tok,"integer")==0 || strcmp(tok,"int")==0)
		{
			featureTypes.push_back(INTEGER);
		}
		else if(strcmp(tok,"real")==0 || strcmp(tok,"double")==0 || strcmp(tok,"float")==0 || strcmp(tok,"floating point")==0)
		{
			featureTypes.push_back(REAL);
		}
		else if(strcmp(tok,"class")==0 || strcmp(tok,"classname")==0 || strcmp(tok,"name")==0)
		{
			featureTypes.push_back(CLASSNAME);
		}
		else//it is either a string or not a type this program recognizes
		{
			featureTypes.push_back(STRING);
		}
		tok = strtok(NULL, ",");
	}

	//get the data points
	done=false;
	while(!done)
	{
		getline(file,input);
		if(input.length()>0)
		{
			int count=0;
			tok = strtok ((char*)input.c_str(),",");
			vector<Feature> temp;
			while(tok != NULL)
			{
				//find out what type of feature we are dealing with then store it
				Feature f;
				switch(featureTypes[count])
				{
					case INTEGER:{f.intdata=atoi(tok);}break;
					case REAL:{f.realdata=atof(tok);}break;
					case STRING:{f.stringdata=tok;}break;
					case CLASSNAME:{f.stringdata=tok;}break;
				}
				temp.push_back(f);
				//move to next feature
				count++;
				tok = strtok(NULL, ",");
			}
			dataPoints.push_back(temp);
		}
		if(!file.good())
		{
			done=true;
		}
	}
	file.close();

	numData=dataPoints.size();

	//Process the data
	//for each feature
	//	get the list of classes from the data
	//	sort the data for the features into an ascending list of unique values
	//	find all possible boundaries for these values
	//calculate the CAIM value for the data matrix with only one descritized unit
	//	then for every possible boundary
	//		add a boundary
	//		calculate the new CAIM value for each boundary
	//		keep the boundary with the best CAIM value
	//	do this until adding a boundary reduces the CAIM value, or until there are as many divisions as there are classes.
	//
	//	now descritize the data for that feature
	//
	//repeat until all necesary features have been descritized

	//int numFeatures;
	//int numDescFeatures;
	//int numData;
	//string datasetName;
	//vector<string> featureNames;
	//vector<string> typeNames;
	//vector<DATATYPE> featureTypes;
	//vector<vector<Feature> > dataPoints;
	//vector<vector<double> > boundaries;
	for(unsigned int feat=0;feat<numFeatures;feat++)
	{
		switch(featureTypes[feat])
		{
			case STRING:

			case CLASSNAME:
			{
				//strings do not get descritized
				//this empty vector is put here as a place holder
				vector<double> temp;
				boundaries.push_back(temp);
			}break;

			case INTEGER:
			{
				int values[numData];//the data we need to work on
				int classesInd[numData];//
				string classes[numData];//the classes for the data
				list<double> allBoundaries;//a list of all possible boundaries, at most dp+1
				list<string> uniqueClasses;//the unique classes in the data
				list<double> keptBoundaries;//a list of boundaries kept
				//get the data
				for(unsigned int dp=0;dp<numData;dp++)
				{
					values[dp]=dataPoints[dp][feat].intdata;
					keptBoundaries.push_back(values[dp]);
					classes[dp]=dataPoints[dp][numFeatures-1].stringdata;
					classesInd[dp]=dp;
					uniqueClasses.push_back(classes[dp]);
				}
				//get unique values and sort data
				keptBoundaries.sort();
				keptBoundaries.unique();
				for(list<double>::iterator it=keptBoundaries.begin();it!=(--keptBoundaries.end());it++)
				{
					list<double>::iterator nt=it;
					nt++;
					allBoundaries.push_back((*nt + *it)/2.0);
				}
				keptBoundaries.clear();
				uniqueClasses.sort();
				uniqueClasses.unique();
				QuickSort2(values, classesInd, 0, numData-1);
				//add the first boundary, this is subtracting 1 from the current first boundary, the 1 is arbitrary
				keptBoundaries.push_front(values[0]-1);
				//add the last boundary, this is adding 1 to the last boundary, the 1 is arbitrary
				keptBoundaries.push_back(values[numData-1]+1);

				//now we start hunting for more boundaries
				double lastCAIM=CAIM(values, classes, classesInd, uniqueClasses, keptBoundaries);
				unsigned int boundsAdded=0;
				bool done=false;
				while(!done)
				{
					double bestCurrentCAIM=0;
					list<double>::iterator bestCurrentCAIMindex;

					for(list<double>::iterator it=allBoundaries.begin();it!=allBoundaries.end();it++)
					{
						list<double> boundy(keptBoundaries);
						boundy.push_back(*it);
						boundy.sort();
						double currentCAIM=CAIM(values, classes, classesInd, uniqueClasses, boundy);
						if(currentCAIM > bestCurrentCAIM)
						{
							bestCurrentCAIM=currentCAIM;
							bestCurrentCAIMindex=it;
						}
					}

					//now we have the best boundary to add, lets see if it improves our results
					//or if we have less added bounds than the number of classes
					if(bestCurrentCAIM > lastCAIM || (boundsAdded+1) < uniqueClasses.size())
					{
						//
						keptBoundaries.push_back(*bestCurrentCAIMindex);
						keptBoundaries.sort();
						allBoundaries.erase(bestCurrentCAIMindex);
						boundsAdded++;
						if(bestCurrentCAIM > lastCAIM)
						{
							lastCAIM=bestCurrentCAIM;
						}
					}
					else
					{
						done=true;
					}
				}

				//we've got the bounds list now. Lets save it.
				vector<double> temp;
				for(list<double>::iterator it=keptBoundaries.begin();it!=keptBoundaries.end();it++)
				{
					temp.push_back(*it);
				}

				boundaries.push_back(temp);

			}break;

			case REAL:
			{
				double values[numData];//the data we need to work on
				int classesInd[numData];//
				string classes[numData];//the classes for the data
				list<double> allBoundaries;//a list of all possible boundaries, at most dp+1
				list<string> uniqueClasses;//the unique classes in the data
				list<double> keptBoundaries;//a list of boundaries kept
				//get the data
				for(unsigned int dp=0;dp<numData;dp++)
				{
					values[dp]=dataPoints[dp][feat].realdata;
					keptBoundaries.push_back(values[dp]);
					classes[dp]=dataPoints[dp][numFeatures-1].stringdata;
					classesInd[dp]=dp;
					uniqueClasses.push_back(classes[dp]);
				}
				//get unique values and sort data
				keptBoundaries.sort();
				keptBoundaries.unique();
				for(list<double>::iterator it=keptBoundaries.begin();it!=(--keptBoundaries.end());it++)
				{
					list<double>::iterator nt=it;
					nt++;
					allBoundaries.push_back((*nt + *it)/2.0);
				}
				keptBoundaries.clear();
				uniqueClasses.sort();
				uniqueClasses.unique();
				QuickSort2(values, classesInd, 0, numData-1);
				//add the first boundary, this is subtracting 1 from the current first boundary, the 1 is arbitrary
				keptBoundaries.push_front(values[0]-1);
				//add the last boundary, this is adding 1 to the last boundary, the 1 is arbitrary
				keptBoundaries.push_back(values[numData-1]+1);

				//now we start hunting for more boundaries
				double lastCAIM=CAIM(values, classes, classesInd, uniqueClasses, keptBoundaries);
				unsigned int boundsAdded=0;
				bool done=false;
				while(!done)
				{
					double bestCurrentCAIM=0;
					list<double>::iterator bestCurrentCAIMindex;

					for(list<double>::iterator it=allBoundaries.begin();it!=allBoundaries.end();it++)
					{
						list<double> boundy(keptBoundaries);
						boundy.push_back(*it);
						boundy.sort();
						double currentCAIM=CAIM(values, classes, classesInd, uniqueClasses, boundy);
						if(currentCAIM > bestCurrentCAIM)
						{
							bestCurrentCAIM=currentCAIM;
							bestCurrentCAIMindex=it;
						}
					}

					//now we have the best boundary to add, lets see if it improves our results
					//or if we have less added bounds than the number of classes
					if(bestCurrentCAIM > lastCAIM || (boundsAdded+1) < uniqueClasses.size())
					{
						//
						keptBoundaries.push_back(*bestCurrentCAIMindex);
						keptBoundaries.sort();
						allBoundaries.erase(bestCurrentCAIMindex);
						boundsAdded++;
						if(bestCurrentCAIM > lastCAIM)
						{
							lastCAIM=bestCurrentCAIM;
						}
					}
					else
					{
						done=true;
					}
				}

				//we've got the bounds list now. Lets save it.
				vector<double> temp;
				for(list<double>::iterator it=keptBoundaries.begin();it!=keptBoundaries.end();it++)
				{
					temp.push_back(*it);
				}

				boundaries.push_back(temp);
			}break;
		}
	}

	if(verbose)
	{
		cout<<datasetName<<"\n";
		int count=0;
		for(vector<vector<double> >::iterator oit=boundaries.begin();oit!=boundaries.end();oit++)
		{
			cout<<count<<": "<<featureNames[count]<<"\t";
			vector<double>::iterator iit=(*oit).begin();
			if(iit!=(*oit).end())
			{
				cout<<"{  [";
				cout<<*iit<<", ";
				iit++;
				for(;iit!=(*oit).end();iit++)
				{
					cout<<*iit<<"] ";
					vector<double>::iterator chk=iit;
					chk++;
					if(chk!=(*oit).end())
					{
						cout<<", ("<<*iit<<", ";
					}
				}
				cout<<" }";
			}
			else
			{
				cout<<"not descritized ...";
			}
			cout<<"\n";
			count++;
		}
	}

	//DEBUG=true;
	//convert data values to new descritized values
	for(unsigned int dat=0;dat<numData;dat++)
	{
		//if(DEBUG)cout<<"Data: "<<dat<<";\n";
		for(unsigned int feat=0;feat<numFeatures;feat++)
		{
			/*if(DEBUG)
			{
				cout<<"\tFeat: "<<feat<<"; ";
				switch(featureTypes[feat])
				{
					case STRING:{cout<<"Type: STRING;\n";}break;
					case CLASSNAME:{cout<<"Type: CLASSNAME;\n";}break;
					case REAL:{cout<<"Type: REAL; ";}break;
					case INTEGER:{cout<<"Type: INTEGER; ";}break;
				}
			}*/
			for(int bdr=0;bdr<((int)boundaries[feat].size()-1);bdr++)
			{
				switch(featureTypes[feat])
				{
					case STRING://we leave these types alone since they are already discrete.
					case CLASSNAME:
					{
						bdr=boundaries[feat].size();
					}break;
					case INTEGER:
					{
						//if the data point is within a particular boundary, then we descritize that data point with the index of that boundary
						if( (dataPoints[dat][feat].intdata > boundaries[feat][bdr])  &&  (dataPoints[dat][feat].intdata < boundaries[feat][bdr+1]) )
						{
							//if(DEBUG)cout<<"Desc: "<<bdr+1<<";\n";
							dataPoints[dat][feat].intdata = bdr+1;//+1 so the values go from 1 to numBoundaries
							bdr=boundaries[feat].size();
						}
					}break;
					case REAL:
					{
						//if the data point is within a particular boundary, then we descritize that data point with the index of that boundary
						if( (dataPoints[dat][feat].realdata > boundaries[feat][bdr])  &&  (dataPoints[dat][feat].realdata < boundaries[feat][bdr+1]) )
						{
							//if(DEBUG)cout<<"Desc: "<<bdr+1<<";\n";
							dataPoints[dat][feat].realdata = bdr+1;//+1 so the values go from 1 to numBoundaries
							bdr=boundaries[feat].size();
						}
					}break;
				}
			}
		}
	}

	//output of data
	file.open(OutFileName.c_str(), fstream::out | fstream::trunc);
	printData(file);
	//printDescritized(file);
	file.close();

	//end
	return 0;
}

//CAIM value calculator
template <class T> double CAIM(T* dataV, string* dataC, int* indexC, list<string> uniqueC, list<double> bounds)
{
	int qs[uniqueC.size()][bounds.size()-1];

	for(int q=0;q<uniqueC.size();q++)
	{
		for(int s=0;s<bounds.size()-1;s++)
		{
			qs[q][s]=0;
		}
	}

	//printArray(dataC, numData);
	//printArray(indexC, numData);
	if(DEBUG)//is zero's
	{
		for(int q=0;q<uniqueC.size();q++)
		{
			for(int s=0;s<bounds.size()-1;s++)
			{
				cout<<qs[q][s]<<"\t";
			}
			cout<<"\n";
		}
	}

	int count=0;
	for(int i=0;i<numData;i++)
	{
		int q=0;
		for(list<string>::iterator cit=uniqueC.begin();cit!=uniqueC.end();cit++,q++)
		{
			//cout<<(*cit) <<" "<<dataC[indexC[i]] <<" "<<i<<" ";
			if((*cit).compare(dataC[indexC[i]])==0)
			{
				//cout<<"*";
				int k=0;
				for(list<double>::iterator bit=bounds.begin();bit!=(--bounds.end());bit++,k++)
				{
					list<double>::iterator it=bit;
					it++;
					if((dataV[i] > *bit)&&(dataV[i] < *it))
					{
						qs[q][k]++;
						count++;
					}
				}
			}
			//cout<<"\n";
		}
	}
	if(DEBUG)cout<<count<<"\n";
	if(DEBUG)//are sane numbers totaling to the number of datapoints
	{
		for(int q=0;q<uniqueC.size();q++)
		{
			for(int s=0;s<bounds.size()-1;s++)
			{
				cout<<qs[q][s]<<"\t";
			}
			cout<<"\n";
		}
	}

	double dMaxs[bounds.size()-1];
	double dTots[bounds.size()-1];
	for(int s=0;s<bounds.size()-1;s++)
	{
		dTots[s]=0;
		dMaxs[s]=0;
	}
	for(int q=0;q<uniqueC.size();q++)
	{
		for(int s=0;s<bounds.size()-1;s++)
		{
			if(DEBUG)
			{
				cout<<"q:"<<qs[q][s]<<" ";
			}

			dTots[s]+=qs[q][s];

			if(DEBUG)
			{
				cout<<"d:"<<dTots[s] <<" ";
			}

			if(qs[q][s] > dMaxs[s])
			{
				dMaxs[s]=qs[q][s];
				if(DEBUG)
				{
					cout<<"M:"<<dMaxs[s];
				}
			}

			if(DEBUG)
			{
				if(s==(bounds.size()-2))cout<<"\n";
				else cout<<"\t";
			}
		}
	}
	if(DEBUG)cout<<"\n";

	double toret=0.0;

	for(int i=0; i < bounds.size()-1; i++)
	{
		toret+=((dMaxs[i] * dMaxs[i] * 1.0)/max(dTots[i]*1.0,1.0));
	}

	toret/=(bounds.size()-1);

	if(DEBUG)cout<<toret<<"\n";

	return toret;
}

//printDescritized - to print out the collected data. This can be passed a stream
ostream& printDescritized(ostream& out)
{
	out<<datasetName<<"\n";
	for(int i=0;(unsigned int)i<featureNames.size();i++)
	{
		out<<featureNames[i];
		if(i<(featureNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;(unsigned int)i<typeNames.size();i++)
	{
		switch(featureTypes[i])
		{
			case INTEGER:
			case REAL:
			{
				out<<"integer";
			}break;
			default:
			{
				out<<typeNames[i];
			}break;
		}
		if(i<(typeNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;i<dataPoints.size();i++)
	{
		for(int j=0;j<dataPoints[i].size();j++)
		{
			//now check to see which boundary it falls in
			switch(featureTypes[j])
			{
				case INTEGER:
				{
					//out<<dataPoints[i][j].intdata;
					for(int bdr=0;bdr<((int)boundaries[j].size()-1);bdr++)
					{
						if( (dataPoints[i][j].intdata > boundaries[j][bdr])  &&  (dataPoints[i][j].intdata < boundaries[j][bdr+1]) )
						{
							out<<bdr+1;//+1 so the values go from 1 to numBoundaries
							bdr=boundaries[j].size();
						}
					}
				}break;
				case REAL:
				{
					//out<<dataPoints[i][j].realdata;
					for(int bdr=0;bdr<((int)boundaries[j].size()-1);bdr++)
					{
						if( (dataPoints[i][j].realdata > boundaries[j][bdr])  &&  (dataPoints[i][j].realdata < boundaries[j][bdr+1]) )
						{
							out<<bdr+1;//+1 so the values go from 1 to numBoundaries
							bdr=boundaries[j].size();
						}
					}
				}break;
				default :{out<<dataPoints[i][j].stringdata;}break;
			}
			if(j<(dataPoints[i].size()-1))out<<",";
		}
		if(i<(dataPoints.size()-1))out<<"\n";
	}
	return out;
}

//printData - to print out the collected data. This can be passed a stream
ostream& printData(ostream& out)
{
	out<<datasetName<<"\n";
	for(int i=0;(unsigned int)i<featureNames.size();i++)
	{
		out<<featureNames[i];
		if(i<(featureNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;(unsigned int)i<typeNames.size();i++)
	{
		out<<typeNames[i];
		if(i<(typeNames.size()-1))out<<",";
	}
	out<<"\n";
	for(int i=0;i<dataPoints.size();i++)
	{
		for(int j=0;j<dataPoints[i].size();j++)
		{
			switch(featureTypes[j])
			{
				case INTEGER:{out<<dataPoints[i][j].intdata;}break;
				case REAL:{out<<dataPoints[i][j].realdata;}break;
				default :{out<<dataPoints[i][j].stringdata;}break;
			}
			if(j<(dataPoints[i].size()-1))out<<",";
		}
		if(i<(dataPoints.size()-1))out<<"\n";
	}
	return out;
}

/* This function does the quicksort
   Arguments :
	 array - the array to be sorted
	 startIndex - index of the first element of the section
	 endIndex - index of the last element of the section
*/
template <class T>
void QuickSort(T* array, int startIndex, int endIndex)
{
	T pivot = array[startIndex];//pivot element is the leftmost element
	int splitPoint;

	if(endIndex > startIndex)    //if they are equal, it means there is
								 //only one element and quicksort's job
								 //here is finished
	{
		splitPoint = SplitArray(array, pivot, startIndex, endIndex);

		array[splitPoint] = pivot;
		QuickSort(array, startIndex, splitPoint-1);   //Quick sort first half
		QuickSort(array, splitPoint+1, endIndex);     //Quick sort second half
	}
}

/* This function splits the array around the pivot
   Arguments :
	 array - the array to be split
	 pivot - pivot element whose position will be returned
	 startIndex - index of the first element of the section
	 endIndex - index of the last element of the section

   Returns :
     the position of the pivot
*/
template <class T>
int SplitArray(T* array, T pivot, int startIndex, int endIndex)
{
	int leftBoundary = startIndex;
	int rightBoundary = endIndex;

	while(leftBoundary < rightBoundary)		       //shuttle pivot until the boundaries meet
	{
		 while( pivot < array[rightBoundary]	      //keep moving until a lesser element is found
					&& rightBoundary > leftBoundary)  //or until the leftBoundary is reached
		 {
			  rightBoundary--;			//move left
		 }

		 swap(array[leftBoundary], array[rightBoundary]);

		 while( pivot >= array[leftBoundary]	      //keep moving until a greater or equal element is found
					&& leftBoundary < rightBoundary)  //or until the rightBoundary is reached
		 {
			  leftBoundary++;						//move right
		 }

		 swap(array[rightBoundary], array[leftBoundary]);
	}

	return leftBoundary;       //leftBoundary is the split point because
							   //the above while loop exits only when
							   //leftBoundary and rightBoundary are equal
}


/* This function does the quicksort
   Arguments :
	 array - the array to be sorted
	 startIndex - index of the first element of the section
	 endIndex - index of the last element of the section
*/
template <class T, class U>
void QuickSort2(T* arr,U* brr, int startIndex, int endIndex)
{
	T pivot = arr[startIndex];//pivot element is the leftmost element
	U oldBrrStart = brr[startIndex];//the value to match the pivot in the second array
	int splitPoint;

	if(endIndex > startIndex)    //if they are equal, it means there is
								 //only one element and quicksort's job
								 //here is finished
	{
		splitPoint = SplitArray2(arr, brr, pivot, startIndex, endIndex);

		arr[splitPoint] = pivot;
		brr[splitPoint] = oldBrrStart;//the value in the same location as the pivot gets changed. The pivot was saved from before. We need to save this value too.
		QuickSort2(arr, brr, startIndex, splitPoint-1);   //Quick sort first half
		QuickSort2(arr, brr, splitPoint+1, endIndex);     //Quick sort second half
	}
}


/* This function splits the array around the pivot
   Arguments :
	 array - the array to be split
	 pivot - pivot element whose position will be returned
	 startIndex - index of the first element of the section
	 endIndex - index of the last element of the section
   Returns :
     the position of the pivot
*/
template <class T, class U>
int SplitArray2(T* arr, U* brr, T pivot, int startIndex, int endIndex)
{
	int leftBoundary = startIndex;
	int rightBoundary = endIndex;

	while(leftBoundary < rightBoundary)//shuttle pivot until the boundaries meet
	{
		 while( pivot < arr[rightBoundary]	      //keep moving until a lesser element is found
					&& rightBoundary > leftBoundary)  //or until the leftBoundary is reached
		 {
			  rightBoundary--;			//move left
		 }

		 swap(arr[leftBoundary], arr[rightBoundary]);
		 swap(brr[leftBoundary], brr[rightBoundary]);

		 while( pivot >= arr[leftBoundary]	      //keep moving until a greater or equal element is found
					&& leftBoundary < rightBoundary)  //or until the rightBoundary is reached
		 {
			  leftBoundary++;						//move right
		 }

		 swap(arr[rightBoundary], arr[leftBoundary]);
		 swap(brr[rightBoundary], brr[leftBoundary]);
		 //PrintArray(arr, ARRAY_SIZE);cout<<" ";PrintArray(brr, ARRAY_SIZE);cout<<"\n\n";
	}

	return leftBoundary;       //leftBoundary is the split point because
							   //the above while loop exits only when
							   //leftBoundary and rightBoundary are equal
}

/*

Test Data and expected analysis

pool metrics
length,width,classname
integer,integer,classname
4,2,tiny
3,6,tiny
12,8,epic
7,7,average
8,6,average
9,4,epic
6,5,average
6,8,epic
7,4,average
8,5,average
9,5,epic
10,6,epic
6,2,tiny
5,3,tiny
3,2,tiny

	2-3.5	3.5-6.5	6.5-13
tiny	2	3	0	5
average	0	1	4	5
epic	0	1	4	5
8	2	5	8	15

	32	12.8	8	17.6



	1-2.5	2.5-6.5	6.5-9
tiny	3	2	0	5
average	0	4	1	5
epic	0	3	2	5
9	3	9	3	15

	27	9	27	21


*/

//eof

