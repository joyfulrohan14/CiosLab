README for the CAIM Algorithm
------------------------------

The code has been written in Java 1.6.0_05 and would require the java runtime to run properly.
I have included the java source code, the class files and the input files in the same zip.

To make the code run, the Path and the Classpath of the your system needs to be set to the bin and the regular java jars respectively.
Unzip all the code/class and the test data files into the same folder.
The program opens a menu to select the file that needs to be picked for processing, the files are exactly the same as provided by you.

I have added a runCAIM.bat file for your convenience. 
The batch file will compile and run the code all you need to do is type 'runCAIM' at the command line.

