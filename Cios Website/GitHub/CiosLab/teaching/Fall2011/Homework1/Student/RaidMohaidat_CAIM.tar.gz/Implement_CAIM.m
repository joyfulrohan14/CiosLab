function Implement_CAIM()
%   Name: Raid Mohaidat
%   Homework 1 - Implementation  of CAIM ALGORITHM
%   CMSC635 KNOWLEDGE DISCOVERY&DATA MINING -  Fall2011
%   10/03/2011
%   Input : There are two comma seperated data files in text format; 1- iris.txt , 
%           2-   HeartDiseaseDatabases.txt
%   Output: The implementation will display the discretization scheme 
%   Instruction: 
%   1-  In Matlab's command window , Type Implement_caim() and press enter
%   2-  You will be prompted with a choice of dataset to use, type 1 or 2
%   and press enter
%   3-  You wil be prompted to selected the output type , type 4 if you
%   wish to see a detailed output or type 3 if you wish to see just the
%   discretization scheme only , then press enter
%   4-  If you selected 4 for details you will need to press enter after
%   processing each feature individually which gives you the chance to
%   review the details of each iteration/feature

tic
clc
close all, clear all, format compact 
%% Reading in the input data and its correspoding classes
% Given: Data consisting of M examples, S classes, and
%   continuous attributes Fi

fprintf('Enter the dataset number to be used in implementation \n');
fnum = input('(1) for Iris and (2) for HeartDiseaseDatabases (Type the number and press Enter) : ');

%details = input('To view Results only Enter (3) - To view Details and Results Enter (4) : ');   
if (fnum == 1) 
    fid = fopen('iris.txt','r'); 
    textscan(fid, '%s', 3, 'delimiter', '\n'); 
    X = textscan(fid, '%.2f %.2f %.2f %.2f %s', 'delimiter', ','); % reading data into X
    inputdata = [X{1} X{2} X{3} X{4}];
    Y = X{5};
    cl = zeros(length(Y),1);
    for c =1:length(Y)
        if(strcmp(Y(c),'Iris-setosa'))
            cl(c) = 0;
        elseif(strcmp(Y(c),'Iris-versicolor'))
            cl(c) = 1;
        elseif(strcmp(Y(c),'Iris-virginica'))   
            cl(c) = 2;
        end
    end
   
 details = input('To view Results only Enter (3) - To view Details and Results Enter (4) : ');    
elseif (fnum == 2) 
    fid = fopen('HeartDiseaseDatabases.txt','r'); % file id
    textscan(fid, '%s', 3, 'delimiter', '\n'); 
    X = textscan(fid, '%.2f %s %.2f %.2f %.2f %s %.2f %.2f %s %.1f %.2f %.2f %s %s', 'delimiter', ',');
    inputdata =  [X{1} X{3} X{4} X{5} X{8} X{10} X{12}];
    Y = X{14};
    cl = zeros(length(Y),1);
    for c=1:length(Y)
        if(strcmp(Y(c),'Presence Heart Disease'))
            cl(c) = 0;
        else
            cl(c) = 1;
        end
    end
details = input('To view Results only Enter (3) - To view Details and Results Enter (4) : '); 
else
   error('You should have selected 1 or 2 , please run the program again and select the appropriate file number ');
 
end
S = size(unique(cl), 1); % number of classes   
fclose(fid);  % finished reading the file and closing the file

%%  Start calculations

% For every Feature (Fi) do
scheme1=[];
Boundary=[];
for i=1:size(inputdata,2)  % for each feature Fi
    if (details == 4 )
        fprintf('\n \n \n');
        fprintf('Feature %i     \n', i);
    end
    GlobalCaim = 0; %initialize the maximum caim value
    d0 = min(inputdata(:,i));% minimum value
    dn = max(inputdata(:,i));% maximum value
    Nodup_Sorted = unique(inputdata(:,i)); % Sort without duplicated values
    for j=1:size(Nodup_Sorted,1) - 1   % calculating boundary points
        Boundary(j) = (Nodup_Sorted(j) + Nodup_Sorted(j + 1)) / 2; 
    end
    Discrete1 = [d0 dn]; % initialization , d0 is min value  and dn is max value

    k = 1;
    ON=1;
    while(ON==1)
        CaimValue = 0;
        pos = 1;

        for L=1:length(Boundary)
            if (Discrete1 ~= Boundary(L))
                Discrete1(end+1) = Boundary(L); % if the boundary does not exit then we add it to the discretization scheme
                Discrete1 = sort(Discrete1);
                if (details == 4 )
                    fprintf('%i: value=%.2f', L, Boundary(L));
                end
                caim = getcaim(inputdata, S, i, Discrete1, cl);
                if (details == 4 )
                    fprintf(' ; caim = %0.2f\n', caim);
                end
                if  (CaimValue < caim)
                        CaimValue = caim;
                        pos = L;
                end
                Discrete1(Discrete1 == Boundary(L)) = [];
            end
        end
        if (CaimValue > GlobalCaim || k < S)
            if (details == 4 )
                fprintf('For Feature %i : ', i);
                fprintf('Select point %i (value = %.2f) with a maximum value of caim (%.3f)\n', ...
                     pos, Boundary(pos), CaimValue);
            end
            Discrete1(end+1) = Boundary(pos);
            Discrete1 = sort(Discrete1);
            GlobalCaim = CaimValue;
        else
          ON=0;
        end
        k = k + 1;
    end  % end while
    
    if (details == 4 )
        fprintf('Scheme for Feature %i \n', i);
    end
    sch=[];
    if length(Discrete1)==1 
       sch= [Discrete1(1) Discrete1(2)];
    else
        for s=1:length(Discrete1)-1
            sch=[sch [Discrete1(s) Discrete1(s+1)]];
        end
    end
    scheme1=[scheme1;sch];            
     
    if (details == 4 )
        for z=1:length(Discrete1)-1
            if (z == 1)
                fprintf('[%.2f %.2f]', Discrete1(z), Discrete1(z+1));
            else
                fprintf('(%.2f %.2f]', Discrete1(z), Discrete1(z+1));
            end
        end
        fprintf('\n Review Feature %i then press enter to continue\n', i);
        pause
    end
    clear Boundary;
    
    
end
fprintf('\n  \n');
fprintf('\n***************   Result for  Discretization Scheme  ******************** \n\n');
    for z=1:size(scheme1,1)
        
        fprintf( 'Discretization Scheme For Feature: %i  ', z );
        for z2=1:2:size(scheme1,2)
            if (z2 == 1)
                fprintf( '[%.2f %.2f] ', scheme1(z,z2),  scheme1(z,z2+1) );
            else
                fprintf( '(%.2f %.2f] ', scheme1(z,z2),  scheme1(z,z2+1) );
            end
        end
       fprintf('\n  \n');
    end
    fprintf('\n  \n');
    fprintf('\n***************   ******************************  ******************** \n\n');
end
%%
function  caim = getcaim(inputdata, class_Count, feature, intervals, classes)

    n = length(intervals) - 1;
    quanta = getquanta(inputdata, class_Count, feature, intervals, classes);
    n_sumation = 0;
    Mr  =  sum(quanta,1) ;
    for s=1:size(quanta,2)
        Maxr = max(quanta(:,s));
        n_sumation =n_sumation + (Maxr * Maxr / Mr(s));
    end
    caim = n_sumation / n  ;
end
%%
function [quanta] = getquanta(inputdata, class_Count, feature, intervals, classes)

    quanta = zeros(class_Count, length(intervals) - 1);
    
    for j=1:length(intervals) - 1
        for i=1:class_Count
            
            if  (j == 1)
                data_j = find(inputdata(:,feature) >= intervals(j)   &  inputdata(:,feature) <= intervals(j+1) );
            else
                data_j = find(inputdata(:,feature) > intervals(j)    &  inputdata(:,feature) <= intervals(j+1) );
            end
            
            class_i = find( classes == i-1);
            
            quanta(i,j) = length(intersect(data_j, class_i));
        end
    end
end


