function varargout = processing(varargin)
% PROCESSING MATLAB code for processing.fig
%      PROCESSING, by itself, creates a new PROCESSING or raises the existing
%      singleton*.
%
%      H = PROCESSING returns the handle to a new PROCESSING or the handle to
%      the existing singleton*.
%
%      PROCESSING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROCESSING.M with the given input arguments.
%
%      PROCESSING('Property','Value',...) creates a new PROCESSING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before processing_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to processing_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help processing

% Last Modified by GUIDE v2.5 28-Sep-2011 23:08:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @processing_OpeningFcn, ...
                   'gui_OutputFcn',  @processing_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before processing is made visible.
function processing_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to processing (see VARARGIN)

% Choose default command line output for processing
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

clc;
clear global;

% Reading data from file
hMainGui = getappdata(0,'hMainGui');
fileName = getappdata(hMainGui, 'fileName');

fid = fopen(fileName,'r');

dName = fgetl(fid);
set(handles.dName, 'String', dName);

data=textscan(fid,'%s','delimiter','\n');
data=data{1};

fid = fclose(fid);

set(handles.objNum, 'String', length(data)-2);

% Preprocessing data read in
for i=1:length(data)
    A{i} = textscan(data{i},'%s','delimiter',',');
    A{i} = A{i}{1};
end

A=A(:);
[x,y] = size(A);
[m,n] = size(A{1});
set(handles.attNum, 'String',m-1);

for j=1:m
    cnames{j} = char(A{1}{j});
end

set(handles.uitable1, 'ColumnName', cnames);
set(handles.uitable3, 'ColumnName', cnames);

for i=1:x-2
    for j=1:m
        T{i,j}=char(A{i+2}{j});
    end
end


%Gathering infomation of continuous features
count = 0;
for j=1:m-1
    if strcmp(char(A{2}{j}),'Real') || strcmp(char(A{2}{j}),'Integer')
        count = count + 1;
        %cnames2 contains the column names of continuous fields
        %continuousColumn contains the column # of continous fields
        cnames2{count} = char(A{1}{j});
        continuousColumn(count) = j;
        for i=1:x-2
            T{i,j}=str2num(T{i,j});
        end
    end
end
set(handles.popupmenu1, 'String', cnames2);

%Gathering infomation of class numbers
classNames{1}=T{1,m};
classNum=1;
for i=2:x-2
    check=1;
    for p=1:classNum
        if strcmp(T{i,m},classNames{p})
            check=0;
            break;
        end
    end
    if check
        classNum=classNum+1;
        classNames{classNum}=T{i,m};
    end
end

set(handles.conAttrNum, 'String',count);
set(handles.uitable2, 'ColumnName', cnames2);
set(handles.uitable1, 'Data', T);
set(handles.claNum, 'String', classNum);

%Obtain the possible boundaries
global Boundary;
k = 1;
for j=1:m-1
    if strcmp(char(A{2}{j}),'Real') || strcmp(char(A{2}{j}),'Integer')
        for q=1:x-2
            tmp(q) = T{q,j};
        end
        tmp=sort(tmp);
        for i=1:x-3
            B{i,k}=(tmp(i)+tmp(i+1))/2;
        end
        Boundary{1,k}=tmp(1);
        Boundary{2,k}=tmp(x-2);
        k=k+1;
    end
end

% Main algorithm is here
global LOGList;
for j=1:count
    GlobalCAIM=0;
    Iterator=1;
    boundaryNum=2;
    
    while 1
        LocalCAIM=0;
        boundaryChosen=0;
        %Try to find the one with the highest CAIM
        for i=1:x-3
            check=0;
            [p,q]=size(Boundary);
            %in B but not already in Boundary
            for l=1:p
                if Boundary{l,j}==B{i,j}
                    check=1;
                    break;
                end
            end
            if check
                continue;
            else
                for g=1:boundaryNum
                    testBoundary(g)=Boundary{g,j};
                end
                testBoundary(boundaryNum+1)=B{i,j};
                testBoundary=sort(testBoundary);

                %Initialization for Quanta Matrix
                for g=1:boundaryNum % Actual BoundaryNum is BoundaryNum+1; but IntervalNum is BoundaryNum+1-1
                    for h=1:classNum
                        Quanta(h,g)=0;
                    end
                end
                
                %calculate Quanta Matrix
                for f=1:x-2
                    for g=1:boundaryNum+1
                        if testBoundary(g)>T{f,continuousColumn(j)};
                            break;
                        end
                    end
                    for h=1:classNum
                        if strcmp(classNames{h},T{f,m})
                            break;
                        end
                    end
                    Quanta(h,g-1)=Quanta(h,g-1)+1;
                end
            end
            
            %Calculate CAIM 
            intervalTotal = sum(Quanta);
            
            Sum = 0;
            for g=1:boundaryNum
                Sum=Sum+max(Quanta(:,g))/intervalTotal(g)*max(Quanta(:,g));
            end
            CAIM = Sum/boundaryNum;
            
            if CAIM > LocalCAIM
                LocalCAIM = CAIM;
                boundaryChosen=i;
            end

        end
        
        % write to logs
        LOG{Iterator,1}=LocalCAIM;
        LOG{Iterator,2}=GlobalCAIM;
        LOG{Iterator,3}=B{boundaryChosen,j};

        
        if LocalCAIM > GlobalCAIM || Iterator<classNum
            LOG{Iterator,4}='Yes';
            GlobalCAIM = LocalCAIM;
            LOG{Iterator,5}=boundaryNum;
            boundaryNum=boundaryNum+1;
            Boundary{boundaryNum,j}=B{boundaryChosen,j};
            Iterator=Iterator+1;
            LOGList{j} = LOG;
        else
            LOG{Iterator,4}='No';
            LOG{Iterator,5}=boundaryNum-1;
            LOGList{j} = LOG;
            break;
        end

    end               
                
end


% Sort the boundary for analysis
for j=1:count
    for i=1:Iterator
        for k=1:Iterator-i+1
            if Boundary{k,j}>Boundary{k+1,j}
                temp=Boundary{k,j};
                Boundary{k,j}=Boundary{k+1,j};
                Boundary{k+1,j}=temp;
            end
        end
    end
end
    
set(handles.uitable2, 'Data', Boundary);


global DataDist;
DataDist=zeros(count,Iterator);
for j=1:count
    for i=1:x-2
        for k=2:Iterator+1;
            if T{i,continuousColumn(j)} < Boundary{k,j}
                break;
            end
        end
        T{i,continuousColumn(j)}=k-1;
        DataDist(j,k-1)=DataDist(j,k-1)+1;
    end
end


set(handles.uitable3, 'Data', T);
set(handles.uitable4, 'Data', LOGList{1});
% UIWAIT makes processing wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = processing_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)


global LOGList;
global DataDist;
global Boundary;

feature = get(handles.popupmenu1, 'Value');
[m,n]=size(Boundary);
init = [num2str(Boundary{1,feature}),'  ',num2str(Boundary{m,feature})];
set(handles.text17, 'String', init);
set(handles.uitable4, 'Data', LOGList{feature});
bar(handles.axes1,DataDist(feature,:));

% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
