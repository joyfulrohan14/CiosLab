function  CLIP4()

%   Name: Raid Mohaidat
%   Homework 2 - Implementation  of CLIP4 ALGORITHM
%   CMSC635 KNOWLEDGE DISCOVERY&DATA MINING -  Fall2011
%   11/09/2011
%   Input : There are four comma seperated data files in text format; 1-   Travel.txt, 2- Weather.txt, 3- iris.txt ,
%            4- Heart.txt
%   Output: The implementation will display the rules and solution
%
%   Instruction:
%   1-  In Matlab's command window , Type Implement_CLIP4() and press enter
%   2-  You will be prompted with a choice of dataset to use, type 1,
%   2,3,0r 4
%   and press enter
%   a "result.txt" text file will be generated in the same directorywhere
%   the file is
%

tic
clc
close all, clear all, format compact

%%
%% Reading in the input data and its correspoding classes
% Given: Data consisting of M examples, S classes, and
% Aattributes Fi
global Idata
fprintf('Enter the dataset number to be used in implementation \n');
fnum = input('(1) for Travel , (2) for Weather , (3) for Iris , (4) Heart  (Type the number and press Enter) : ');
classoptions=1;

if      fnum ==1
    Idata=1;
    fileName='Travel.csv';
    Indata=load('Travel.csv');
    classoptions=1
elseif  fnum ==2
    Idata=2;
    fileName='Weather.csv';
    Indata=load('Weather.csv');
    classoptions=1
elseif  fnum ==3
    Idata=3;
    fileName='Iris.csv';
    Indata=load('Iris.csv');
    classoptions=3
else
    Idata=4;
    fileName='Heart.csv';
    Indata=load('Heart.csv');
    classoptions=1
end
fid = fopen('result.txt', 'w');
fid2 = fopen('result2.txt', 'w');

% Ignore a node that has a positive with values less than 5% of the
% previuos node
Noise_Threshold=2
% Pruning_Threshold = # of rows of POS1 / # of 1's in the SOL
Pruning_Threshold=0; %choose the one with the maximum fitteness value
% For removing records that has been identified by another set of rules
Stop_Threshold=1

for permutations=1:classoptions %this is to scan through all possibilities of the three classes of Iris
    S=[]; P=[]; N=[]; BIN=[]; tm=[]; POS11=[]; FSOL=[]; IND=[]; INDfinal=[]; begen=[]; Pfinal=[]; beg=[]; Ptemp=[];   Ptemp1=[];
    en=[]; red1=0; temp1=0; temp2=0; temp1=size(Indata,2); temp2=unique(Indata(:,temp1)); % all possible classes
    % Generating the POS and NEG matrices
    if length(temp2) > 2  % if the number of classes is more than two ( Iris case) then we consider the three possible options
        if permutations == 1
            % in the case of {1,23}, 1=pos and 23=neg
            posrec=Indata(find(Indata(:,temp1)==temp2(1)),1:temp1-1);
            negrec=Indata(find(Indata(:,temp1)==temp2(2)),1:temp1-1);
            negrec=[negrec; Indata(find(Indata(:,temp1)==temp2(3)),1:temp1-1)];
        elseif permutations == 2
            % in the case of {1,23}, 2=pos and 13=neg
            posrec=Indata(find(Indata(:,temp1)==temp2(2)),1:temp1-1);
            negrec=Indata(find(Indata(:,temp1)==temp2(1)),1:temp1-1);
            negrec=[negrec; Indata(find(Indata(:,temp1)==temp2(3)),1:temp1-1)];
        elseif permutations == 3
            % in the case of {1,23}, 3=pos and 12=neg
            posrec=Indata(find(Indata(:,temp1)==temp2(3)),1:temp1-1);
            negrec=Indata(find(Indata(:,temp1)==temp2(1)),1:temp1-1);
            negrec=[negrec; Indata(find(Indata(:,temp1)==temp2(2)),1:temp1-1)];
        end
    else
        % in the case of the other datasets - two class options only
        posrec=Indata(find(Indata(:,temp1)==temp2(1)),1:temp1-1)
        negrec=Indata(find(Indata(:,temp1)==temp2(2)),1:temp1-1)
    end
    for i22=1:2 %POS and NEG matrices
        Ptemp=[];Ptemp1=[];FSOL=[];red1=0;beg=[];en=[];begen=[];Pfinal=[];INDfinal=[];
        temp1=0;temp2=0;BIN=[];tm=[];POS11=[];P=[];IND=[];N=[];S=[];
        temp1=size(Indata,2);temp2=unique(Indata(:,temp1));str3=[];
        POS=posrec
        NEG=negrec
        P=[];
        % Ignore a node that has a positive with values less than 5% of the
        % previuos node
        Noise_Threshold=2
        % Pruning_Threshold = # of rows of POS1 / # of 1's in the SOL
        Pruning_Threshold=0;
        % For removing records that has been identified by another set
        % of rules
        Stop_Threshold=size(POS,1) %to remove the examples which have been covered by another set
        
        
        disp('--------------- POS and NEG matrices are completed  and ready for Phase I -------------')
        
        disp('--------------- PHASE I -------------')
        for inode=1:size(NEG,1) % for all neg examples
            red1=0;
            %splitting the POS matrices according to the solution
                %vector
            disp(['------ Node',num2str(inode),'--------'])
            if inode ~= 1
                if isempty(beg)==false  & isempty(Ptemp1)==false
                    for isplit=1:length(IND)
                        POS= Ptemp1(beg(isplit):en(isplit),:)
                        SOL=final_solution(POS,NEG(inode,:))
                        S=[S; SOL]
                    end
                else
                    SOL=final_solution(POS,NEG(inode,:))
                    S=[S; SOL]
                end
            else
                SOL=final_solution(POS,NEG(inode,:))
                S=[S; SOL]
            end
            Pruning_Threshold=size(P,1)/length(find(SOL==1))
            n1=NEG(inode,:);
            POS1=[];
            IND=[];N=[];
            isp=0;
            i8=0;
            for isolj=1:size(S,1)
                SOL=S(isolj,:)
                ind21=0
                for isol=1:length(SOL)
                    if SOL(isol) ~= 0
                       if inode ~= 1
                          i8=i8+1;
                          if isempty(beg)==false & isempty(Ptemp1)==false
                             if max(max([beg en])) <= size(Ptemp1,1)
                                POS= Ptemp1(beg(isolj):en(isolj),:)
                             else
                                POS=Ptemp1
                             end
                          else
                             POS=Ptemp1
                          end
                        end %end of if inode
                        if length(find(SOL==1))>1
                            ind21=ind21+1
                            ind1=find(SOL==1)
                            POS1=POSMAT(POS,n1,ind1(ind21))
                        else
                            ind2=find(SOL==1)
                            POS1=POSMAT(POS,n1,ind2)
                        end
                        POS1
                        if size(POS1,1)==size(P,1)
                            dd=POS1(:)-P(:);
                            if sum(dd) ~= 0
                                Ptemp=P;P=[P; POS1]
                                Ntemp=N;N=[N; n1]
                                INDtemp=IND;IND=[IND; size(POS1,1)]
                            end
                        else
                            Ptemp=P;P=[P; POS1]
                            Ntemp=N;N=[N; n1]
                            INDtemp=IND;IND=[IND; size(POS1,1)]
                        end
                        if size(P,1)>size(POS1,1) & size(POS1,1)<=Noise_Threshold
                            red1=redundant(P,POS1)
                        end
                        if red1 ~=0
                            P=Ptemp;
                            N=Ntemp;
                            IND=INDtemp;
                            POS1=[];
                        end %if redundnat
                    end %if SOL..
                end %isol
            end %endof isolj, scan through the solution matrix S

            %begining and ending for all POS in P matrix
            if size(P,1)>size(POS,1)
                beg=[];en=[];s=0;
                for j0=1:length(IND)
                    s=s+IND(j0);
                    en=[en; s];
                    beg=[beg; s-IND(j0)] ;
                    beg=beg;
                end
                beg=beg+1;
                begen=[beg en];
                S=[];
                Ptemp=P;
                Ptemp1=P;
            end
            Ptemp1=P;
            P=[];

            % saving the matrices
            if inode==size(NEG,1)
                Pfinal=Ptemp1;
                INDfinal=[INDfinal; size(POS,1)]
                IND
            end

        end

        disp('--------------- PHASE II and III -------------')
        tm=TM1(posrec,Ptemp1,IND)
        n1=NEG(size(NEG,1),:)
        SOL=SOL_BIN(tm)

        for isplit=1:length(INDfinal)
            excovered=[];
            str5=[];
            if isempty(beg)==false
                POS1= Pfinal(beg(isplit):en(isplit),:)
            else
                POS1=Pfinal;
            end

            flag2=CHECKZEROS(NEG,POS1);
            if flag2==0; % calculate backproj 
                [s BNEG]=BBIN1(NEG,POS1);
            else % if all are zero then break the loop
                break;
            end

            % Generate rules
            switch Idata
                case 1
                    rulesstr=TRAV2STR(BNEG,s,i22);
                case 2
                    rulesstr=WEA2STR(BNEG,s,i22);
                case 3
                    rulesstr=IRIS2STR(BNEG,s,permutations);
            end
            % Select the rule that covers the largest number of examples
            excovered=EXAMRULES(POS1,BNEG,s);
            str5=[str5; length(excovered)];
            str3=[str3 rulesstr '; '];
        end
        str3
        fprintf(fid2, '%s\n \r', str3)
        str5;
        [v,i]=max(str5);
        i; % Index of the maximum number of examples covered
        PP=posrec;
        while v < Stop_Threshold
            i15=0;
            for i14=1:size(PP,1)
                if find(i14==excovered)
                else
                    i15=i15+1;
                    POS1(i15,:)=PP(i14,:);
                end
            end
            flag2=CHECKZEROS(NEG,POS1);
            if flag2==0 ;
                [s BNEG]=BBIN1(NEG,POS1);
            else 
                break; % break if all zeros
            end
            %generate rules
            switch Idata
                case 1
                    rulesstr=TRAV2STR(BNEG,s,i22);
                case 2
                    rulesstr=WEA2STR(BNEG,s,i22);
                case 3
                    rulesstr=IRIS2STR(BNEG,s,permutations);
            end
            excovered=EXAMRULES(POS1,BNEG,s);
            str5=[str5; length(excovered)];
            str3=[str3 rulesstr ';']

            fprintf(fid, '%s\n \r', str3)
            [v,i]=max(str5);
            v=sum(str5);
            PP=POS1;
            %*******************************************
        end %end of while 

        %generate the first rule
        temp22=posrec;
        temp23=negrec;
        posrec=temp23;
        negrec=temp22;
    end 

end %end of for loop for permutations

fclose(fid);
fclose(fid2);
end




%%




%%
function redund=redundant(P,POS1)
%this function is to find out of the POS1 available in P
% if redund=1 then the submatrix is available in the big matrix

redund=0;
iindex=0 ;
%removing the redundant data

if length(P) ~= 0 & size(POS1,1) < size(P,1)
    %find block of POS1 in P
    for j5=1:size(POS1,1)
        for i5=1:size(P,1)
            if length(find(P(i5,:)==POS1(j5,:)))==size(P,2)
                if i5==(iindex+1) & j5>1
                    redund=1;
                else
                    iindex=i5;
                end

            end
        end %end  i5. end of redundant data
    end % end of j5

end %end of if length(P)

if redund==0
    if iindex~=0
        redund=1;
    end
else
    redund
end
end
%%

function SOL=SOL_BIN(S)
%SOL function is to get the solution of the binary matrix S
%function SOL=SOL_BIN(S,SOL,SOL1,accol,ac)

SOL=zeros(size(S,2),1);SOL=SOL';
SOL1=zeros(size(S,2),1)';
accol=1:size(S,2);
ac=1:size(S,1);

while length(ac) ~= 0

    Mir=[];
    for irow=1:size(S,1)
        if find(ac==irow) ~= 0
            Mir=[Mir; irow sum(length(find(S(irow,:)==1)))];
        end
    end
    [bb,ii]=sort(Mir(:,2));
    Mir_temp=[Mir(ii) bb];

    %-----------------------------------------
    temp0=0;temp1=1;Mir_temp1=[];%ac=[];
    if size(Mir_temp,1) > 1
        %check if the Mir_temp is zero
        i9=0;
        for i10=1:size(Mir_temp,1)
            if sum(Mir_temp(i10,2)~=0)
                i9=i9+1;
                Mir_temp1(i9,:)=Mir_temp(i10,:);
            end
        end
        temp0=Mir_temp1(1,2);
        %ac=find(Mir_temp(:,2)~=0)
        ac=Mir_temp1(:,1)
        for i=2:length(ac)
            if Mir_temp1(i,2) ~= temp0,  break
            end
            temp1=i;
        end
    end

    temp1
    Mir_temp=Mir_temp1;
    %-----------------------------------------
    if temp1==size(Mir,1)
        Mir_temp=Mir;
    end

    Mir_final=Mir_temp(1:temp1,:)
    min_index=Mir_final(:,1)%min_index=Mir_final(:,1)
    min_ones=Mir_final(:,2)
    n0=length(find(S(min_index,:)==1));
    if temp1 ~= 1 & n0 ~= 1

        if size(S,1) > 1
            Mic=[];
            for icol=1:size(S,2)
                if find(accol==icol) ~= 0
                    Mic=[Mic; icol sum(length(find(S(min_index,icol)==1)))];
                end
            end
            [bb,ii]=sort(Mic(:,2),'descend');
            Mac_temp=[Mic(ii) bb];
            temp0=0;temp1=1;
            if size(Mac_temp,1) > 1
                temp0=Mac_temp(1,2);
                for i=2:size(S,2) %length(ac)
                    if Mac_temp(i,2) ~= temp0,  break
                    end
                    temp1=i;
                end
            end
            temp1
            if temp1 > 1 %if there are more than one column index with same number of 1's
                %find out if all rows are active
                if length(ac)==size(S,1)
                    %find out the max number of 1's in all columns
                    %if the case of same number of 1's in the columns then the
                    %first column will be taken
                    %Mac_temp=Mac_temp(1:temp1,:);
                    %++++++++++++++++++

                    Mic=[];
                    for icol=1:temp1
                        Mic=[Mic; Mac_temp(icol,1) length(find(S(:,Mac_temp(icol,1))==1))];
                    end
                    Mac_temp=Mic
                    %                 [bb]=sort(Mic,1,'descend')%[bb]=sort(Mic)%[bb,ii]=sort(Mic(:,2),'descend')
                    %                  Mac_temp=[bb]%Mac_temp=[bb]%Mac_temp=[ii bb]
                    %                 temp0=0;temp1=1;
                    %                 if size(Mac_temp,1) > 1
                    %                     temp0=Mac_temp(1,2);
                    %                     for i=2:size(Mac_temp,2) %for i=2:length(ac)
                    %                         if Mac_temp(i,2) ~= temp0,  break
                    %                         end
                    %                         temp1=i
                    %                     end
                    %                 end
                    %find out the MAX number of 1's in the columns

                    temp0=0;temp2=1;
                    if size(Mac_temp,1) > 1
                        temp0=Mac_temp(1,2);
                        for i=2:size(Mac_temp,2) %for i=2:length(ac)
                            if Mac_temp(i,2) ~= temp0,  break
                            end
                            temp2=i;
                        end
                    end

                    temp2
                    if temp2 == 1
                        Mac_temp=sort(Mac_temp,1,'descend');
                    end

                    %++++++++++++++++++++
                else
                    %find out the min number of 1's in the inactive rows
                    %OR the MIN number of 1's in all columns corresponding to the
                    %=======
                    Mic=[];
                    for icol=1:temp1
                        Mic=[Mic; Mac_temp(icol,1) length(find(S(:,Mac_temp(icol,1))==1))];
                    end
                    [bb,ii]=sort(Mic(:,2),'ascend');
                    Mac_temp=[Mic(ii) bb];
                    %Mac_temp=sort(Mic,1)
                    temp0=0;temp1=1;
                    if size(Mac_temp,1) > 1
                        temp0=Mac_temp(1,2);
                        for i=2:size(Mac_temp,1)%for i=2:length(ac)
                            if Mac_temp(i,2) ~= temp0,  break
                            end
                            temp1=i;
                        end
                    end
                    %=======
                end
            else
                %find out the max number of 1's in all active rows
                %--------
                Mic=[];
                for icol=1:temp1
                    Mic=[Mic; Mac_temp(icol,1) length(find(S(:,Mac_temp(icol,1))==1))]
                end
                [bb,ii]=sort(Mic(:,2),'descend');
                [bb(1) Mic(ii(1))];
                Mac_temp=[Mic(ii) bb];
                temp0=0;temp1=1;
                if size(Mac_temp,1) > 1
                    temp0=Mac_temp(1,2);
                    for i=2:length(ac)
                        if Mac_temp(i,2) ~= temp0,  break
                        end
                        temp1=i;
                    end
                end
                %--------
            end
            Mac_final=Mac_temp(1:temp1,:)
            if temp1 > 1
                max_index=Mac_final(:,1);
                max_ones=Mac_final(:,2);
            else
                max_index=Mac_final(:,1);
                max_ones=Mac_final(:,2);
            end
        else
            [a,i]=find(S==1);
            max_index(1)=i(1);
        end
    else %if temp1 ~=1
        max_index=find(S(min_index,:)==1); %min_index
    end %if temp ~= 1
    %finding the solution
    SOL(max_index(1))=1;


    SOL=SOL | SOL1;
    SOL1=SOL;
    ac=[];
    a=find(SOL==1);
    for iac=1:size(S,1)
        if S(iac,a) ~= 1 & S(iac,a) ~= 0
            ac=[ac iac];
        end
    end
    ac;
end

% % % end %end of if size (S,2)

end


%%
function [str1]=TRAV2STR(BNEG1,SOLU,yesno)
%TRAV2STR is to change the travel solution and BGEN matrix to rules. This
%will be returned as str1
BNEG=[];s=[];
BNEG=BNEG1
s=SOLU

% s =[1     1     0     0]
%
%
% BNEG =[1     0     0     1
%        1     0     0     2
%        0     1     0     2
%        0     4     0     4]

%Travel
Type_of_Call=char('local', 'long', 'Intern');
Lang_Fluency=char('Fluent', 'Not fluent', 'Accent', 'Foreign');
Ticket_Type=char('Long', 'Local', 'Short');
Age=char('Very young', 'old', 'Middle', 'Very old', 'Young');
Decision=char(' Buy', ' Not buy');



% IF F4 = 1 AND F4 = 2 AND F4 = 4 THEN BUY
travmat=char('Type_of_Call',  'Lang_Fluency',  'Ticket_Type', 'Age', ' Decision') ;
ones=[];str1=[];
ones=find(s==1);
for it=1:length(ones)
    travel=ones(it);
    travmat(travel);
    switch travel

        case 1
            Type_of_Call=char('local', 'long', 'Intern');
            xt=BNEG(:,travel);
            xt=unique(xt);
            %str1=[];
            for jt=1:length(xt)%size(BNEG,1)
                if xt(jt) ~= 0
                    Type_of_Call(xt(jt),:);
                    if jt==length(xt)
                        str1=[str1 ' Type_of_Call = ' Type_of_Call(xt(jt),:)]
                    else
                        str1=[str1 ' Type_of_Call = ' Type_of_Call(xt(jt),:), ' AND']
                    end % end of if jt
                end
            end
            %str2=strcat(' Decision ',Decision(1,:));
           % str2=strcat(Decision(1,:));
           % str1=strcat('IF ', str1, ' THEN ',' ', str2);
        case 2
            Lang_Fluency=char('Fluent', 'Not fluent', 'Accent', 'Foreign');
            xt=BNEG(:,travel);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    Lang_Fluency(xt(jt),:);
                    if jt==length(xt)
                        str1=[str1 ' Lang_Fluency = ' Lang_Fluency(xt(jt),:)];
                    else
                        str1=[str1 ' Lang_Fluency = ' Lang_Fluency(xt(jt),:), ' AND'];
                    end % end of if jt
                end
            end
            %str2=strcat(' Decision ',Decision(1,:));
           % str2=strcat(Decision(1,:));
           % str1=strcat('IF ', str1, ' THEN ',' ', str2);
        case 3
            Ticket_Type=char('Long', 'Local', 'Short');
            xt=BNEG(:,travel);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    Ticket_Type(xt(jt),:);
                    if jt==length(xt)
                        str1=[str1 ' Ticket_Type = ' Ticket_Type(xt(jt),:)];
                    else
                        str1=[str1 ' Ticket_Type = ' Ticket_Type(xt(jt),:), ' AND'];
                    end % end of if jt
                end
            end
           % str2=strcat(' Decision ',Decision(1,:));
            %str2=strcat(Decision(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2);
        case 4
            Age=char('Very young', 'old', 'Middle', 'Very old', 'Young');
            xt=BNEG(:,travel);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    Age(xt(jt),:);
                    if jt==length(xt)
                        str1=[str1 ' Age = ' Age(xt(jt),:)];
                    else
                        str1=[str1 ' Age = ' Age(xt(jt),:), ' AND '];
                    end % end of if jt
                end
            end
           % str2=strcat(' Decision ',Decision(1,:));
           % str2=strcat(Decision(1,:));
           % str1=strcat('IF ', str1, ' THEN ',' ', str2);
        case 5
            Decision=char(' Buy', ' Not buy');
    end

end % end of for it
str2=strcat(' Decision ',Decision(yesno,:));
str1=strcat('IF ', str1, ' THEN ',' ', str2);
end
%%
function [str1]=WEA2STR(BNEG1,SOLU,yesno)
BNEG=[];s=[];
BNEG=BNEG1
s=SOLU
outlook=char('sunny', 'overcast' ,'rainy');
temperature=char('hot', 'mild', 'cool');
humidity=char('high', 'normal');
windy=char('FALSE', 'TRUE');
play=char(' no', ' yes');

weatmat=char('outlook',  'temperature',  'humidity', 'windy', ' play') ;
ones=[];str1=[];
ones=find(s==1);
for it=1:length(ones)
    weather=ones(it);
    weatmat(weather);
    switch weather
        case 1
            outlook=char('sunny', 'overcast' ,'rainy');
            xt=BNEG(:,weather);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    if jt==length(xt)
                        str1=[str1 ' outlook = ' outlook(xt(jt),:)];
                    else
                        str1=[str1 ' outlook = ' outlook(xt(jt),:), ' AND'];
                    end
                end
            end
            %str2=strcat(play(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2)
        case 2
            temperature=char('hot', 'mild', 'cool');
            xt=BNEG(:,weather);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    if jt==length(xt)
                        str1=[str1 ' temperature = ' temperature(xt(jt),:)];
                    else
                        str1=[str1 ' temperature = ' temperature(xt(jt),:), ' AND'];
                    end 
                end
            end
            %str2=strcat(play(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2)
        case 3
            humidity=char('high', 'normal');
            xt=BNEG(:,weather);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    if jt==length(xt)
                        str1=[str1 ' humidity = ' humidity(xt(jt),:)];
                    else
                        str1=[str1 ' humidity = ' humidity(xt(jt),:), ' AND'];
                    end
                end
            end
            %str2=strcat(' play ',play(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2)
        case 4
            windy=char('FALSE', 'TRUE');
            xt=BNEG(:,weather);
            xt=unique(xt);
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    if jt==length(xt)
                        str1=[str1 ' windy = ' windy(xt(jt),:)];
                    else
                        str1=[str1 ' windy = ' windy(xt(jt),:), ' AND '];
                    end 
                end
            end
           % str2=strcat(' play ',play(1,:));
           % str2=strcat(play(1,:));
           % str1=strcat('IF ', str1, ' THEN ',' ', str2)
        case 5
            play=char(' no', ' yes');
    end

end % end of for it
str2=strcat(' play ',play(yesno,:));
str1=strcat('IF ', str1, ' THEN ',' ', str2);
end

%%


function [str1]=IRIS2STR(BNEG1,SOLU,yesno)
BNEG=[];s=[];
BNEG=BNEG1;
s=SOLU;

sepallength=char('(3.05-4.4]', '(2.95-3.05]', '[2-2.95]');
sepalwidth=char('[1-2.45]', '(2.45-4.75]', '(4.75-6.9]');
petallength=char('[0.1-0.8]', '(0.8-1.75]', '(1.75-2.5]');
petalwidth=char('Iris-setosa', 'Iris-versicolor', 'Iris-virginica');
classname=char(' Iris-setosa', ' Iris-versicolor', ' Iris-virginica');

irismat=char('sepallength',  'sepalwidth',  'petallength', 'petalwidth', ' classname') ;
ones=[];
ones=find(s==1);
for it=1:length(ones)
    iris1=ones(it);
    irismat(iris1);
    switch iris1

        case 1
            sepallength=char('(3.05-4.4]', '(2.95-3.05]', '[2-2.95]');
            xt=BNEG(:,iris1);
            xt=unique(xt);
            str1=[];
            for jt=1:length(xt)
                if xt(jt) ~= 0
                    sepallength(xt(jt),:);
                    if jt==length(xt)
                        str1=[ str1 ' sepallength = ' sepallength(xt(jt),:)];
                    else
                        str1=[str1 ' sepallength = ' sepallength(xt(jt),:), ' AND '];
                    end % end of if jt
                end
            end
            %str2=strcat(' classname ',classname(1,:));
            %str2=strcat(classname(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2);
            %disp(['IF ', str1,  'THEN ',classname(1,:)])

        case 2
            sepalwidth=char('[1-2.45]', '(2.45-4.75]', '(4.75-6.9]');
            xt=BNEG(:,iris1);
            xt=unique(xt);
            str1=[];
            for jt=1:length(xt)%size(BNEG,1)
                if xt(jt) ~= 0
                    sepalwidth(xt(jt),:);
                    if jt==length(xt)
                        str1=[ str1 ' sepalwidth = ' sepalwidth(xt(jt),:)];
                    else
                        str1=[ str1 ' sepalwidth = ' sepalwidth(xt(jt),:), ' AND '];
                    end % end of if jt
                end
            end
           % str2=strcat(' classname ',classname(1,:));
            %str2=strcat(classname(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2);
            %disp(['IF ', str1,  'THEN ',classname(1,:)])

        case 3
            petallength=char('[0.1-0.8]', '(0.8-1.75]', '(1.75-2.5]');
            xt=BNEG(:,iris1);
            xt=unique(xt);
            str1=[];
            for jt=1:length(xt)%size(BNEG,1)
                if xt(jt) ~= 0
                    petallength(xt(jt),:);
                    if jt==length(xt)
                        str1=[ str1 ' petallength = ' petallength(xt(jt),:)];
                    else
                        str1=[str1 ' petallength = ' petallength(xt(jt),:), ' AND '];
                    end % end of if jt
                end
            end
           % str2=strcat(' classname ',classname(1,:));
            %str2=strcat(classname(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2);
            %disp(['IF ', str1,  'THEN ',classname(1,:)])

        case 4
            petalwidth=char('Iris-setosa', 'Iris-versicolor', 'Iris-virginica');
            xt=BNEG(:,iris1);
            xt=unique(xt);
            str1=[];
            for jt=1:length(xt)%size(BNEG,1)
                if xt(jt) ~= 0
                    petalwidth(xt(jt),:);
                    if jt==length(xt)
                        str1=[str1 ' petalwidth = ' petalwidth(xt(jt),:)];
                    else
                        str1=[str1 ' petalwidth = ' petalwidth(xt(jt),:), ' AND '];
                    end % end of if jt
                end
            end
           % str2=strcat(' classname ',classname(1,:));
            %str2=strcat(classname(1,:));
            %str1=strcat('IF ', str1, ' THEN ',' ', str2);
            %disp(['IF ', str1,  'THEN ',classname(1,:)])
        case 5
            classname=char(' Iris-setosa', ' Iris-versicolor', 'Iris-virginica');
    end

end % end of for it
str2=strcat(' classname ',classname(yesno,:));
str1=strcat('IF ', str1, ' THEN ',' ', str2);
end

%%


%%

function P1=POSMAT(P,n,ind)
%extracting POS1 from POS
i0=0;P1=[];
isol=ind;
for i1=1:size(P,1)
    if P(i1,isol) ~= n(isol)
        i0=i0+1;
        P1(i0,:)=P(i1,:);
    end
end %end of i1

P1

end
%%

function [tmatrix] = TM1(pos,pfinal,indfinal)
%this function is to generate the TM matrix as first step of PHASE II

P=[];INDfinal=[];Pinal=[];
P=pos
INDfinal=indfinal
Pfinal=pfinal
%P=posrec; %original data POS
beg=[];en=[];s=0;TM=[];begen=[];TM=zeros(size(P,1),length(INDfinal))
tmatrix=[];


for j0=1:length(INDfinal)
    s=s+INDfinal(j0);
    en=[en; s];
    beg=[beg; s-INDfinal(j0)] ;
    beg=beg;
end
beg=beg+1;
begen=[beg en]

for isplit=1:length(INDfinal)
    P1= Pfinal(beg(isplit):en(isplit),:) %splitting the data from PHASE I into TM

    %for irows=1:size(P1,1)

    for itm=1:size(P,1)

        for jtm=1:size(P1,1)
            if length(find(P1(jtm,:)==P(itm,:)))==size(P,2)
                TM(itm,isplit)=1;
                %                      else
                %                          TM(itm,isplit)=0
            end
        end %end of for jtm

    end %end of for itm
    %end %end of irows

end %end of for isplit

tmatrix=TM


end

%%


%%

function SOL=final_solution(pmat,nmat)
%this function to find out the SOL from the matrix pmat and one row of nmat
BIN=[];
for i=1:size(pmat,1)
    for j=1:size(pmat,2)
        pmat(i,j);
        nmat(1,j);
        if pmat(i,j)==nmat(1,j)
            BIN(i,j)=0;
        else
            BIN(i,j)=1;
        end
    end
end

S=BIN;
if size(BIN,2)==2
    SOL=[1 1];
end

%function SOL=SOL_BIN(S,SOL,SOL1,accol,ac)

SOL=SOL_BIN(S)

end

%%

function [examind]=EXAMRULES(posrec,BNEG,SOL)
p=posrec;
n=BNEG;
s=SOL;

n2=[];
ind12=[];
examind=[];
n2=find(s==1);

for i11=1:length(n2)
    n1=unique(n(:,n2(i11)));
    for j11=1:length(n1)
        indtemp=find(p(:,n2(i11))==n1(j11));
        if isempty(indtemp)==false
            ind12=[ind12; indtemp];
        end
    end
end

indpos=unique(ind12);
%number of examples covered by the rules:
if isempty(indpos)==false
    examnu=size(p,1)-length(indpos);
else
    examnu=size(p,1);
end

for i13=1:size(p,1)
    if find(indpos==i13)
    else
        indtemp1=i13;
        examind=[examind; indtemp1];
    end
end


end
%%

function [s BNEG]= BBIN1(negrec,POS1)
%this function is to find out the backproj matrix from the POS1 and NEG
BNEG=[];BBIN=[];
n=negrec
p1=POS1
for ib=1:size(n,1)
    for jb=1:size(p1,2)
        if find(n(ib,jb)==p1(:,jb))
            BNEG(ib,jb)=0;
            BBIN(ib,jb)=0;
        else
            BNEG(ib,jb)=n(ib,jb);
            BBIN(ib,jb)=1;
        end
    end %end of jb
end %end of ib

BNEG;

%get the binary matrix by chnaging every number to 1
BBIN;
s=SOL_BIN(BBIN);

end


%%

function flag1=CHECKZEROS(n,p)
%this function to check if the matrix are with zero elements
BNEG=[];BBIN=[];
p1=p;
for ib=1:size(n,1)
    for jb=1:size(p1,2)
        if find(n(ib,jb)==p1(:,jb))
            BNEG(ib,jb)=0;
            BBIN(ib,jb)=0;
        else
            BNEG(ib,jb)=n(ib,jb);
            BBIN(ib,jb)=1;
        end
    end %end of jb
end %end of ib


BNEG;

if sum(BNEG(:))==0
    flag1=1;
else
    flag1=0;
end
end

%%







