
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
public class Clip4Algo {

    final static int MAX_ROW_NUM = 300;
    final static int MAX_COL_NUM = 80;
    final static boolean DEBUG = false;
    private static BufferedReader csvBuffFile;
    private static String DBName;
    private static String[] DBMetaDataFieldType;

    private static class dataMatrixInt {

        public int n,  m;
        public int[][] value = new int[MAX_ROW_NUM][MAX_COL_NUM];
    };

    private static class dataMatrixString {

        public int n,  m;
        public String[][] value = new String[MAX_ROW_NUM][MAX_COL_NUM];
    };
    static String[] title = new String[MAX_COL_NUM];
    static HashSet<String> myclass;
    static int colnum;
    static String currentclass;

    static void printMatrix(dataMatrixInt m) {
        int i, j;
        for (i = 0; i < m.m; i++) {
            for (j = 0; j < m.n; j++) {
                System.out.printf("%d ", m.value[i][j]);
            }
            System.out.printf("\n");
        }
    }

    static void printMatrix(dataMatrixString m) {
        int i, j;
        for (i = 0; i < m.m; i++) {
            for (j = 0; j < m.n; j++) {
                System.out.printf("%s ", m.value[i][j]);
            }
            System.out.printf("\n");
        }
    }
    static int[] used_row = new int[MAX_ROW_NUM];

    static void getMinRows(dataMatrixInt source) {
        int i, j;
        int mincnt = MAX_COL_NUM;
        for (i = 0; i < source.m; i++) {
            if (used_row[i] == 1) {
                continue;
            }
            int cnt = 0;
            for (j = 0; j < source.n; j++) {
                cnt += source.value[i][j];
            }
            if (cnt == 0) {
                used_row[i] = 1;
                continue;
            }
            if (cnt < mincnt) {
                mincnt = cnt;
            }
        }
        if (DEBUG) {
            System.out.printf("min rows: ");
        }
        for (i = 0; i < source.m; i++) {
            if (used_row[i] == 1) {
                continue;
            }
            int cnt = 0;
            for (j = 0; j < source.n; j++) {
                cnt += source.value[i][j];
            }
            if (cnt == mincnt) {
                used_row[i] = 2;
                if (DEBUG) {
                    System.out.printf("%d ", i);
                }
            }
        }
        if (DEBUG) {
            System.out.printf("\n");
        }
    }

    static void removeEmptyRows(dataMatrixInt source) {
        int i, j;
        for (i = 0; i < source.m; i++) {
            int cnt = 0;
            for (j = 0; j < source.n; j++) {
                cnt += source.value[i][j];
            }
            if (cnt == 0) {
                used_row[i] = 1;
            }
        }
    }

    static boolean covering_finished(dataMatrixInt source) {
        for (int i = 0; i < source.m; i++) {
            if (used_row[i] == 0) {
                return false;
            }
        }
        return true;
    }

    static public int[][] reset(int[][] in) {
        for (int i = 0; i < in.length; i++) {
            for (int j = 0; j < in[i].length; j++) {
                in[i][j] = 0;
            }
        }
        return in;
    }

    static public int[] reset(int[] in) {
        for (int i = 0; i < in.length; i++) {
            in[i] = 0;
        }
        return in;
    }
    static int[] used_col = new int[MAX_COL_NUM];
    static int[] uc = new int[MAX_COL_NUM];

    static dataMatrixInt setCover(dataMatrixInt source) {
        //solution matrix 
        dataMatrixInt result = new dataMatrixInt();
        result.m = 1;
        result.n = source.n;
        result.value = reset(result.value);
        used_row = reset(used_row);

        removeEmptyRows(source);
        while (!covering_finished(source)) {
            getMinRows(source);

            int i, j;
            used_col = reset(used_col);

            for (i = 0; i < source.m; i++) {
                if (used_row[i] == 2) {
                    for (j = 0; j < source.n; j++) {
                        used_col[j] = used_col[j] + source.value[i][j];
                        if (used_col[j] > 10000) {
                            //while(true);
                        }
                    }
                }
            }

            int maxcnt = 0;
            for (i = 0; i < source.n; i++) {
                if (used_col[i] > maxcnt) {
                    maxcnt = used_col[i];
                }
            }

            int maxone = -1;
            for (i = 0; i < source.n; i++) {
                if (used_col[i] == maxcnt) {
                    if (maxone == -1) {
                        maxone = i;
                    } else {
                        maxone = -2;
                    }
                } else {
                    used_col[i] = 0;
                }
            }
            if (maxone == -2) {
                if (DEBUG) {
                    System.out.printf("method 2(%d)\n", maxcnt);
                    for (i = 0; i < source.n; i++) {
                        if (used_col[i] == maxcnt) {
                            System.out.printf("%d ", i);
                        }
                    }
                    System.out.printf("\n");
                }


                for (i = 0; i < source.m; i++) {
                    if (used_row[i] == 0) {
                        for (j = 0; j < source.n; j++) {
                            if (used_col[j] > 0) {
                                used_col[j] += source.value[i][j];
                            }
                        }
                    }
                }

                maxcnt = 0;
                for (i = 0; i < source.n; i++) {
                    if (used_col[i] > maxcnt) {
                        maxcnt = used_col[i];
                    }
                }
                maxone = -1;
                for (i = 0; i < source.n; i++) {
                    if (used_col[i] == maxcnt) {
                        if (maxone == -1) {
                            maxone = i;
                        } else {
                            maxone = -2;
                        }
                    } else {
                        used_col[i] = 0;
                    }
                }

                if (maxone == -2) {
                    uc = reset(uc);
                    for (i = 0; i < source.m; i++) {
                        for (j = 0; j < source.n; j++) {
                            if (used_row[i] == 1) {
                                uc[j] += source.value[i][j];
                            }
                        }
                    }
                    maxcnt = MAX_ROW_NUM;
                    for (i = 0; i < source.n; i++) {
                        if (used_col[i] > 0 && uc[i] < maxcnt) {
                            maxcnt = uc[i];
                        }
                    }
                    maxone = -1;
                    for (i = 0; i < source.n; i++) {
//                    System.out.printf("%d ", used_col[i]);
                        if (used_col[i] > 0 && uc[i] == maxcnt) {
                            maxone = i;
                            break;
                        }
                    }
//                System.out.printf("\n");
                }
            }
            result.value[0][maxone] = 1;
            if (DEBUG) {
                System.out.printf("maxone: %d\n", maxone);
            }
            for (i = 0; i < source.m; i++) {
                if (source.value[i][maxone] == 1) {
                    used_row[i] = 1;
                } else {
                    if (used_row[i] == 2) {
                        used_row[i] = 0;
                        if (DEBUG) {
                            System.out.printf("hy: %d\n", i);
                        }
                        if (DEBUG) {
                            System.out.printf("source: %d\n", source.value[i][maxone]);
                        }
                    }
                }
            }
        }
        return result;
    }


    static boolean chkSet(dataMatrixString a, dataMatrixString b) {
        int i, j, k;
        for (i = 0; i < b.m; i++) {
            for (j = 0; j < a.m; j++) {
                for (k = 0; k < a.n; k++) {
                    if (!a.value[j][k].equals(b.value[i][k])) {
                        break;
                    }
                }
                if (k >= a.n) {
                    break;
                }
            }
            if (j >= a.m) {
                return false;
            }
        }
        return true;
    }

    static dataMatrixInt getBinMatrix(dataMatrixString positive, dataMatrixString negative, int rn) {
        dataMatrixInt result = new dataMatrixInt();
        result.m = positive.m;
        result.n = positive.n;
        result.value = reset(result.value);
        int i, j;
        for (i = 0; i < positive.m; i++) {
            for (j = 0; j < positive.n; j++) {
                if (positive.value[i][j].equals(negative.value[rn][j])) {
                    result.value[i][j] = 0;
                } else {
                    result.value[i][j] = 1;
                }
            }
        }
        return result;
    }

 
    static ArrayList<dataMatrixString> splitMatrix(dataMatrixString positive, dataMatrixString negative, int rn) {
        dataMatrixInt solution = setCover(getBinMatrix(positive, negative, rn));
        ArrayList<dataMatrixString> result = new ArrayList<dataMatrixString>();
        //result.clear();
        dataMatrixString temp_matrix = new dataMatrixString();
        int i, j, k;
        for (i = 0; i < solution.n; i++) {
            if (solution.value[0][i] == 1) {
                temp_matrix.m = 0;
                temp_matrix.n = positive.n;
                for (j = 0; j < positive.m; j++) {
                    //System.out.printf("j: %d %s %s\n", j, positive.value[j][i].c_str(), negative.value[rn][i].c_str());
                    if (!positive.value[j][i].equals(negative.value[rn][i])) {
                        for (k = 0; k < positive.n; k++) {
                            temp_matrix.value[temp_matrix.m][k] = positive.value[j][k];
                        }
                        temp_matrix.m++;
                    }
                }
                result.add(temp_matrix);
            }
        }
        return result;
    }

    static void removeDupMatrix(ArrayList<dataMatrixString> ms) {
        //int i;
        // ArrayList<dataMatrixString>::iterator it1, it2;
        int[] hash = new int[ms.size()];
//	System.out.printf("sz: %d\n", ms.size());
        hash = reset(hash);
        int p, k;
        p = 0;
        for (dataMatrixString it1 : ms) {
            if (hash[p] == 1) {
                continue;
            }
            k = 0;
            for (dataMatrixString it2 : ms) {
                if (it1 == it2 || hash[k] == 1) {
                    continue; // TODO: Dubious 
                }
                if (chkSet(it1, it2)) {
                    hash[k] = 1;
                }
                k++;
            }
            p++;
        }
        //p=0;
        for (p = 0; p < ms.size(); p++) {
            if (hash[p] == 1) {
                ms.remove(p);
            }

        }
    }

    static void printRule(dataMatrixString negative, dataMatrixString leaf) {
        int i, j, k, l;
        dataMatrixString bp = new dataMatrixString();
        dataMatrixInt bp_t = new dataMatrixInt();
        bp.m = negative.m;
        bp.n = negative.n;
        bp_t.m = negative.m;
        bp_t.n = negative.n;
        bp_t.value = reset(bp_t.value);
        for (i = 0; i < negative.m; i++) {
            for (j = 0; j < negative.n; j++) {
                for (k = 0; k < leaf.m; k++) {
                    if (negative.value[i][j].equals(leaf.value[k][j])) {
                        break;
                    }
                }
                if (k < leaf.m) {
                    bp.value[i][j] = "0";
                    bp_t.value[i][j] = 0;
                } else {
                    bp.value[i][j] = negative.value[i][j];
                    bp_t.value[i][j] = 1;
                }
            }
        }
        dataMatrixInt sol = setCover(bp_t);
        HashMap<Integer, String> rule = new HashMap<Integer, String>();

        for (i = 0; i < sol.n; i++) {
            if (sol.value[0][i] == 1) {
                for (j = 0; j < bp_t.m; j++) {
                    if (bp_t.value[j][i] != 0) {
                        rule.put(new Integer(i), bp.value[j][i]);
                    }
                }
            }
        }

        System.out.printf("if ");
        boolean start = true;
        for (Integer sit : rule.keySet()) {
            if (start) {
                start = false;
            } else {
                System.out.printf("and ");
            }
            System.out.printf("%s <> %s ", title[sit.intValue()], rule.get(sit));
        }
        System.out.printf("then %s = %s\n", title[colnum - 1], currentclass);
    }

    static void solve(dataMatrixString positive, dataMatrixString negative) {
        int i, j, k, l;
        ArrayList<dataMatrixString> l1 = new ArrayList<dataMatrixString>();
        ArrayList<dataMatrixString> l2 = new ArrayList<dataMatrixString>();
        ArrayList<dataMatrixString> tl;

        l1.add(positive);
        for (i = 0; i < negative.m; i++) {
            for (dataMatrixString it : l1) {
                ArrayList<dataMatrixString> tmp = splitMatrix(it, negative, i);
                l2.addAll(tmp);
            }
            removeDupMatrix(l2);
            tl = l1;
            l1 = l2;
            l2 = tl;
            l2 = new ArrayList();
        }

        dataMatrixInt tm = new dataMatrixInt();
        tm.m = positive.m;
        tm.n = l1.size();
        tm.value = reset(tm.value);
        l = 0;
        for (dataMatrixString it : l1) {

            for (i = 0; i < positive.m; i++) {
                for (k = 0; k < it.m; k++) {
                    for (j = 0; j < positive.n; j++) {
                        if (!positive.value[i][j].equals(it.value[k][j])) {
                            break;
                        }
                    }
                    if (j >= positive.n) {
                        break;
                    }
                }
                if (k < it.m) {
                    tm.value[i][l] = 1;
                } else {
                    tm.value[i][l] = 0;
                }
            }
            l++;
        }

        dataMatrixInt sol = setCover(tm);
        int cnt = 1;
        i = 0;
        for (dataMatrixString it : l1) {
            if (sol.value[0][i] != 0) {
                //System.out.printf("rule %d:", cnt++);
                printRule(negative, it);
            }
            i++;
        }
    }

    public static String makeMenu() throws IOException {
        File dir = new File(".");
        String[] children;
        int x = 0;
        FilenameFilter filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                //System.out.println(name);
                return name.endsWith("txt");
            }
        };
        children = dir.list(filter);
        if (children == null || children.length == 0) {
            System.out.println("Can't find .txt data files in the same directory as the class file!");
            return null;
        } else {
            System.out.println("Select the file to be used for the processing");
            for (int i = 0; i < children.length; i++) {
                System.out.println("\t" + (i + 1) + ". " + children[i]);
            }
            System.out.println("Press the number for the file to be picked.");
            do {
                System.out.print("?");
                x = System.in.read();
            } while ((x - 48) > children.length || (x - 48) < 1);
            System.out.println("Selected " + children[x - 49]);
            return children[x - 49];
        }
    }

    public static void main(String args[]) throws FileNotFoundException, IOException {
        String strFilename = makeMenu();
        csvBuffFile = new BufferedReader(new FileReader(strFilename));

        DBName = csvBuffFile.readLine();
        title = csvBuffFile.readLine().split(",");
        DBMetaDataFieldType = csvBuffFile.readLine().split(",");
        String strLine = csvBuffFile.readLine();
        //data = new ArrayList<ArrayList<String>>();

        dataMatrixString data = new dataMatrixString();
        data.m = 0;
        data.n = title.length;
        colnum = title.length;
        String value;
        int i = 0;
        strLine = csvBuffFile.readLine();
        while (strLine != null) {
            data.value[i] = strLine.split(",");
            strLine = csvBuffFile.readLine();
            i++;
        }
        data.m = i;
        csvBuffFile.close();

        myclass = new HashSet();
        //System.out.print(" m " + data.m);
        for (i = 0; i < data.m; i++) {
            //System.out.print(" m " + data.value[i][colnum - 1]);
            myclass.add(data.value[i][colnum - 1]);
        }
        //HashSet<String>::iterator sit;
        dataMatrixString positive = new dataMatrixString();
        dataMatrixString negative = new dataMatrixString();
        positive.n = negative.n = data.n - 1;
        for (String sit : myclass) {
            //System.out.printf("the positive class is %s\n", sit);
            currentclass = new String(sit);
            positive.m = 0;
            negative.m = 0;
            for (i = 0; i < data.m; i++) {
                if (data.value[i][colnum - 1].equals(sit)) {
                    for (int j = 0; j < positive.n; j++) {
                        positive.value[positive.m][j] = data.value[i][j];
                    }
                    positive.m++;
                } else {
                    for (int j = 0; j < negative.n; j++) {
                        negative.value[negative.m][j] = data.value[i][j];
                    }
                    negative.m++;
                }
            }
            solve(positive, negative);
        }

    }
}
